package com.batchfee.edu.ui.enquiries

import android.content.ClipData
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import com.batchfee.edu.data.database.AppDatabase
import com.batchfee.edu.data.models.EnquiryEntity
import com.batchfee.edu.domain.SessionManager
import com.batchfee.edu.domain.EnquiryFollowUpSupport
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val BgColor = Color(0xFF07111F)
private val CardBg = Color(0xFF0F172A)
private val CardBgAlt = Color(0xFF111827)
private val BorderSub = Color(0xFF1E293B)
private val Cyan = Color(0xFF22D3EE)
private val ElectricBlue = Color(0xFF3B82F6)
private val TextWhite = Color(0xFFF8FAFC)
private val TextMuted = Color(0xFF94A3B8)
private val AccentGreen = Color(0xFF10B981)
private val AccentRed = Color(0xFFEF4444)
private val AccentAmber = Color(0xFFF59E0B)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EnquiryListScreen(
    db: AppDatabase,
    onBack: () -> Unit,
    onAddEnquiry: () -> Unit,
    onConvertToStudent: (EnquiryEntity) -> Unit
) {
    val viewModel: EnquiryViewModel = viewModel(factory = EnquiryViewModelFactory(db))
    val allEnquiries by viewModel.allEnquiries.collectAsState()
    val archivedEnquiries by viewModel.archivedEnquiries.collectAsState()
    val auditLogs by viewModel.auditLogs.collectAsState()
    val filterStatus by viewModel.filterStatus.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val todayCount by viewModel.todayCount.collectAsState()
    val followUpCount by viewModel.followUpCount.collectAsState()

    var selectedEnquiry by remember { mutableStateOf<EnquiryEntity?>(null) }
    var showStatusDialog by remember { mutableStateOf(false) }
    var showAddDialog by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var newPhone by remember { mutableStateOf("") }
    var newSubject by remember { mutableStateOf("") }
    var newAddress by remember { mutableStateOf("") }
    var showDeleteConfirmation by remember { mutableStateOf(false) }
    var staffFilter by remember { mutableStateOf("") }
    var sourceFilter by remember { mutableStateOf("") }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }

    val filteredEnquiries = remember(allEnquiries, archivedEnquiries, filterStatus, staffFilter, sourceFilter) {
        val source = if (filterStatus == "archived") archivedEnquiries else allEnquiries
        val statusFiltered = when (filterStatus) {
            "follow_up" -> source.filter {
                it.status.equals("follow_up", ignoreCase = true) ||
                it.status.equals("follow up", ignoreCase = true)
            }
            "active" -> source.filter { it.status.equals("active", ignoreCase = true) }
            "close" -> source.filter {
                it.status.equals("close", ignoreCase = true) ||
                it.status.equals("closed", ignoreCase = true)
            }
            "overdue" -> source.filter {
                val now = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
                it.followUpAtMs != null && it.followUpAtMs < now
            }
            else -> source
        }
        statusFiltered.filter { (staffFilter.isBlank() || it.assignedStaffId.equals(staffFilter, true)) && (sourceFilter.isBlank() || it.source?.contains(sourceFilter, true) == true) }
    }

    Scaffold(
        containerColor = BgColor,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("Enquiries", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 20.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = TextWhite)
                    }
                },
                actions = {
                    IconButton(onClick = onAddEnquiry) {
                        Icon(Icons.Filled.Add, "Add Enquiry", tint = Cyan)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgColor)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = Color.Transparent,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(brush = Brush.horizontalGradient(listOf(ElectricBlue, Cyan)))
            ) {
                Icon(Icons.Default.Add, "Add", tint = Color.White)
            }
        }
    ) { padding ->
        if (isLoading) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Cyan, strokeWidth = 3.dp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding).fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // ── Summary row ────────────────────────────
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SummaryChip("Today", "$todayCount", Cyan, filterStatus == "today", Modifier.weight(1f)) {
                            // Today filter just shows count, no separate filter
                        }
                        SummaryChip("Follow Up", "$followUpCount", AccentAmber, filterStatus == "follow_up", Modifier.weight(1f)) {
                            viewModel.setFilter(if (filterStatus == "follow_up") "all" else "follow_up")
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }

                // ── Filter chips ────────────────────────────
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("all" to "All", "active" to "Active", "follow_up" to "Follow Up", "overdue" to "Overdue", "close" to "Closed", "archived" to "Archived").forEach { (key, label) ->
                            val isSel = filterStatus == key
                            FilterChip(
                                selected = isSel,
                                onClick = { viewModel.setFilter(key) },
                                label = {
                                    Text(
                                        label,
                                        fontSize = 12.sp,
                                        color = if (isSel) Color.White else TextMuted
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ElectricBlue.copy(alpha = 0.25f),
                                    selectedLabelColor = Color.White,
                                    containerColor = CardBg,
                                    labelColor = TextMuted
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    borderColor = BorderSub,
                                    selectedBorderColor = Cyan,
                                    enabled = true,
                                    selected = isSel
                                )
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    OutlinedTextField(value = staffFilter, onValueChange = { staffFilter = it }, label = { Text("Assigned staff ID filter") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                    OutlinedTextField(value = sourceFilter, onValueChange = { sourceFilter = it }, label = { Text("Source filter") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                    Text(
                        "${filteredEnquiries.size} enquiry${if (filteredEnquiries.size != 1) "ies" else ""}",
                        color = TextMuted, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(2.dp))
                }

                if (filteredEnquiries.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 60.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Filled.ContactPhone, null,
                                    tint = TextMuted.copy(alpha = 0.4f), modifier = Modifier.size(56.dp)
                                )
                                Spacer(Modifier.height(12.dp))
                                Text("No enquiries found.", color = TextMuted, fontSize = 15.sp)
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "Tap + to add a new enquiry.",
                                    color = TextMuted.copy(alpha = 0.6f), fontSize = 12.sp
                                )
                            }
                        }
                    }
                } else {
                    items(filteredEnquiries, key = { it.id }) { enquiry ->
                        EnquiryCard(
                            enquiry = enquiry,
                            auditLogs = auditLogs,
                            dateFormat = dateFormat,
                            onClick = {
                                selectedEnquiry = enquiry
                                showStatusDialog = true
                            }
                        )
                    }
                }

                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }

    // ── Add enquiry dialog ─────────────────────────────
    if (showAddDialog) {
        Dialog(onDismissRequest = { showAddDialog = false }) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                border = BorderStroke(1.dp, BorderSub)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("New Enquiry", color = TextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(14.dp))

                    OutlinedTextField(
                        value = newName, onValueChange = { newName = it },
                        label = { Text("Name *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = fieldColors(),
                        shape = RoundedCornerShape(10.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = newPhone, onValueChange = { newPhone = it },
                        label = { Text("Phone *") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth(),
                        colors = fieldColors(),
                        shape = RoundedCornerShape(10.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = newSubject, onValueChange = { newSubject = it },
                        label = { Text("Subject *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = fieldColors(),
                        shape = RoundedCornerShape(10.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = newAddress, onValueChange = { newAddress = it },
                        label = { Text("Address (optional)") },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth(),
                        colors = fieldColors(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showAddDialog = false },
                            modifier = Modifier.weight(1f).height(44.dp),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, BorderSub)
                        ) { Text("Cancel", color = TextMuted) }

                        Button(
                            onClick = {
                                viewModel.addEnquiry(
                                    name = newName, phone = newPhone,
                                    address = newAddress, subjectName = newSubject,
                                    enquiryDateMs = System.currentTimeMillis(),
                                    onSuccess = {
                                        showAddDialog = false
                                        newName = ""; newPhone = ""; newSubject = ""; newAddress = ""
                                        scope.launch { snackbarHostState.showSnackbar("Enquiry saved.") }
                                    },
                                    onError = { msg ->
                                        scope.launch { snackbarHostState.showSnackbar(msg) }
                                    }
                                )
                            },
                            modifier = Modifier.weight(1f).height(44.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                        ) { Text("Save", color = Color.White) }
                    }
                }
            }
        }
    }

    // ── Status change dialog ────────────────────────────
    if (showStatusDialog && selectedEnquiry != null) {
        val e = selectedEnquiry!!
        val enquiryTimeline = remember(auditLogs, e.id, e.name) {
            auditLogs.filter { log -> log.module == "enquiry" && (log.description.contains(e.name) || log.newValue == e.id) }.take(8)
        }
        val statusLabel = when {
            e.status.equals("follow_up", ignoreCase = true) ||
            e.status.equals("follow up", ignoreCase = true) -> "Follow Up"
            e.status.equals("active", ignoreCase = true) -> "Active"
            else -> "Closed"
        }
        val statusColor = when {
            e.status.equals("follow_up", ignoreCase = true) ||
            e.status.equals("follow up", ignoreCase = true) -> AccentAmber
            e.status.equals("active", ignoreCase = true) -> Cyan
            else -> TextMuted
        }

        Dialog(onDismissRequest = { showStatusDialog = false }) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                border = BorderStroke(1.dp, BorderSub)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    // Header
                    Text(
                        e.name,
                        color = TextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Phone, null, tint = TextMuted, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(e.phone, color = TextMuted, fontSize = 13.sp)
                    }
                    if (!e.subjectName.isNullOrBlank()) {
                        Spacer(Modifier.height(2.dp))
                        Text("Subject: ${e.subjectName}", color = TextMuted, fontSize = 13.sp)
                    }
                    if (enquiryTimeline.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text("Activity", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        enquiryTimeline.forEach { event -> Text("• ${event.description}", color = TextMuted, fontSize = 12.sp) }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Date: ${dateFormat.format(Date(e.enquiryDateMs))}",
                        color = TextMuted, fontSize = 12.sp
                    )

                    Spacer(Modifier.height(14.dp))

                    // Current status badge
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Status: ", color = TextMuted, fontSize = 14.sp)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(statusColor.copy(alpha = 0.15f))
                                .padding(horizontal = 10.dp, vertical = 3.dp)
                        ) {
                            Text(statusLabel, color = statusColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(Modifier.height(16.dp))
                    HorizontalDivider(color = BorderSub)
                    Spacer(Modifier.height(12.dp))

                    Text("Contact", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                        val phone = EnquiryFollowUpSupport.normalizedPhone(e.phone)
                        IconButton(onClick = { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))) }) { Icon(Icons.Filled.Call, "Call", tint = Cyan) }
                        IconButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${phone.filter(Char::isDigit)}"))) }) { Icon(Icons.Filled.Chat, "WhatsApp", tint = AccentGreen) }
                        IconButton(onClick = { context.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phone"))) }) { Icon(Icons.Filled.Sms, "SMS", tint = AccentAmber) }
                        IconButton(onClick = {
                            (context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                                .setPrimaryClip(ClipData.newPlainText("Phone", e.phone))
                            scope.launch { snackbarHostState.showSnackbar("Phone number copied") }
                        }) { Icon(Icons.Filled.ContentCopy, "Copy number", tint = TextMuted) }
                    }

                    Spacer(Modifier.height(8.dp))

                    Text("Change Status", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatusButton("Active", Icons.Filled.FiberManualRecord, Cyan, Modifier.weight(1f)) {
                            viewModel.updateStatus(e, "active") { msg ->
                                scope.launch { snackbarHostState.showSnackbar(msg) }
                            }
                            showStatusDialog = false
                        }
                        StatusButton("Follow Up", Icons.Filled.Refresh, AccentAmber, Modifier.weight(1f)) {
                            viewModel.updateStatus(e, "follow_up") { msg ->
                                scope.launch { snackbarHostState.showSnackbar(msg) }
                            }
                            showStatusDialog = false
                        }
                        StatusButton("Closed", Icons.Filled.CheckCircle, AccentGreen, Modifier.weight(1f)) {
                            viewModel.updateStatus(e, "close") { msg ->
                                scope.launch { snackbarHostState.showSnackbar(msg) }
                            }
                            showStatusDialog = false
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    var followType by remember(e.id) { mutableStateOf(e.followUpType ?: "Call") }
                    var followPriority by remember(e.id) { mutableStateOf(e.priority) }
                    var followNote by remember(e.id) { mutableStateOf(e.followUpNote.orEmpty()) }
                    var assignedStaff by remember(e.id) { mutableStateOf(e.assignedStaffId.orEmpty()) }
                    var sourceField by remember(e.id) { mutableStateOf(e.source.orEmpty()) }
                    Text("Follow-up", color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    OutlinedTextField(value = followType, onValueChange = { followType = it }, label = { Text("Type: Call / WhatsApp / SMS / Meeting / Demo / Other") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                    OutlinedTextField(value = followPriority, onValueChange = { followPriority = it }, label = { Text("Priority") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                    OutlinedTextField(value = assignedStaff, onValueChange = { assignedStaff = it }, label = { Text("Assigned staff ID (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                    OutlinedTextField(value = sourceField, onValueChange = { sourceField = it }, label = { Text("Source (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                    OutlinedTextField(value = followNote, onValueChange = { followNote = it }, label = { Text("Follow-up note") }, modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                    OutlinedButton(
                        onClick = {
                            val tomorrow = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 10); set(Calendar.MINUTE, 0) }.timeInMillis
                            viewModel.saveFollowUp(e, tomorrow, followType, followPriority, followNote, assignedStaff, sourceField) { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } }
                            showStatusDialog = false
                        }, modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, AccentAmber.copy(alpha = .5f))
                    ) { Text("Follow up tomorrow", color = AccentAmber) }
                    OutlinedButton(
                        onClick = { viewModel.archive(e) { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } }; showStatusDialog = false },
                        modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, AccentRed.copy(alpha = .5f))
                    ) { Text("Archive enquiry", color = AccentRed) }
                    OutlinedButton(onClick = { onConvertToStudent(e); showStatusDialog = false }, modifier = Modifier.fillMaxWidth()) { Text("Convert to Student", color = Cyan) }
                    if (e.archivedAtMs != null) {
                        OutlinedButton(onClick = { viewModel.archive(e, restore = true); showStatusDialog = false }, modifier = Modifier.fillMaxWidth()) { Text("Restore", color = AccentGreen) }
                    }
                    if (SessionManager.isAdmin()) {
                        TextButton(onClick = { showDeleteConfirmation = true }, modifier = Modifier.fillMaxWidth()) { Text("Permanently Delete", color = AccentRed) }
                    }

                    Spacer(Modifier.height(12.dp))
                    TextButton(
                        onClick = { showStatusDialog = false },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Cancel", color = TextMuted)
                    }
                }
            }
        }
    }
    if (showDeleteConfirmation && selectedEnquiry != null) {
        AlertDialog(onDismissRequest = { showDeleteConfirmation = false }, title = { Text("Permanently delete enquiry?") }, text = { Text("This cannot be undone. Archive is safer for normal follow-up management.") }, confirmButton = { TextButton(onClick = { viewModel.deletePermanently(selectedEnquiry!!) { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } }; showDeleteConfirmation = false; showStatusDialog = false }) { Text("Delete", color = AccentRed) } }, dismissButton = { TextButton(onClick = { showDeleteConfirmation = false }) { Text("Cancel") } })
    }
}

@Composable
private fun SummaryChip(
    label: String,
    value: String,
    accent: Color,
    isActive: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .shadow(2.dp, RoundedCornerShape(12.dp), spotColor = accent.copy(alpha = 0.12f))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) accent.copy(alpha = 0.12f) else CardBg
        ),
        border = BorderStroke(1.dp, if (isActive) accent.copy(alpha = 0.5f) else BorderSub)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(value, color = accent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp))
            Text(label, color = TextMuted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun EnquiryCard(
    enquiry: EnquiryEntity,
    auditLogs: List<com.batchfee.edu.data.models.AuditLogEntity>,
    dateFormat: SimpleDateFormat,
    onClick: () -> Unit
) {
    val e = enquiry
    val calendar = Calendar.getInstance()
    val startOfToday = calendar.apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
    val startOfTomorrow = (calendar.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }.timeInMillis
    val followUpState = EnquiryFollowUpSupport.followUpState(enquiry.followUpAtMs, startOfToday, startOfTomorrow)
    val statusColor = when {
        enquiry.status.equals("follow_up", ignoreCase = true) ||
        enquiry.status.equals("follow up", ignoreCase = true) -> AccentAmber
        enquiry.status.equals("active", ignoreCase = true) -> Cyan
        else -> TextMuted
    }
    val statusLabel = when {
        enquiry.status.equals("follow_up", ignoreCase = true) ||
        enquiry.status.equals("follow up", ignoreCase = true) -> "Follow Up"
        enquiry.status.equals("active", ignoreCase = true) -> "Active"
        else -> "Closed"
    }

    Card(
        modifier = Modifier.fillMaxWidth()
            .shadow(2.dp, RoundedCornerShape(12.dp), spotColor = statusColor.copy(alpha = 0.10f))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, BorderSub)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Avatar
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(statusColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    enquiry.name.take(1).uppercase(),
                    color = statusColor, fontSize = 16.sp, fontWeight = FontWeight.Bold
                )
            }

            Spacer(Modifier.width(12.dp))

            Column(Modifier.weight(1f)) {
                Text(
                    enquiry.name,
                    color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    "${enquiry.phone} • ${enquiry.subjectName}",
                    color = TextMuted, fontSize = 12.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    dateFormat.format(Date(enquiry.enquiryDateMs)),
                    color = TextMuted.copy(alpha = 0.6f), fontSize = 11.sp
                )
                if (followUpState != com.batchfee.edu.domain.FollowUpState.NONE) {
                    Text(
                        when (followUpState) {
                            com.batchfee.edu.domain.FollowUpState.OVERDUE -> "Follow-up overdue"
                            com.batchfee.edu.domain.FollowUpState.TODAY -> "Follow-up today"
                            else -> "Follow-up upcoming"
                        },
                        color = if (followUpState == com.batchfee.edu.domain.FollowUpState.OVERDUE) AccentRed else AccentAmber,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    val timeline = auditLogs.filter { it.module == "enquiry" && (it.description.contains(e.name) || it.newValue == e.id) }.take(8)
                    if (timeline.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp)); Text("Activity", color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        timeline.forEach { log -> Text("• ${log.description}", color = TextMuted, fontSize = 12.sp) }
                    }
                }
            }

            Spacer(Modifier.width(8.dp))

            // Status badge
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(statusColor.copy(alpha = 0.12f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(statusLabel, color = statusColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(4.dp))
                Icon(
                    Icons.Filled.ChevronRight, null,
                    tint = TextMuted.copy(alpha = 0.3f), modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun StatusButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(46.dp),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.4f)),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = color),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextWhite,
    unfocusedTextColor = TextWhite,
    focusedBorderColor = ElectricBlue,
    unfocusedBorderColor = BorderSub,
    focusedContainerColor = CardBgAlt,
    unfocusedContainerColor = CardBgAlt,
    cursorColor = Cyan,
    focusedLabelColor = Cyan,
    unfocusedLabelColor = TextMuted
)

