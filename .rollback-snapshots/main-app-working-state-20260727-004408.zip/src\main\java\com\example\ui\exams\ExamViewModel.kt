package com.batchfee.edu.ui.exams

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.batchfee.edu.data.database.AppDatabase
import com.batchfee.edu.data.firestore.ExamSyncHelper
import com.batchfee.edu.data.firestore.InstituteCacheRefreshManager
import com.batchfee.edu.data.models.BatchEntity
import com.batchfee.edu.data.models.ExamEntity
import com.batchfee.edu.data.models.InstituteEntity
import com.batchfee.edu.data.models.ResultEntity
import com.batchfee.edu.data.models.StudentEntity
import com.batchfee.edu.domain.ExamMarkOutcome
import com.batchfee.edu.domain.ExamResultRules
import com.batchfee.edu.domain.ExamReviewSummary
import com.batchfee.edu.domain.SessionManager
import com.batchfee.edu.domain.StaffAuditLogger
import com.batchfee.edu.domain.StaffPermissions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

data class MarkEntry(
    val studentId: String,
    val marks: Double? = null,
    val isAbsent: Boolean = false,
    val remark: String? = null
)

data class StudentResultItem(
    val student: StudentEntity,
    val result: ResultEntity?,
    val marksText: String,
    val position: Int?
)

data class ResultCardData(
    val institute: InstituteEntity?,
    val batchName: String,
    val exam: ExamEntity,
    val item: StudentResultItem,
    val outcome: ExamMarkOutcome
)

data class ReportCardLine(val exam: ExamEntity, val result: ResultEntity, val outcome: ExamMarkOutcome)

data class ReportCardData(
    val institute: InstituteEntity?,
    val batchName: String,
    val student: StudentEntity,
    val lines: List<ReportCardLine>
)

class ExamViewModel(private val db: AppDatabase) : ViewModel() {
    private val _exams = MutableStateFlow<List<ExamEntity>>(emptyList())
    val exams = _exams.asStateFlow()
    private val _batches = MutableStateFlow<List<BatchEntity>>(emptyList())
    val batches = _batches.asStateFlow()
    private val _institute = MutableStateFlow<InstituteEntity?>(null)
    private val _selectedExam = MutableStateFlow<ExamEntity?>(null)
    val selectedExam = _selectedExam.asStateFlow()
    private val _studentResults = MutableStateFlow<List<StudentResultItem>>(emptyList())
    val studentResults = _studentResults.asStateFlow()
    private val _batchStudents = MutableStateFlow<List<StudentEntity>>(emptyList())
    val batchStudents = _batchStudents.asStateFlow()
    private val _isLoading = MutableStateFlow(false)
    val isLoading = _isLoading.asStateFlow()
    private var detailsJob: Job? = null

    init { loadData() }

    private fun loadData() {
        val instituteId = SessionManager.currentInstituteId.value ?: return
        viewModelScope.launch {
            InstituteCacheRefreshManager.refreshIfStale(db, instituteId)
            db.examDao().getExamsByInstitute(instituteId).collect { _exams.value = it }
        }
        viewModelScope.launch { db.batchDao().getBatchesByInstitute(instituteId).collect { _batches.value = it } }
        viewModelScope.launch { db.instituteDao().getInstituteFlow(instituteId).collect { _institute.value = it } }
    }

    fun loadExamDetails(examId: String) {
        val instituteId = SessionManager.currentInstituteId.value ?: return
        detailsJob?.cancel()
        _isLoading.value = true
        detailsJob = viewModelScope.launch {
            InstituteCacheRefreshManager.refreshIfStale(db, instituteId)
            db.examDao().getExamById(examId, instituteId).collectLatest { exam ->
                _selectedExam.value = exam
                if (exam == null) {
                    _studentResults.value = emptyList(); _batchStudents.value = emptyList(); _isLoading.value = false
                } else {
                    combine(
                        db.resultDao().getResultsForExam(examId, instituteId),
                        db.batchStudentDao().getStudentsForBatch(exam.batchId, instituteId)
                    ) { results, students ->
                        val resultByStudent = results.associateBy { it.studentId }
                        students.sortedWith(
                            compareByDescending<StudentEntity> { resultByStudent[it.id]?.isAbsent == false }
                                .thenByDescending { resultByStudent[it.id]?.marksObtained ?: Double.NEGATIVE_INFINITY }
                        ).map { student ->
                            val result = resultByStudent[student.id]
                            StudentResultItem(
                                student = student,
                                result = result,
                                marksText = result?.marksObtained?.let(::formatMarks).orEmpty(),
                                position = result?.position
                            )
                        } to students
                    }.collect { (items, students) ->
                        _studentResults.value = items
                        _batchStudents.value = students
                        _isLoading.value = false
                    }
                }
            }
        }
    }

    fun createExam(
        batchId: String, examName: String, examType: String, subject: String?, totalMarks: Double,
        passingMarks: Double, examDateMs: Long, includeInReportCard: Boolean, teacherName: String?,
        onSuccess: () -> Unit, onError: (String) -> Unit = {}
    ) {
        val instituteId = SessionManager.currentInstituteId.value ?: return
        if (!canManage(onError) || !validateExam(batchId, examName, totalMarks, passingMarks, onError)) return
        val now = System.currentTimeMillis()
        val exam = ExamEntity(
            id = UUID.randomUUID().toString(), instituteId = instituteId, batchId = batchId,
            examName = examName.trim(), examType = examType.takeIf { it in ExamResultRules.examTypes } ?: "Other",
            subject = subject?.trim()?.takeIf { it.isNotEmpty() }, examDateMs = examDateMs,
            totalMarks = totalMarks, passingMarks = passingMarks,
            teacherName = teacherName?.trim()?.takeIf { it.isNotEmpty() }, note = null,
            includeInReportCard = includeInReportCard, status = ExamResultRules.DRAFT,
            createdAtMs = now, updatedAtMs = now, archivedAtMs = null
        )
        viewModelScope.launch {
            runCatching { ExamSyncHelper.upsertExam(exam); db.examDao().insertExam(exam) }
                .onSuccess { onSuccess() }.onFailure { onError(it.message ?: "Failed to create exam") }
        }
    }

    fun updateExam(
        examId: String, batchId: String, examName: String, examType: String, subject: String?, totalMarks: Double,
        passingMarks: Double, examDateMs: Long, includeInReportCard: Boolean, teacherName: String?,
        onSuccess: () -> Unit, onError: (String) -> Unit = {}
    ) {
        val instituteId = SessionManager.currentInstituteId.value ?: return
        val current = _selectedExam.value
        if (!canManage(onError) || current?.id != examId) { if (current?.id != examId) onError("Exam details not loaded yet."); return }
        if (current.status != ExamResultRules.DRAFT) { onError("Only draft exams can be edited. Historical result settings stay fixed."); return }
        if (!validateExam(batchId, examName, totalMarks, passingMarks, onError)) return
        viewModelScope.launch {
            val updated = current.copy(
                instituteId = instituteId, batchId = batchId, examName = examName.trim(),
                examType = examType.takeIf { it in ExamResultRules.examTypes } ?: "Other",
                subject = subject?.trim()?.takeIf { it.isNotEmpty() }, totalMarks = totalMarks,
                passingMarks = passingMarks, examDateMs = examDateMs, includeInReportCard = includeInReportCard,
                teacherName = teacherName?.trim()?.takeIf { it.isNotEmpty() }, updatedAtMs = System.currentTimeMillis()
            )
            runCatching { ExamSyncHelper.upsertExam(updated); db.examDao().updateExam(updated) }
                .onSuccess { onSuccess() }.onFailure { onError(it.message ?: "Failed to update exam") }
        }
    }

    fun archiveExam(examId: String, onSuccess: () -> Unit, onError: (String) -> Unit = {}) {
        val instituteId = SessionManager.currentInstituteId.value ?: return
        if (!canManage(onError)) return
        viewModelScope.launch {
            runCatching {
                val now = System.currentTimeMillis()
                _selectedExam.value?.takeIf { it.id == examId }?.copy(
                    status = ExamResultRules.ARCHIVED, archivedAtMs = now, updatedAtMs = now
                )?.let { ExamSyncHelper.upsertExam(it) }
                db.examDao().archiveExam(instituteId, examId, now)
                StaffAuditLogger.record(db, instituteId, SessionManager.currentUserId.value, "exam_archived", "exam", "Archived exam $examId")
            }.onSuccess { onSuccess() }.onFailure { onError(it.message ?: "Failed to archive exam") }
        }
    }

    fun saveResults(examId: String, entries: List<MarkEntry>, onSuccess: () -> Unit, onError: (String) -> Unit = {}) {
        val instituteId = SessionManager.currentInstituteId.value ?: return
        val exam = _selectedExam.value
        if (!canManage(onError) || exam?.id != examId) { if (exam?.id != examId) onError("Exam details not loaded yet."); return }
        if (!ExamResultRules.canEditResults(exam.status)) { onError("Published or archived results cannot be changed."); return }
        val studentIds = _batchStudents.value.map { it.id }.toSet()
        if (entries.map { it.studentId }.toSet().size != entries.size || entries.any { it.studentId !in studentIds }) { onError("Invalid student result entry."); return }
        if (entries.any { !it.isAbsent && (it.marks == null || !ExamResultRules.validateMark(it.marks, exam.totalMarks)) }) {
            onError("Marks must be between 0 and ${formatMarks(exam.totalMarks)}."); return
        }
        if (_studentResults.value.any { it.result?.published == true }) { onError("Published results cannot be silently changed."); return }

        viewModelScope.launch {
            runCatching {
                val now = System.currentTimeMillis()
                val existing = _studentResults.value.mapNotNull { it.result }.associateBy { it.studentId }
                val changed = entries.associateBy { it.studentId }
                val finalEntries = (existing.keys + changed.keys).mapNotNull { studentId ->
                    changed[studentId] ?: existing[studentId]?.let { MarkEntry(it.studentId, it.marksObtained, it.isAbsent, it.remarks) }
                }
                val ranked = finalEntries.filter { !it.isAbsent }.sortedByDescending { it.marks!! }
                val rankByStudent = ranked.zip(ExamResultRules.ranksDescending(ranked.map { it.marks!! })).associate { it.first.studentId to it.second }
                val results = finalEntries.map { entry ->
                    val old = existing[entry.studentId]
                    val outcome = ExamResultRules.outcome(entry.marks ?: 0.0, exam.totalMarks, exam.passingMarks, entry.isAbsent)
                    ResultEntity(
                        id = old?.id ?: UUID.randomUUID().toString(), instituteId = instituteId, examId = examId,
                        batchId = exam.batchId, studentId = entry.studentId, marksObtained = entry.marks ?: 0.0,
                        isAbsent = entry.isAbsent, grade = outcome.grade, position = if (entry.isAbsent) null else rankByStudent[entry.studentId],
                        remarks = entry.remark?.trim()?.takeIf { it.isNotEmpty() } ?: old?.remarks,
                        published = false, createdAtMs = old?.createdAtMs ?: now, updatedAtMs = now
                    )
                }
                val summary = reviewFor(results, _batchStudents.value.size, exam)
                val updatedExam = exam.copy(status = ExamResultRules.statusForReview(summary), updatedAtMs = now)
                withContext(Dispatchers.IO) {
                    results.forEach { ExamSyncHelper.upsertResult(it); db.resultDao().insertOrUpdateResult(it) }
                    ExamSyncHelper.upsertExam(updatedExam); db.examDao().updateExam(updatedExam)
                }
            }.onSuccess { onSuccess() }.onFailure { onError(it.message ?: "Failed to save marks") }
        }
    }

    fun reviewSummary(): ExamReviewSummary {
        val exam = _selectedExam.value ?: return ExamReviewSummary(0, 0, 0, 0, 0, 0)
        return reviewFor(_studentResults.value.mapNotNull { it.result }, _batchStudents.value.size, exam)
    }

    fun publishResults(examId: String, onSuccess: () -> Unit, onError: (String) -> Unit = {}) {
        val exam = _selectedExam.value
        if (!canManage(onError) || exam?.id != examId) { if (exam?.id != examId) onError("Exam details not loaded yet."); return }
        val summary = reviewSummary()
        if (exam.status != ExamResultRules.READY_TO_PUBLISH || !ExamResultRules.canPublish(summary.totalStudents, summary.marksEntered)) {
            onError("Review requires marks or absence for every batch student before publishing."); return
        }
        viewModelScope.launch {
            runCatching {
                val now = System.currentTimeMillis()
                withContext(Dispatchers.IO) {
                    _studentResults.value.mapNotNull { it.result }.forEach { result ->
                        val updated = result.copy(published = true, updatedAtMs = now)
                        ExamSyncHelper.upsertResult(updated); db.resultDao().insertOrUpdateResult(updated)
                    }
                    val published = exam.copy(status = ExamResultRules.PUBLISHED, updatedAtMs = now)
                    ExamSyncHelper.upsertExam(published); db.examDao().updateExam(published)
                    StaffAuditLogger.record(db, exam.instituteId, SessionManager.currentUserId.value, "exam_results_published", "exam", "Published results for ${exam.examName}")
                }
            }.onSuccess { onSuccess() }.onFailure { onError(it.message ?: "Failed to publish results") }
        }
    }

    fun resultCard(item: StudentResultItem, exam: ExamEntity): ResultCardData? {
        val result = item.result ?: return null
        return ResultCardData(_institute.value, batchName(exam.batchId), exam, item,
            ExamResultRules.outcome(result.marksObtained, exam.totalMarks, exam.passingMarks, result.isAbsent))
    }

    fun buildReportCard(item: StudentResultItem, maxExams: Int = 3, onReady: (ReportCardData?) -> Unit) {
        val instituteId = SessionManager.currentInstituteId.value ?: return onReady(null)
        viewModelScope.launch {
            val eligible = _exams.value.filter {
                it.batchId == item.result?.batchId && it.includeInReportCard && it.status == ExamResultRules.PUBLISHED
            }.sortedByDescending { it.examDateMs }.take(maxExams)
            val resultByExam = db.resultDao().getResultsForStudent(item.student.id, instituteId).associateBy { it.examId }
            val lines = eligible.mapNotNull { exam -> resultByExam[exam.id]?.takeIf { it.published }?.let { result ->
                ReportCardLine(exam, result, ExamResultRules.outcome(result.marksObtained, exam.totalMarks, exam.passingMarks, result.isAbsent))
            } }
            onReady(lines.takeIf { it.isNotEmpty() }?.let { ReportCardData(_institute.value, batchName(item.result?.batchId), item.student, it) })
        }
    }

    fun buildMeritMessage(exam: ExamEntity, includeAll: Boolean = true): String {
        val ranked = _studentResults.value.filter { it.result != null && !it.result.isAbsent }.sortedBy { it.position ?: Int.MAX_VALUE }
        val list = if (includeAll) ranked else ranked.take(10)
        return buildString {
            appendLine("Exam Merit List")
            appendLine("${exam.examName} (${exam.examType}) - ${batchName(exam.batchId)}")
            exam.subject?.let { appendLine("Subject: $it") }
            appendLine("Total Marks: ${formatMarks(exam.totalMarks)} | Pass: ${formatMarks(exam.passingMarks)}")
            appendLine()
            list.forEach { item -> appendLine("${item.position}. ${item.student.fullName} - ${formatMarks(item.result!!.marksObtained)} (${item.result.grade ?: "-"})") }
            appendLine(); appendLine("Sent via ${_institute.value?.name?.ifBlank { "BatchFee" } ?: "BatchFee"}")
        }
    }

    fun buildReportMessage(report: ReportCardData): String = buildString {
        appendLine("REPORT CARD")
        appendLine(report.institute?.name?.ifBlank { "BatchFee" } ?: "BatchFee")
        appendLine("Student: ${report.student.fullName} (${report.student.studentCode})")
        appendLine("Batch: ${report.batchName}")
        appendLine()
        report.lines.forEach { line ->
            appendLine("${line.exam.examName} (${line.exam.examType}): " +
                if (line.result.isAbsent) "Absent" else "${formatMarks(line.result.marksObtained)}/${formatMarks(line.exam.totalMarks)}, ${line.outcome.grade}")
        }
        appendLine(); appendLine("Individual exam results only; no weighting is applied.")
    }

    fun buildStudentMessage(item: StudentResultItem, exam: ExamEntity): String {
        val card = resultCard(item, exam) ?: return "Result is not available."
        return buildString {
            appendLine("RESULT CARD")
            appendLine(card.institute?.name?.ifBlank { "BatchFee" } ?: "BatchFee")
            appendLine("Student: ${card.item.student.fullName} (${card.item.student.studentCode})")
            appendLine("Batch: ${card.batchName}")
            appendLine("Exam: ${exam.examName} (${exam.examType})")
            exam.subject?.let { appendLine("Subject: $it") }
            appendLine("Marks: ${formatMarks(card.item.result!!.marksObtained)} / ${formatMarks(exam.totalMarks)}")
            appendLine("Percentage: ${"%.2f".format(card.outcome.percentage)}% | Grade: ${card.outcome.grade}")
            appendLine("Result: ${if (card.outcome.passed) "Pass" else if (card.item.result.isAbsent) "Absent" else "Fail"}")
            card.item.position?.let { appendLine("Position: $it") }
            card.item.result.remarks?.takeIf { it.isNotBlank() }?.let { appendLine("Remark: $it") }
        }
    }

    private fun reviewFor(results: List<ResultEntity>, totalStudents: Int, exam: ExamEntity): ExamReviewSummary =
        ExamResultRules.review(totalStudents, results.map { ExamResultRules.outcome(it.marksObtained, exam.totalMarks, exam.passingMarks, it.isAbsent) }, results.map { it.isAbsent })

    private fun validateExam(batchId: String, name: String, total: Double, pass: Double, onError: (String) -> Unit): Boolean = when {
        batchId.isBlank() -> { onError("Batch is required."); false }
        name.isBlank() -> { onError("Exam name is required."); false }
        total <= 0 -> { onError("Total marks must be greater than 0."); false }
        pass < 0 || pass > total -> { onError("Pass marks must be between 0 and total marks."); false }
        else -> true
    }

    private fun canManage(onError: (String) -> Unit): Boolean {
        if (SessionManager.isAdmin() || SessionManager.hasPermission(StaffPermissions.MANAGE_EXAMS)) return true
        onError("You do not have permission to manage exams.")
        return false
    }

    private fun batchName(batchId: String?): String = _batches.value.find { it.id == batchId }?.name ?: "Batch"
    private fun formatMarks(value: Double): String = if (value == value.toLong().toDouble()) value.toLong().toString() else "%.1f".format(value)
}

class ExamViewModelFactory(private val db: AppDatabase) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ExamViewModel::class.java)) return ExamViewModel(db) as T
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
