﻿package com.batchfee.edu.data.models

import androidx.room.Entity
import androidx.room.ColumnInfo
import androidx.room.PrimaryKey

@Entity(tableName = "exams")
data class ExamEntity(
    @PrimaryKey val id: String,
    val instituteId: String,
    val batchId: String,
    val examName: String,
    @ColumnInfo(defaultValue = "'Other'") val examType: String = "Other",
    val subject: String?,
    val examDateMs: Long,
    val totalMarks: Double,
    val passingMarks: Double,
    val teacherName: String?,
    val note: String?,
    @ColumnInfo(defaultValue = "1") val includeInReportCard: Boolean = true,
    val status: String,
    val createdAtMs: Long,
    val updatedAtMs: Long,
    val archivedAtMs: Long?
)

