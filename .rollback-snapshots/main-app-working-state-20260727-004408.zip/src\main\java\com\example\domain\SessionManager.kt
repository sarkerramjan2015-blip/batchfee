﻿package com.batchfee.edu.domain

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface SessionState {
    data object Loading : SessionState
    data object Authenticated : SessionState
    data object Unauthenticated : SessionState
    data object SessionExpired : SessionState
}

object SessionManager {
    const val SESSION_TIMEOUT_MS = 300_000L
    const val SESSION_EXPIRED_MESSAGE = "Your session has expired. Please log in again."

    private val sessionLock = Any()

    private val _sessionState = MutableStateFlow<SessionState>(SessionState.Unauthenticated)
    val sessionState: StateFlow<SessionState> = _sessionState.asStateFlow()

    private val _currentUserId = MutableStateFlow<String?>(null)
    val currentUserId: StateFlow<String?> = _currentUserId.asStateFlow()

    private val _currentInstituteId = MutableStateFlow<String?>(null)
    val currentInstituteId: StateFlow<String?> = _currentInstituteId.asStateFlow()

    private val _currentUserRole = MutableStateFlow<String?>(null)
    val currentUserRole: StateFlow<String?> = _currentUserRole.asStateFlow()

    private val _currentStaffPermissions = MutableStateFlow<Set<String>>(emptySet())
    val currentStaffPermissions: StateFlow<Set<String>> = _currentStaffPermissions.asStateFlow()

    private val _sessionNotice = MutableStateFlow<String?>(null)
    val sessionNotice: StateFlow<String?> = _sessionNotice.asStateFlow()

    private val _lastActivityAtMs = MutableStateFlow(System.currentTimeMillis())
    val lastActivityAtMs: StateFlow<Long> = _lastActivityAtMs.asStateFlow()

    fun beginRestoringSession() {
        synchronized(sessionLock) {
            if (_sessionState.value is SessionState.Authenticated) return
            _sessionNotice.value = null
            _sessionState.value = SessionState.Loading
        }
    }

    fun login(userId: String, instituteId: String?, role: String, staffPermissions: String? = null) {
        synchronized(sessionLock) {
            _sessionNotice.value = null
            _currentUserId.value = userId
            _currentInstituteId.value = instituteId
            _currentUserRole.value = role
            _currentStaffPermissions.value = parsePermissions(staffPermissions)
            _lastActivityAtMs.value = System.currentTimeMillis()
            _sessionState.value = SessionState.Authenticated
        }
    }

    fun logout(expired: Boolean = false) {
        synchronized(sessionLock) {
            clearAuthenticatedState(expired)
            _sessionState.value = if (expired) SessionState.SessionExpired else SessionState.Unauthenticated
        }
    }

    /**
     * Clears only in-memory account state.  The caller owns Firebase sign-out.
     * Returning false makes simultaneous auth failures a single expiry event.
     */
    fun expireSession(): Boolean = synchronized(sessionLock) {
        if (_sessionState.value !is SessionState.Authenticated &&
            _sessionState.value !is SessionState.Loading
        ) return false
        clearAuthenticatedState(expired = true)
        _sessionState.value = SessionState.SessionExpired
        true
    }

    /** Returns true only for a confirmed unauthenticated remote failure. */
    fun handleRemoteFailure(error: Throwable): Boolean {
        return if (SessionErrorClassifier.classify(error) == SessionFailureKind.SESSION_INVALID) {
            expireSession()
        } else {
            false
        }
    }

    /** Acknowledges the one-shot expiry notice after the root UI displays it. */
    fun consumeSessionNotice(notice: String) {
        synchronized(sessionLock) {
            if (_sessionNotice.value == notice) {
                _sessionNotice.value = null
            }
        }
    }

    fun markActivity() {
        if (_currentUserId.value != null) {
            _lastActivityAtMs.value = System.currentTimeMillis()
        }
    }

    fun isSessionInactive(nowMs: Long = System.currentTimeMillis()): Boolean {
        return _currentUserId.value != null && nowMs - _lastActivityAtMs.value >= SESSION_TIMEOUT_MS
    }

    fun isLoggedIn(): Boolean = _sessionState.value is SessionState.Authenticated &&
        _currentUserId.value != null

    // Role helpers for access control
    fun isAdmin(): Boolean {
        val role = _currentUserRole.value ?: return false
        return role in listOf("InstituteOwner", "SuperAdmin", "InstituteAdmin")
    }

    fun isStaff(): Boolean {
        val role = _currentUserRole.value ?: return false
        return role == "Staff"
    }

    fun updateStaffPermissions(staffPermissions: String?) {
        _currentStaffPermissions.value = parsePermissions(staffPermissions)
    }

    fun hasPermission(permission: String, staffPermissions: String? = null): Boolean {
        if (isAdmin()) return true
        val permissions = staffPermissions?.let(::parsePermissions) ?: _currentStaffPermissions.value
        return permission in permissions
    }

    fun hasAnyPermission(vararg permissions: String): Boolean {
        if (isAdmin()) return true
        return permissions.any { hasPermission(it) }
    }

    private fun parsePermissions(raw: String?): Set<String> {
        return raw
            ?.split(",")
            ?.map { it.trim() }
            ?.filter { it.isNotEmpty() }
            ?.toSet()
            ?: emptySet()
    }

    private fun clearAuthenticatedState(expired: Boolean) {
        _sessionNotice.value = if (expired) SESSION_EXPIRED_MESSAGE else null
        _currentUserId.value = null
        _currentInstituteId.value = null
        _currentUserRole.value = null
        _currentStaffPermissions.value = emptySet()
    }
}

