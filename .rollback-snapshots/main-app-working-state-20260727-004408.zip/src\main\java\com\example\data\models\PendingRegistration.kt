﻿package com.batchfee.edu.data.models

data class PendingRegistration(
    val requestId: String = "",
    val instituteId: String = "",
    val fullName: String = "",
    val phone: String = "",
    val guardianName: String? = null,
    val whatsappNumber: String? = null,
    val gender: String? = null,
    val dateOfBirthMs: Long? = null,
    val schoolName: String? = null,
    val className: String? = null,
    val address: String? = null,
    val requestedBatchId: String? = null,
    val source: String? = null,
    val submittedAt: Long = System.currentTimeMillis(),
    val status: String = "pending",
    val approvedStudentId: String? = null,
    val approvedAt: Long? = null,
    val approvedByUserId: String? = null,
    val rejectedAt: Long? = null,
    val rejectedByUserId: String? = null,
    val rejectionReason: String? = null
)

