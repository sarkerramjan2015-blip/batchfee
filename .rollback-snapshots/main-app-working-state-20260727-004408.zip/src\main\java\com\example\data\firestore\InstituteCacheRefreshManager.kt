﻿package com.batchfee.edu.data.firestore

import com.batchfee.edu.data.database.AppDatabase
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

object InstituteCacheRefreshManager {
    private const val DEFAULT_MIN_INTERVAL_MS = 30_000L
    private val lastRefreshAtMs = mutableMapOf<String, Long>()
    private val inFlightRefreshes = mutableMapOf<String, CompletableDeferred<Boolean>>()
    private val refreshMutex = Mutex()

    suspend fun refreshIfStale(
        db: AppDatabase,
        instituteId: String,
        minIntervalMs: Long = DEFAULT_MIN_INTERVAL_MS
    ): Boolean = refresh(db, instituteId, minIntervalMs, force = false)

    suspend fun forceRefresh(db: AppDatabase, instituteId: String): Boolean =
        refresh(db, instituteId, DEFAULT_MIN_INTERVAL_MS, force = true)

    private suspend fun refresh(
        db: AppDatabase,
        instituteId: String,
        minIntervalMs: Long,
        force: Boolean
    ): Boolean {
        if (instituteId.isBlank()) return false

        val request = refreshMutex.withLock {
            inFlightRefreshes[instituteId]?.let { return@withLock RefreshRequest(it, isOwner = false) }

            val now = System.currentTimeMillis()
            val last = lastRefreshAtMs[instituteId] ?: 0L
            if (!force && now - last < minIntervalMs) {
                null
            } else {
                val deferred = CompletableDeferred<Boolean>()
                inFlightRefreshes[instituteId] = deferred
                RefreshRequest(deferred, isOwner = true)
            }
        }

        if (request == null) return true
        if (!request.isOwner) return request.result.await()

        val result = try {
            CoreDataSyncCoordinator.refreshInstituteCache(db, instituteId)
        } catch (_: Throwable) {
            false
        }

        refreshMutex.withLock {
            inFlightRefreshes.remove(instituteId)
            if (result) {
                lastRefreshAtMs[instituteId] = System.currentTimeMillis()
            }
            request.result.complete(result)
        }
        return result
    }

    private data class RefreshRequest(
        val result: CompletableDeferred<Boolean>,
        val isOwner: Boolean
    )
}

