﻿package com.batchfee.edu.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "receipts")
data class ReceiptEntity(
    @PrimaryKey val id: String,
    val instituteId: String,
    val paymentId: String,
    val feeId: String,
    val studentId: String,
    val receiptNumber: String,
    val receiptDateMs: Long,
    val totalAmount: Double,
    val paidAmount: Double,
    val dueAmount: Double,
    val paymentMethod: String,
    val receiptText: String?,
    val createdAtMs: Long,
    // Additive transaction-time presentation snapshots.  Nullable keeps legacy
    // receipts readable without inventing historical values.
    val instituteNameSnapshot: String? = null,
    val instituteAddressSnapshot: String? = null,
    val institutePhoneSnapshot: String? = null,
    val instituteEmailSnapshot: String? = null,
    val instituteLogoUriSnapshot: String? = null,
    val studentNameSnapshot: String? = null,
    val studentCodeSnapshot: String? = null,
    val studentPhoneSnapshot: String? = null,
    val batchNameSnapshot: String? = null,
    val feePeriodSnapshot: String? = null,
    val feeTypeSnapshot: String? = null,
    val grossAmountSnapshot: Double? = null,
    val discountAmountSnapshot: Double? = null,
    val collectorNameSnapshot: String? = null,
    val collectorRoleSnapshot: String? = null,
    val collectorStaffCodeSnapshot: String? = null,
    val paymentReferenceSnapshot: String? = null,
    val paymentNoteSnapshot: String? = null,
    val paymentStatusSnapshot: String? = null
)

