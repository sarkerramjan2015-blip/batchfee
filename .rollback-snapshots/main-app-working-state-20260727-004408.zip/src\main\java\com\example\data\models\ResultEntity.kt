﻿package com.batchfee.edu.data.models

import androidx.room.Entity
import androidx.room.ColumnInfo
import androidx.room.PrimaryKey

@Entity(tableName = "results")
data class ResultEntity(
    @PrimaryKey val id: String,
    val instituteId: String,
    val examId: String,
    val batchId: String,
    val studentId: String,
    val marksObtained: Double,
    @ColumnInfo(defaultValue = "0") val isAbsent: Boolean = false,
    val grade: String?,
    val position: Int?,
    val remarks: String?,
    val published: Boolean,
    val createdAtMs: Long,
    val updatedAtMs: Long
)

