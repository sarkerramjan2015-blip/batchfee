﻿package com.batchfee.edu.data.repository

import androidx.room.withTransaction
import com.batchfee.edu.data.database.AppDatabase
import com.batchfee.edu.data.firestore.FinanceSyncHelper
import com.batchfee.edu.data.models.FeeEntity
import com.batchfee.edu.data.models.PaymentEntity
import com.batchfee.edu.data.models.ReceiptEntity
import java.util.UUID
import kotlin.math.abs
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class FeeCollectionResult(
    val paymentId: String,
    val receiptNumber: String,
    val updatedFee: FeeEntity
)

data class FeeCreationResult(
    val fee: FeeEntity,
    val paymentId: String? = null,
    val receiptNumber: String? = null
)

data class MonthlyFeeAllocationRequest(
    val feeId: String,
    val collectedAmount: Double,
    val discountPercent: Double = 0.0
)

data class MonthlyFeeAllocationResult(
    val feeId: String,
    val paymentId: String?,
    val receiptNumber: String?,
    val updatedFee: FeeEntity
)

class FeeCollectionRepository(private val db: AppDatabase) {
    private val monthlyAllocationMutex = Mutex()

    /**
     * Records a single collection action as exact fee-level allocations. It does
     * not move a payment to any unselected month.
     */
    suspend fun collectMonthlyAllocations(
        instituteId: String,
        collectedByUserId: String,
        studentId: String,
        allocations: List<MonthlyFeeAllocationRequest>,
        paymentMethod: String,
        paymentDateMs: Long = System.currentTimeMillis(),
        note: String? = null,
        transactionId: String? = null,
        now: Long = System.currentTimeMillis()
    ): List<MonthlyFeeAllocationResult> = monthlyAllocationMutex.withLock {
        require(allocations.isNotEmpty()) { "Select at least one fee month." }
        require(allocations.map { it.feeId }.distinct().size == allocations.size) { "A fee month was selected more than once." }
        db.withTransaction {
            // A collection action receives one receipt number. Each allocation
            // still creates its own payment/fee receipt row for ledger safety.
            val collectionReceiptNumber = "REC-$now"
            allocations.map { allocation ->
                require(allocation.collectedAmount >= 0.0) { "Collected amount cannot be negative." }
                require(allocation.discountPercent in 0.0..100.0) { "Discount must be between 0 and 100%." }
                val existing = db.feeDao().getFeeById(allocation.feeId, instituteId)
                    ?: throw IllegalArgumentException("Selected fee was not found.")
                require(existing.studentId == studentId) { "Selected fee belongs to a different student." }
                require(existing.cancelledAtMs == null) { "Selected fee is cancelled." }

                val adjusted = applySelectedDiscount(existing, allocation.discountPercent, now)
                val remaining = adjusted.dueAmount.coerceAtLeast(0.0)
                if (allocation.collectedAmount - remaining > EPSILON) {
                    throw IllegalArgumentException("Payment rejected - amount exceeds remaining due for ${adjusted.feePeriod}.")
                }
                if (allocation.collectedAmount <= EPSILON) {
                    if (remaining > EPSILON) {
                        throw IllegalArgumentException("Enter a payment amount or apply a full waiver for ${adjusted.feePeriod}.")
                    }
                    MonthlyFeeAllocationResult(adjusted.id, null, null, adjusted)
                } else {
                    val result = collectFromFee(
                        fee = adjusted,
                        instituteId = instituteId,
                        collectedByUserId = collectedByUserId,
                        amount = allocation.collectedAmount,
                        paymentMethod = paymentMethod,
                        paymentDateMs = paymentDateMs,
                        note = note,
                        transactionId = transactionId,
                        receiptText = "Monthly fee payment — ${adjusted.feePeriod}",
                        now = now,
                        receiptNumberOverride = collectionReceiptNumber
                    )
                    MonthlyFeeAllocationResult(result.updatedFee.id, result.paymentId, result.receiptNumber, result.updatedFee)
                }
            }
        }
    }

    suspend fun createFee(
        instituteId: String,
        studentId: String,
        batchId: String?,
        feePeriod: String,
        feeType: String,
        dueDateMs: Long,
        baseAmount: Double,
        discountAmount: Double,
        lateFeeAmount: Double,
        note: String? = null,
        now: Long = System.currentTimeMillis()
    ): FeeEntity = db.withTransaction {
        val totalAmount = calculateTotal(baseAmount, discountAmount, lateFeeAmount)
        val fee = FeeEntity(
            id = UUID.randomUUID().toString(),
            instituteId = instituteId,
            studentId = studentId,
            batchId = batchId,
            feePeriod = feePeriod,
            feeType = normalizeFeeType(feeType),
            dueDateMs = dueDateMs,
            baseAmount = baseAmount,
            discountAmount = discountAmount,
            lateFeeAmount = lateFeeAmount,
            totalAmount = totalAmount,
            paidAmount = 0.0,
            dueAmount = totalAmount,
            status = statusForNewFee(totalAmount),
            note = note,
            createdAtMs = now,
            updatedAtMs = now,
            cancelledAtMs = null
        )
        FinanceSyncHelper.upsertFee(fee)
        db.feeDao().insertFee(fee)
        fee
    }

    suspend fun createFeeWithInitialPayment(
        instituteId: String,
        collectedByUserId: String,
        studentId: String,
        batchId: String?,
        feePeriod: String,
        feeType: String,
        dueDateMs: Long,
        baseAmount: Double,
        discountAmount: Double,
        lateFeeAmount: Double,
        collectedAmount: Double,
        paymentMethod: String,
        paymentDateMs: Long,
        note: String?,
        receiptText: String?,
        now: Long = System.currentTimeMillis()
    ): FeeCreationResult = db.withTransaction {
        val totalAmount = calculateTotal(baseAmount, discountAmount, lateFeeAmount)
        if (collectedAmount < 0.0) {
            throw IllegalArgumentException("Collected amount cannot be negative.")
        }
        if (collectedAmount - totalAmount > EPSILON) {
            throw IllegalArgumentException("Payment rejected - amount exceeds remaining due.")
        }

        val fee = FeeEntity(
            id = UUID.randomUUID().toString(),
            instituteId = instituteId,
            studentId = studentId,
            batchId = batchId,
            feePeriod = feePeriod,
            feeType = normalizeFeeType(feeType),
            dueDateMs = dueDateMs,
            baseAmount = baseAmount,
            discountAmount = discountAmount,
            lateFeeAmount = lateFeeAmount,
            totalAmount = totalAmount,
            paidAmount = 0.0,
            dueAmount = totalAmount,
            status = statusForNewFee(totalAmount),
            note = note,
            createdAtMs = now,
            updatedAtMs = now,
            cancelledAtMs = null
        )
        FinanceSyncHelper.upsertFee(fee)
        db.feeDao().insertFee(fee)

        if (collectedAmount <= 0.0) {
            FeeCreationResult(fee = fee)
        } else {
            val result = collectFromFee(
                fee = fee,
                instituteId = instituteId,
                collectedByUserId = collectedByUserId,
                amount = collectedAmount,
                paymentMethod = paymentMethod,
                paymentDateMs = paymentDateMs,
                note = note,
                receiptText = receiptText,
                now = now
            )
            FeeCreationResult(
                fee = result.updatedFee,
                paymentId = result.paymentId,
                receiptNumber = result.receiptNumber
            )
        }
    }

    suspend fun collectPayment(
        instituteId: String,
        collectedByUserId: String,
        feeId: String,
        amount: Double,
        paymentMethod: String,
        paymentDateMs: Long = System.currentTimeMillis(),
        note: String? = null,
        transactionId: String? = null,
        receiptText: String? = null,
        now: Long = System.currentTimeMillis()
    ): FeeCollectionResult = db.withTransaction {
        val fee = db.feeDao().getFeeById(feeId, instituteId)
            ?: throw IllegalArgumentException("Fee not found.")
        collectFromFee(
            fee = fee,
            instituteId = instituteId,
            collectedByUserId = collectedByUserId,
            amount = amount,
            paymentMethod = paymentMethod,
            paymentDateMs = paymentDateMs,
            note = note,
            transactionId = transactionId,
            receiptText = receiptText,
            now = now
        )
    }

    suspend fun updateFeeAndCollectPayment(
        instituteId: String,
        collectedByUserId: String,
        feeId: String,
        newBaseAmount: Double,
        discountPercent: Double,
        collectedAmount: Double,
        paymentMethod: String,
        feePeriod: String,
        note: String? = null,
        now: Long = System.currentTimeMillis()
    ): FeeCollectionResult = db.withTransaction {
        val fee = db.feeDao().getFeeById(feeId, instituteId)
            ?: throw IllegalArgumentException("Fee not found.")
        if (fee.cancelledAtMs != null) {
            throw IllegalArgumentException("Fee is cancelled.")
        }
        if (newBaseAmount < 0.0) {
            throw IllegalArgumentException("Fee amount cannot be negative.")
        }
        if (discountPercent < 0.0 || discountPercent > 100.0) {
            throw IllegalArgumentException("Discount must be between 0 and 100%.")
        }

        val discountAmount = newBaseAmount * discountPercent / 100.0
        val totalAmount = calculateTotal(newBaseAmount, discountAmount, 0.0)
        if (totalAmount + EPSILON < fee.paidAmount) {
            throw IllegalArgumentException("Adjusted fee total cannot be less than already paid.")
        }
        val adjustedDue = (totalAmount - fee.paidAmount).coerceAtLeast(0.0)
        if (collectedAmount - adjustedDue > EPSILON) {
            throw IllegalArgumentException("Payment rejected - amount exceeds remaining due.")
        }

        val adjustedFee = fee.copy(
            baseAmount = newBaseAmount,
            discountAmount = discountAmount,
            lateFeeAmount = 0.0,
            totalAmount = totalAmount,
            feePeriod = feePeriod,
            dueAmount = adjustedDue,
            status = statusForAdjustedFee(adjustedDue, fee.paidAmount),
            updatedAtMs = now
        )
        FinanceSyncHelper.upsertFee(adjustedFee)
        db.feeDao().updateFee(adjustedFee)

        collectFromFee(
            fee = adjustedFee,
            instituteId = instituteId,
            collectedByUserId = collectedByUserId,
            amount = collectedAmount,
            paymentMethod = paymentMethod,
            paymentDateMs = now,
            note = note,
            receiptText = buildString {
                append("Receipt\n")
                append("Period: $feePeriod\n")
                append("Base: BDT $newBaseAmount\n")
                append("Discount (${discountPercent.toInt()}%): BDT ${"%.2f".format(discountAmount)}\n")
                append("Payable: BDT ${"%.2f".format(totalAmount)}\n")
                append("Collected Now: BDT ${"%.2f".format(collectedAmount)}")
            },
            now = now
        )
    }

    private suspend fun collectFromFee(
        fee: FeeEntity,
        instituteId: String,
        collectedByUserId: String,
        amount: Double,
        paymentMethod: String,
        paymentDateMs: Long,
        note: String?,
        transactionId: String? = null,
        receiptText: String?,
        now: Long,
        receiptNumberOverride: String? = null
    ): FeeCollectionResult {
        if (fee.cancelledAtMs != null) {
            throw IllegalArgumentException("Fee is cancelled.")
        }
        if (amount <= 0.0) {
            throw IllegalArgumentException("Amount must be greater than zero.")
        }
        val remainingDue = fee.dueAmount.coerceAtLeast(0.0)
        if (remainingDue <= EPSILON) {
            throw IllegalArgumentException("Fee already settled.")
        }
        if (amount - remainingDue > EPSILON) {
            throw IllegalArgumentException("Payment rejected - amount exceeds remaining due.")
        }

        val normalizedAmount = if (abs(remainingDue - amount) <= EPSILON) remainingDue else amount
        val newDue = (remainingDue - normalizedAmount).let { if (it <= EPSILON) 0.0 else it }
        val newPaid = if (newDue <= EPSILON) fee.totalAmount else fee.paidAmount + normalizedAmount
        val updatedFee = fee.copy(
            paidAmount = newPaid,
            dueAmount = newDue,
            status = statusAfterPayment(newDue),
            updatedAtMs = now
        )
        FinanceSyncHelper.upsertFee(updatedFee)
        db.feeDao().updateFee(updatedFee)

        val paymentId = UUID.randomUUID().toString()
        val receiptNumber = receiptNumberOverride ?: "REC-$now"
        val payment = PaymentEntity(
            id = paymentId,
            instituteId = instituteId,
            feeId = fee.id,
            studentId = fee.studentId,
            amount = normalizedAmount,
            paymentMethod = paymentMethod.lowercase(),
            transactionId = transactionId?.trim()?.takeIf { it.isNotEmpty() },
            receiptNumber = receiptNumber,
            paymentDateMs = paymentDateMs,
            collectedByUserId = collectedByUserId,
            status = "completed",
            note = note,
            createdAtMs = now,
            updatedAtMs = now
        )
        FinanceSyncHelper.upsertPayment(payment)
        db.paymentDao().insertPayment(payment)
        val receipt = createReceiptSnapshot(
            instituteId = instituteId,
            payment = payment,
            fee = updatedFee,
            receiptText = receiptText ?: "Payment of $normalizedAmount received.",
            now = now
        )
        FinanceSyncHelper.upsertReceipt(receipt)
        db.receiptDao().insertReceipt(receipt)
        return FeeCollectionResult(paymentId, receiptNumber, updatedFee)
    }

    /**
     * Captures presentation data once at collection time.  It never changes the
     * payment or fee ledger and all fields are optional so a receipt stays valid
     * even if a legacy/local profile record is unavailable.
     */
    private suspend fun createReceiptSnapshot(
        instituteId: String,
        payment: PaymentEntity,
        fee: FeeEntity,
        receiptText: String,
        now: Long
    ): ReceiptEntity {
        val institute = db.instituteDao().getInstitute(instituteId)
        val student = db.studentDao().getStudentById(payment.studentId, instituteId).firstOrNull()
        val batch = fee.batchId?.let { db.batchDao().getBatchById(it, instituteId).firstOrNull() }
        val collector = db.userDao().getUserById(payment.collectedByUserId)
        val staff = db.staffDao().getStaffByIdOnce(payment.collectedByUserId, instituteId)

        return ReceiptEntity(
            id = UUID.randomUUID().toString(),
            instituteId = instituteId,
            paymentId = payment.id,
            feeId = fee.id,
            studentId = payment.studentId,
            receiptNumber = payment.receiptNumber,
            receiptDateMs = payment.paymentDateMs,
            totalAmount = fee.totalAmount,
            paidAmount = fee.paidAmount,
            dueAmount = fee.dueAmount,
            paymentMethod = payment.paymentMethod,
            receiptText = receiptText,
            createdAtMs = now,
            instituteNameSnapshot = institute?.name?.takeIf { it.isNotBlank() },
            instituteAddressSnapshot = institute?.address?.takeIf { it.isNotBlank() },
            institutePhoneSnapshot = institute?.phone?.takeIf { it.isNotBlank() },
            instituteEmailSnapshot = institute?.email?.takeIf { it.isNotBlank() },
            instituteLogoUriSnapshot = institute?.profilePhotoUri?.takeIf { it.isNotBlank() },
            studentNameSnapshot = student?.fullName?.takeIf { it.isNotBlank() },
            studentCodeSnapshot = student?.studentCode?.takeIf { it.isNotBlank() },
            studentPhoneSnapshot = student?.phone?.takeIf { it.isNotBlank() }
                ?: student?.guardianPhone?.takeIf { it.isNotBlank() },
            batchNameSnapshot = batch?.name?.takeIf { it.isNotBlank() },
            feePeriodSnapshot = fee.feePeriod.takeIf { it.isNotBlank() },
            feeTypeSnapshot = fee.feeType.takeIf { it.isNotBlank() },
            grossAmountSnapshot = fee.baseAmount,
            discountAmountSnapshot = fee.discountAmount,
            collectorNameSnapshot = collector?.name?.takeIf { it.isNotBlank() }
                ?: staff?.fullName?.takeIf { it.isNotBlank() },
            collectorRoleSnapshot = collector?.role?.takeIf { it.isNotBlank() }
                ?: staff?.roleTitle?.takeIf { it.isNotBlank() },
            collectorStaffCodeSnapshot = staff?.staffCode?.takeIf { it.isNotBlank() },
            paymentReferenceSnapshot = payment.transactionId?.takeIf { it.isNotBlank() },
            paymentNoteSnapshot = payment.note?.takeIf { it.isNotBlank() },
            paymentStatusSnapshot = payment.status.takeIf { it.isNotBlank() }
        )
    }

    private fun calculateTotal(baseAmount: Double, discountAmount: Double, lateFeeAmount: Double): Double {
        if (baseAmount < 0.0) {
            throw IllegalArgumentException("Fee amount cannot be negative.")
        }
        if (discountAmount < 0.0 || lateFeeAmount < 0.0) {
            throw IllegalArgumentException("Discount and late fee cannot be negative.")
        }
        val total = baseAmount - discountAmount + lateFeeAmount
        if (total < -EPSILON) {
            throw IllegalArgumentException("Total fee cannot be negative.")
        }
        return total.coerceAtLeast(0.0)
    }

    private suspend fun applySelectedDiscount(fee: FeeEntity, discountPercent: Double, now: Long): FeeEntity {
        if (discountPercent <= 0.0) return fee
        val requestedDiscount = fee.baseAmount * discountPercent / 100.0
        // A later collection must never remove a discount previously granted.
        val effectiveDiscount = maxOf(fee.discountAmount, requestedDiscount)
        val totalAmount = calculateTotal(fee.baseAmount, effectiveDiscount, fee.lateFeeAmount)
        if (totalAmount + EPSILON < fee.paidAmount) {
            throw IllegalArgumentException("Discount cannot reduce ${fee.feePeriod} below its amount already paid.")
        }
        val updated = fee.copy(
            discountAmount = effectiveDiscount,
            totalAmount = totalAmount,
            dueAmount = (totalAmount - fee.paidAmount).coerceAtLeast(0.0),
            status = statusForAdjustedFee((totalAmount - fee.paidAmount).coerceAtLeast(0.0), fee.paidAmount),
            updatedAtMs = now
        )
        if (updated != fee) {
            FinanceSyncHelper.upsertFee(updated)
            db.feeDao().updateFee(updated)
        }
        return updated
    }

    private fun statusForNewFee(dueAmount: Double): String =
        if (dueAmount <= EPSILON) "paid" else "unpaid"

    private fun statusForAdjustedFee(dueAmount: Double, paidAmount: Double): String =
        when {
            dueAmount <= EPSILON -> "paid"
            paidAmount > EPSILON -> "partially_paid"
            else -> "unpaid"
        }

    private fun statusAfterPayment(dueAmount: Double): String =
        if (dueAmount <= EPSILON) "paid" else "partially_paid"

    private fun normalizeFeeType(feeType: String): String =
        feeType.trim().lowercase().ifBlank { "monthly_fee" }

    private companion object {
        const val EPSILON = 0.001
    }
}

