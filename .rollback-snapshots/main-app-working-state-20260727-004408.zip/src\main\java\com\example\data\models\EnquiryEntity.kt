﻿package com.batchfee.edu.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "enquiries")
data class EnquiryEntity(
    @PrimaryKey val id: String,
    val instituteId: String,
    val name: String,
    val phone: String,
    val address: String?,
    val subjectName: String,
    val enquiryDateMs: Long,
    val status: String,
    val createdAtMs: Long,
    val updatedAtMs: Long,
    val archivedAtMs: Long?,
    val followUpAtMs: Long? = null,
    val followUpType: String? = null,
    val followUpNote: String? = null,
    val priority: String = "normal",
    val assignedStaffId: String? = null,
    val source: String? = null,
    val convertedStudentId: String? = null,
    val convertedAtMs: Long? = null,
    val convertedByUserId: String? = null
)

