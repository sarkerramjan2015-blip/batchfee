package com.batchfee.edu

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.fragment.app.FragmentActivity
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.batchfee.edu.domain.AccessControl
import com.batchfee.edu.domain.FirebaseSessionMonitor
import com.batchfee.edu.domain.ForceUpdateChecker
import com.batchfee.edu.domain.PasswordHasher
import com.batchfee.edu.domain.SessionManager
import com.batchfee.edu.domain.SessionState
import com.batchfee.edu.domain.ThemePreferences
import com.batchfee.edu.ui.auth.AuthScreen
import com.batchfee.edu.ui.billing.BillingScreen
import com.batchfee.edu.ui.dashboard.DashboardScreen
import com.batchfee.edu.ui.legal.PrivacyPolicyScreen
import com.batchfee.edu.ui.legal.TermsConditionsScreen
import com.batchfee.edu.ui.navigation.*
import com.batchfee.edu.ui.pricing.PricingScreen
import com.batchfee.edu.ui.superadmin.SuperAdminScreen
import com.batchfee.edu.ui.subscription.SubscriptionExpiredScreen
import com.batchfee.edu.ui.theme.MyApplicationTheme
import com.batchfee.edu.ui.update.ForceUpdateScreen
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class MainActivity : FragmentActivity() {
    override fun onUserInteraction() {
        super.onUserInteraction()
        SessionManager.markActivity()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val appDb = (application as BatchFeeApp).database
        
        setContent {
            val darkMode by ThemePreferences.isDarkMode.collectAsState()
            MyApplicationTheme(darkTheme = darkMode ?: isSystemInDarkTheme()) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    var forceUpdate by remember { mutableStateOf<Int?>(null) }

                    // ── Force Update Check ──
                    if (forceUpdate != null) {
                        ForceUpdateScreen(requiredVersion = forceUpdate!!)
                    } else {
                        LaunchedEffect(Unit) {
                            val result = ForceUpdateChecker.check()
                            if (result is ForceUpdateChecker.UpdateResult.UpdateRequired) {
                                forceUpdate = result.requiredVersion
                            }
                        }

                        MainAppContent(appDb)
                    }
                }
            }
        }
    }
}

@Composable
private fun MainAppContent(appDb: com.batchfee.edu.data.database.AppDatabase) {
    val navController = rememberNavController()
    val lifecycleOwner = LocalLifecycleOwner.current
    val sessionState by SessionManager.sessionState.collectAsState()
    val isLoggedIn by SessionManager.currentUserId.collectAsState()
    val sessionSnackbarHostState = remember { SnackbarHostState() }
    val lastActivityAtMs by SessionManager.lastActivityAtMs.collectAsState()
    val sessionScope = rememberCoroutineScope()
    val sessionMonitor = remember {
        FirebaseSessionMonitor(FirebaseAuth.getInstance(), sessionScope, appDb)
    }

    DisposableEffect(sessionMonitor) {
        sessionMonitor.start()
        onDispose { sessionMonitor.stop() }
    }

    LaunchedEffect(sessionMonitor) {
        sessionMonitor.restoreSession()
    }

    // This root host survives Login destination recreation while the protected
    // graph is cleared. The notice is consumed only after it becomes visible.
    LaunchedEffect(Unit) {
        SessionManager.sessionNotice.collect { notice ->
            if (notice == null) return@collect
            launch {
                sessionSnackbarHostState.showSnackbar(
                    message = notice,
                    duration = SnackbarDuration.Long
                )
            }
            snapshotFlow { sessionSnackbarHostState.currentSnackbarData }
                .first { it?.visuals?.message == notice }
            withFrameNanos { }
            SessionManager.consumeSessionNotice(notice)
        }
    }

    // Protected destinations are reachable only while the authoritative
    // session state is confirmed authenticated. This also clears the back stack.
    LaunchedEffect(sessionState) {
        if (sessionState is SessionState.Unauthenticated || sessionState is SessionState.SessionExpired) {
            if (sessionState is SessionState.SessionExpired) {
                FirebaseAuth.getInstance().signOut()
            }
            navController.navigate(AuthRoute) {
                popUpTo(navController.graph.id) { inclusive = true }
            }
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && SessionManager.isLoggedIn()) {
                if (SessionManager.isSessionInactive()) {
                    sessionMonitor.expireSession()
                } else {
                    SessionManager.markActivity()
                    sessionMonitor.validateOnResume()
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(isLoggedIn) {
        val uid = isLoggedIn ?: return@LaunchedEffect
        val role = SessionManager.currentUserRole.value ?: return@LaunchedEffect
        if (role == "SuperAdmin") return@LaunchedEffect
        withContext(Dispatchers.IO) {
            try {
                FirebaseFirestore.getInstance()
                    .collection("institutes").document(uid)
                    .update("lastActiveAt", System.currentTimeMillis())
                    .await()
            } catch (e: Exception) {
                FirebaseCrashlytics.getInstance().recordException(e)
            }
        }
        while (true) {
            delay(5 * 60 * 1000L)
            if (SessionManager.currentUserId.value != uid) break
            withContext(Dispatchers.IO) {
                try {
                    FirebaseFirestore.getInstance()
                        .collection("institutes").document(uid)
                        .update("lastActiveAt", System.currentTimeMillis())
                        .await()
                } catch (e: Exception) {
                    FirebaseCrashlytics.getInstance().recordException(e)
                }
            }
        }
    }

    LaunchedEffect(isLoggedIn, lastActivityAtMs) {
        val activeUserId = isLoggedIn ?: return@LaunchedEffect
        val elapsedMs = System.currentTimeMillis() - lastActivityAtMs
        val remainingMs = (SessionManager.SESSION_TIMEOUT_MS - elapsedMs).coerceAtLeast(0)
        delay(remainingMs)
        if (SessionManager.currentUserId.value == activeUserId && SessionManager.isSessionInactive()) {
            sessionMonitor.expireSession()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
    NavHost(navController = navController, startDestination = AuthRoute) {
        composable<AuthRoute> {
            val scope = rememberCoroutineScope()
            AuthScreen(
                db = appDb,
                onNavigateDashboard = {
                    scope.launch {
                        val instituteId = SessionManager.currentInstituteId.value
                        val role = SessionManager.currentUserRole.value
                        if (role != "SuperAdmin" && instituteId != null) {
                            val isExpired = checkSubscriptionExpired(instituteId)
                            if (isExpired) {
                                navController.navigate(SubscriptionExpiredRoute) {
                                    popUpTo(navController.graph.id) { inclusive = true }
                                }
                                return@launch
                            }
                        }
                        navController.navigate(DashboardRoute) {
                            popUpTo(navController.graph.id) { inclusive = true }
                        }
                    }
                },
                onNavigateSuperAdmin = {
                    navController.navigate(SuperAdminRoute) {
                        popUpTo(navController.graph.id) { inclusive = true }
                    }
                },
                onNavigatePrivacyPolicy = {
                    navController.navigate(PrivacyPolicyRoute)
                },
                onNavigateTermsConditions = {
                    navController.navigate(TermsConditionsRoute)
                }
            )
        }

        composable<PrivacyPolicyRoute> {
            PrivacyPolicyScreen(onBack = { navController.popBackStack() })
        }

        composable<TermsConditionsRoute> {
            TermsConditionsScreen(onBack = { navController.popBackStack() })
        }
        
        composable<DashboardRoute> {
            var currentTab by remember { mutableStateOf("DashboardRoute") }
            com.batchfee.edu.ui.dashboard.DashboardTabsScreen(
                db = appDb,
                currentRoute = currentTab,
                onNavigate = navigate@ { route ->
                    if (route == "DashboardRoute" || route == "More") {
                        currentTab = route
                    } else {
                        if (!AccessControl.canAccessRoute(route)) return@navigate
                        when (route) {
                            "StudentsRoute" -> navController.navigate(StudentsRoute)
                            "AddStudentRoute" -> navController.navigate(AddStudentRoute)
                            "BatchesRoute" -> navController.navigate(BatchesRoute)
                            "AddBatchRoute" -> navController.navigate(AddBatchRoute)
                            "FeeDashboardRoute" -> navController.navigate(FeeDashboardRoute)
                            "DueFeesRoute" -> navController.navigate(DueFeesRoute)
                            "CreateFeeRoute" -> navController.navigate(CreateFeeRoute)
                            "UnifiedCollectRoute" -> navController.navigate(UnifiedCollectRoute)
                            "AttendanceRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.AttendanceRoute)
                            "AttendanceReportRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.AttendanceReportRoute)
                            "ReportsRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.ReportsRoute)
                            "ReminderTemplatesRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.ReminderTemplatesRoute)
                            "StaffRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.StaffRoute)
                            "AddStaffRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.AddStaffRoute)
                            "StaffAttendanceRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.StaffAttendanceRoute)
                            "SalaryRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.SalaryRoute)
                            "ExpensesRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.ExpensesRoute)
                            "AddExpenseRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.AddExpenseRoute)
                            "ProfitLossRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.ProfitLossRoute)
                            "ExamsRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.ExamsRoute)
                            "CreateExamRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.CreateExamRoute)
                            "IdCardGeneratorRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.IdCardGeneratorRoute)
                            "BirthdayReminderRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.BirthdayReminderRoute)
                            "SettingsRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.SettingsRoute)
                            "EnquiryListRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.EnquiryListRoute)
                            else -> {
                                if (route.startsWith("TakeAttendanceRoute:")) {
                                    route.substringAfter(":").takeIf { it.isNotBlank() }?.let { batchId ->
                                        navController.navigate(TakeAttendanceRoute(batchId))
                                    }
                                }
                            }
                        }
                    }
                },
                onNavigatePricing = { navController.navigate(PricingRoute) },
                onNavigateBilling = { navController.navigate(BillingRoute) },
                onLogout = {
                    sessionMonitor.logout()
                    navController.navigate(AuthRoute) {
                        popUpTo(navController.graph.id) { inclusive = true }
                    }
                }
            )
        }
        
        composable<StudentsRoute> {
            com.batchfee.edu.ui.students.StudentListScreen(
                db = appDb,
                onBack = { navController.popBackStack() },
                onAddStudent = { navController.navigate(AddStudentRoute) },
                onNavigateToProfile = { studentId -> navController.navigate(StudentProfileRoute(studentId)) },
                onNavigateToIdCards = { navController.navigate(IdCardGeneratorRoute) }
            )
        }
        
        composable<AddStudentRoute> {
            com.batchfee.edu.ui.students.AddEditStudentScreen(db = appDb, onBack = { navController.popBackStack() })
        }

        composable<EditStudentRoute> { backStackEntry ->
            val route = backStackEntry.toRoute<EditStudentRoute>()
            com.batchfee.edu.ui.students.AddEditStudentScreen(
                db = appDb,
                studentId = route.studentId,
                onBack = { navController.popBackStack() }
            )
        }
        
        composable<StudentProfileRoute> { backStackEntry ->
            val route = backStackEntry.toRoute<StudentProfileRoute>()
            com.batchfee.edu.ui.students.StudentProfileScreen(
                db = appDb,
                studentId = route.studentId,
                onBack = { navController.popBackStack() },
                onEdit = { navController.navigate(EditStudentRoute(route.studentId)) },
                onGenerateIdCard = { navController.navigate(IdCardPreviewRoute("student", route.studentId)) }
            )
        }
        
        composable<BatchesRoute> {
            com.batchfee.edu.ui.batches.BatchListScreen(
                db = appDb,
                onBack = { navController.popBackStack() },
                onAddBatch = { navController.navigate(AddBatchRoute) },
                onNavigateToBatch = { batchId -> navController.navigate(BatchDetailRoute(batchId)) }
            )
        }
        
        composable<AddBatchRoute> {
            com.batchfee.edu.ui.batches.AddEditBatchScreen(db = appDb, onBack = { navController.popBackStack() })
        }

        composable<EditBatchRoute> { backStackEntry ->
            val route = backStackEntry.toRoute<EditBatchRoute>()
            com.batchfee.edu.ui.batches.AddEditBatchScreen(
                db = appDb,
                batchId = route.batchId,
                onBack = { navController.popBackStack() }
            )
        }
        
        composable<BatchDetailRoute> { backStackEntry ->
            val route = backStackEntry.toRoute<BatchDetailRoute>()
            com.batchfee.edu.ui.batches.BatchDetailScreen(
                db = appDb,
                batchId = route.batchId,
                onBack = { navController.popBackStack() },
                onEdit = { navController.navigate(EditBatchRoute(route.batchId)) },
                onEnroll = { navController.navigate(EnrollStudentsRoute(route.batchId)) }
            )
        }
        
        composable<EnrollStudentsRoute> { backStackEntry ->
            val route = backStackEntry.toRoute<EnrollStudentsRoute>()
            com.batchfee.edu.ui.batches.EnrollStudentsScreen(
                db = appDb,
                batchId = route.batchId,
                onBack = { navController.popBackStack() }
            )
        }
        
        composable<FeeDashboardRoute> {
            com.batchfee.edu.ui.fees.FeeDashboardScreen(
                db = appDb,
                onBack = { navController.popBackStack() },
                onNavigateDueFees = { navController.navigate(UnifiedCollectRoute) },
                onCreateFee = { navController.navigate(CreateFeeRoute) },
                onCollectPayment = { feeId -> navController.navigate(CollectPaymentRoute(feeId)) }
            )
        }
        
        composable<CreateFeeRoute> {
            com.batchfee.edu.ui.fees.CreateFeeScreen(db = appDb, onBack = { navController.popBackStack() })
        }
        
        composable<DueFeesRoute> {
            com.batchfee.edu.ui.fees.DueFeeListScreen(
                db = appDb,
                onBack = { navController.popBackStack() }
            )
        }
        
        composable<CollectPaymentRoute> { backStackEntry ->
            val route = backStackEntry.toRoute<CollectPaymentRoute>()
            com.batchfee.edu.ui.fees.CollectPaymentScreen(
                db = appDb,
                feeId = route.feeId,
                onBack = { navController.popBackStack() },
                onNavigateReceipt = { paymentId -> 
                    navController.popBackStack()
                    navController.navigate(ReceiptDetailRoute(paymentId))
                }
            )
        }
        
        composable<ReceiptDetailRoute> { backStackEntry ->
            val route = backStackEntry.toRoute<ReceiptDetailRoute>()
            com.batchfee.edu.ui.fees.ReceiptDetailScreen(db = appDb, paymentId = route.paymentId, onBack = { navController.popBackStack() })
        }
        
        composable<UnifiedCollectRoute> {
            com.batchfee.edu.ui.fees.UnifiedCollectScreen(
                db = appDb,
                onBack = { navController.popBackStack() },
                onCollectPayment = { feeId -> navController.navigate(CollectPaymentRoute(feeId)) }
            )
        }
        
        composable<ReportsRoute> {
            com.batchfee.edu.ui.reports.ReportsScreen(db = appDb, onBack = { navController.popBackStack() })
        }
        
        composable<ReminderTemplatesRoute> {
            com.batchfee.edu.ui.reminders.ReminderTemplatesScreen(db = appDb, onBack = { navController.popBackStack() })
        }
        
        composable<AttendanceRoute> {
            com.batchfee.edu.ui.attendance.AttendanceBatchSelectScreen(
                db = appDb,
                onBack = { navController.popBackStack() },
                onSelectBatch = { batchId -> navController.navigate(TakeAttendanceRoute(batchId)) }
            )
        }
        
        composable<TakeAttendanceRoute> { backStackEntry ->
            val route = backStackEntry.toRoute<TakeAttendanceRoute>()
            com.batchfee.edu.ui.attendance.TakeAttendanceScreen(db = appDb, batchId = route.batchId, onBack = { navController.popBackStack() })
        }
        
        composable<AttendanceReportRoute> {
            com.batchfee.edu.ui.attendance.AttendanceReportScreen(db = appDb, onBack = { navController.popBackStack() })
        }
        
        composable<StaffRoute> {
            com.batchfee.edu.ui.staff.StaffListScreen(
                db = appDb,
                onBack = { navController.popBackStack() },
                onAddStaff = { navController.navigate(AddStaffRoute) },
                onNavigateToProfile = { id -> navController.navigate(StaffProfileRoute(id)) },
                onNavigateToPricing = { navController.navigate(PricingRoute) }
            )
        }
        
        composable<AddStaffRoute> {
            val staffId = runCatching {
                navController.previousBackStackEntry
                    ?.toRoute<StaffProfileRoute>()
                    ?.staffId
            }.getOrNull()
            com.batchfee.edu.ui.staff.AddEditStaffScreen(
                db = appDb,
                staffId = staffId,
                onBack = { navController.popBackStack() }
            )
        }

        composable<EditStaffRoute> { backStackEntry ->
            val route = backStackEntry.toRoute<EditStaffRoute>()
            com.batchfee.edu.ui.staff.AddEditStaffScreen(
                db = appDb,
                staffId = route.staffId,
                onBack = { navController.popBackStack() }
            )
        }
        
        composable<StaffProfileRoute> { backStackEntry ->
            val route = backStackEntry.toRoute<StaffProfileRoute>()
            com.batchfee.edu.ui.staff.StaffProfileScreen(
                db = appDb,
                staffId = route.staffId,
                onBack = { navController.popBackStack() },
                onEdit = { navController.navigate(EditStaffRoute(route.staffId)) }
            )
        }

        composable<StaffAttendanceRoute> {
            com.batchfee.edu.ui.staff.StaffAttendanceScreen(
                db = appDb,
                onBack = { navController.popBackStack() }
            )
        }

        composable<StaffAttendanceReportRoute> {
            com.batchfee.edu.ui.staff.StaffAttendanceScreen(
                db = appDb,
                onBack = { navController.popBackStack() }
            )
        }
        
        composable<SalaryRoute> {
            com.batchfee.edu.ui.staff.SalaryDashboardScreen(
                db = appDb,
                onBack = { navController.popBackStack() },
                onGenerate = { navController.navigate(GenerateSalaryRoute) },
                onNavigateToPricing = { navController.navigate(PricingRoute) }
            )
        }
        
        composable<GenerateSalaryRoute> {
            com.batchfee.edu.ui.staff.GenerateSalaryScreen(db = appDb, onBack = { navController.popBackStack() })
        }
        
        composable<ExpensesRoute> {
            com.batchfee.edu.ui.expenses.ExpenseListScreen(
                db = appDb,
                onBack = { navController.popBackStack() },
                onAddExpense = { navController.navigate(AddExpenseRoute) },
                onNavigateToPricing = { navController.navigate(PricingRoute) }
            )
        }
        
        composable<AddExpenseRoute> {
            com.batchfee.edu.ui.expenses.AddEditExpenseScreen(db = appDb, onBack = { navController.popBackStack() })
        }
        
        composable<ProfitLossRoute> {
            com.batchfee.edu.ui.reports.ProfitLossScreen(db = appDb, onBack = { navController.popBackStack() }, onNavigateToPricing = { navController.navigate(PricingRoute) })
        }
        
        composable<ExamsRoute> {
            com.batchfee.edu.ui.exams.ExamListScreen(
                db = appDb,
                onBack = { navController.popBackStack() },
                onAddExam = { navController.navigate(CreateExamRoute) },
                onNavigateToDetail = { examId -> navController.navigate(ExamDetailRoute(examId)) },
                onNavigateToPricing = { navController.navigate(PricingRoute) }
            )
        }
        
        composable<CreateExamRoute> {
            com.batchfee.edu.ui.exams.AddEditExamScreen(db = appDb, onBack = { navController.popBackStack() })
        }

        composable<EditExamRoute> { backStackEntry ->
            val route = backStackEntry.toRoute<EditExamRoute>()
            com.batchfee.edu.ui.exams.AddEditExamScreen(
                db = appDb,
                examId = route.examId,
                onBack = { navController.popBackStack() }
            )
        }

        composable<ExamDetailRoute> { backStackEntry ->
            val route = backStackEntry.toRoute<ExamDetailRoute>()
            com.batchfee.edu.ui.exams.ExamDetailScreen(
                db = appDb,
                examId = route.examId,
                onBack = { navController.popBackStack() },
                onEdit = { navController.navigate(EditExamRoute(route.examId)) }
            )
        }
        
        composable<IdCardGeneratorRoute> {
            com.batchfee.edu.ui.students.IdCardGeneratorScreen(
                db = appDb,
                onBack = { navController.popBackStack() },
                onNavigateToPreview = { type, id -> navController.navigate(IdCardPreviewRoute(type, id)) },
                onNavigateToPricing = { navController.navigate(PricingRoute) }
            )
        }
        
        composable<IdCardPreviewRoute> { backStackEntry ->
            val route = backStackEntry.toRoute<IdCardPreviewRoute>()
            com.batchfee.edu.ui.students.IdCardPreviewScreen(db = appDb, type = route.type, studentId = route.id, onBack = { navController.popBackStack() })
        }
        
        composable<BirthdayReminderRoute> {
            com.batchfee.edu.ui.students.BirthdayReminderScreen(db = appDb, onBack = { navController.popBackStack() }, onNavigateToPricing = { navController.navigate(PricingRoute) })
        }
        
        composable<EnquiryListRoute> {
            com.batchfee.edu.ui.enquiries.EnquiryListScreen(
                db = appDb,
                onBack = { navController.popBackStack() },
                onAddEnquiry = { /* handled in screen */ },
                onConvertToStudent = { enquiry ->
                    com.batchfee.edu.domain.EnquiryConversionDraft.pending.value = enquiry
                    navController.navigate(AddStudentRoute)
                }
            )
        }

        composable<BackupRestoreRoute> {
            com.batchfee.edu.ui.dashboard.BackupRestoreScreen(onBack = { navController.popBackStack() }, onNavigateToPricing = { navController.navigate(PricingRoute) })
        }
        
        composable<SettingsRoute> {
            com.batchfee.edu.ui.dashboard.SettingsScreen(
                db = appDb,
                onBack = { navController.popBackStack() },
                onNavigate = { routeStr ->
                    when(routeStr) {
                        "BillingRoute" -> navController.navigate(BillingRoute)
                        "ReminderTemplatesRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.ReminderTemplatesRoute)
                        "BackupRestoreRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.BackupRestoreRoute)
                        "StudentRegistrationRoute" -> navController.navigate(com.batchfee.edu.ui.navigation.StudentRegistrationRoute)
                    }
                }
            )
        }
        
        composable<StudentRegistrationRoute> {
            com.batchfee.edu.ui.registrations.RegistrationListScreen(
                db = appDb,
                onBack = { navController.popBackStack() }
            )
        }
        
        composable<PricingRoute> {
            PricingScreen(
                db = appDb,
                onBack = { navController.popBackStack() },
                onSubscribe = { planId ->
                    navController.popBackStack()
                }
            )
        }
        
        composable<BillingRoute> {
            BillingScreen(
                db = appDb,
                onBack = { navController.popBackStack() },
                onUpgrade = { navController.navigate(PricingRoute) }
            )
        }
        
        composable<SuperAdminRoute> {
            SuperAdminScreen(
                db = appDb,
                onLogout = {
                    sessionMonitor.logout()
                    navController.navigate(AuthRoute) {
                        popUpTo(navController.graph.id) { inclusive = true }
                    }
                }
            )
        }

        composable<SubscriptionExpiredRoute> {
            SubscriptionExpiredScreen(
                db = appDb,
                onRenew = {
                    navController.navigate(PricingRoute)
                },
                onLogout = {
                    sessionMonitor.logout()
                    navController.navigate(AuthRoute) {
                        popUpTo(navController.graph.id) { inclusive = true }
                    }
                }
            )
        }
    }
        SnackbarHost(
            hostState = sessionSnackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        )
    }
}

private suspend fun checkSubscriptionExpired(instituteId: String): Boolean {
    return try {
        val doc = FirebaseFirestore.getInstance()
            .collection("institutes").document(instituteId)
            .get().await()
        val isActive = doc.getBoolean("isActive") ?: true
        if (!isActive) return true
        val trialEnd = doc.getLong("trialEndDate") ?: return false
        System.currentTimeMillis() > trialEnd
    } catch (e: Exception) {
        FirebaseCrashlytics.getInstance().recordException(e)
        false
    }
}

