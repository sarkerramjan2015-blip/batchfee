package com.batchfee.edu.ui.fees

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.batchfee.edu.data.database.AppDatabase
import com.batchfee.edu.data.firestore.InstituteCacheRefreshManager
import com.batchfee.edu.data.models.BatchEntity
import com.batchfee.edu.data.models.FeeEntity
import com.batchfee.edu.data.models.InstituteEntity
import com.batchfee.edu.data.models.ReceiptEntity
import com.batchfee.edu.data.models.StudentEntity
import com.batchfee.edu.domain.ReceiptDocument
import com.batchfee.edu.domain.ReceiptPresentation
import com.batchfee.edu.domain.SessionManager
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.util.Calendar
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ── Premium palette (matching other polished screens) ───────────
private val BgColor      = Color(0xFF07111F)
private val CardBg        = Color(0xFF0F172A)
private val CardBgAlt     = Color(0xFF111827)
private val BorderSub     = Color(0xFF1E293B)
private val Cyan          = Color(0xFF22D3EE)
private val ElectricBlue  = Color(0xFF3B82F6)
private val TextWhite     = Color(0xFFF8FAFC)
private val TextMuted     = Color(0xFF94A3B8)
private val AccentRed     = Color(0xFFEF4444)
private val AccentGreen   = Color(0xFF10B981)

// polish: shared text field colors for dark theme inputs
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun premiumTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextWhite,
    unfocusedTextColor = TextWhite,
    focusedBorderColor = ElectricBlue,
    unfocusedBorderColor = BorderSub,
    focusedContainerColor = CardBgAlt,
    unfocusedContainerColor = CardBgAlt,
    cursorColor = Cyan,
    focusedLabelColor = Cyan,
    unfocusedLabelColor = TextMuted
)

@Composable
private fun SectionLabel(text: String) {
    Text(
        text, color = TextMuted, fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp
    )
}

// ── Helper: Month/Year data ─────────────────────────────────────
private data class MonthYear(val month: Int, val year: Int, val label: String)

private fun generateMonthOptions(): List<MonthYear> {
    val names = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    val calendar = Calendar.getInstance()
    return (-12..1).map { offset ->
        val c = (calendar.clone() as Calendar).apply { add(Calendar.MONTH, offset) }
        val month = c.get(Calendar.MONTH) + 1
        val year = c.get(Calendar.YEAR)
        MonthYear(month, year, "${names[month - 1]} $year")
    }
}

private fun parseFeePeriod(period: String): Pair<Int, Int>? {
    val names = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    val parts = period.trim().split("\\s+".toRegex())
    if (parts.size < 2) return null
    val monthIdx = names.indexOfFirst { parts[0].startsWith(it, ignoreCase = true) }
    if (monthIdx < 0) return null
    val year = parts[1].takeWhile { it.isDigit() }.toIntOrNull() ?: return null
    return Pair(monthIdx, year)
}

// ── Helper: Image processing ────────────────────────────────────
private fun compressAndResizeBitmap(context: Context, uri: Uri, maxSize: Int = 800): Bitmap? {
    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    var sample = 1
    while (opts.outWidth / sample > maxSize || opts.outHeight / sample > maxSize) sample *= 2
    val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sample }
    val bmp = context.contentResolver.openInputStream(uri)?.use {
        BitmapFactory.decodeStream(it, null, decodeOpts)
    } ?: return null
    val scale = minOf(maxSize.toFloat() / bmp.width, maxSize.toFloat() / bmp.height, 1f)
    return if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
}

// ── Helper: PDF receipt generation ───────────────────────────────
private fun generatePdfReceipt(
    context: Context,
    receiptNumber: String,
    studentName: String,
    batchName: String,
    feePeriod: String,
    baseAmount: Double,
    discountPercent: Double,
    discountAmount: Double,
    payableAmount: Double,
    totalPaid: Double,
    dueAmount: Double,
    collectedAmount: Double,
    paymentMethod: String
): Uri {
    val doc = PdfDocument()
    val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
    val c = page.canvas
    c.drawColor(android.graphics.Color.WHITE)

    // Header bar
    c.drawRect(0f, 0f, 595f, 80f, Paint().apply { color = android.graphics.Color.parseColor("#0F172A") })
    c.drawText("PAYMENT RECEIPT", 30f, 52f, Paint().apply {
        color = android.graphics.Color.WHITE; textSize = 28f
        typeface = Typeface.DEFAULT_BOLD; isAntiAlias = true
    })

    val sub = Paint().apply { color = android.graphics.Color.parseColor("#22D3EE"); textSize = 16f; isAntiAlias = true }
    c.drawText("Receipt #: $receiptNumber", 30f, 110f, sub)

    val lbl = Paint().apply { color = android.graphics.Color.parseColor("#64748B"); textSize = 14f; isAntiAlias = true }
    val vlu = Paint().apply { color = android.graphics.Color.parseColor("#0F172A"); textSize = 16f; typeface = Typeface.DEFAULT_BOLD; isAntiAlias = true }
    val nrm = Paint().apply { color = android.graphics.Color.parseColor("#0F172A"); textSize = 14f; isAntiAlias = true }
    val div = Paint().apply { color = android.graphics.Color.parseColor("#E2E8F0"); strokeWidth = 1f }

    var y = 150f; val lh = 28f; val c1 = 30f; val c2 = 200f
    for ((label, value) in listOf(
        "Student" to studentName, "Batch" to batchName, "Fee Period" to feePeriod
    )) { c.drawText(label, c1, y, lbl); c.drawText(value, c2, y, nrm); y += lh }
    y += 10f; c.drawLine(c1, y, 565f, y, div); y += 20f

    for ((label, value) in listOf(
        "Base Amount" to "BDT ${"%.2f".format(baseAmount)}",
        "Discount (${discountPercent.toInt()}%)" to "- BDT ${"%.2f".format(discountAmount)}",
    )) { c.drawText(label, c1, y, lbl); c.drawText(value, c2, y, nrm); y += lh }
    c.drawText("Payable Amount", c1, y, lbl)
    c.drawText("BDT ${"%.2f".format(payableAmount)}", c2, y, vlu); y += lh + 10f
    c.drawLine(c1, y, 565f, y, div); y += 20f

    c.drawText("Total Paid", c1, y, lbl); c.drawText("BDT ${"%.2f".format(totalPaid)}", c2, y, nrm); y += lh
    c.drawText("Due Amount", c1, y, lbl); c.drawText("BDT ${"%.2f".format(dueAmount)}", c2, y, nrm); y += lh
    c.drawText("Collected Now", c1, y, lbl)
    c.drawText("BDT ${"%.2f".format(collectedAmount)}", c2, y, Paint().apply {
        color = android.graphics.Color.parseColor("#22D3EE"); textSize = 16f; typeface = Typeface.DEFAULT_BOLD; isAntiAlias = true
    }); y += lh + 10f
    c.drawLine(c1, y, 565f, y, div); y += 20f

    c.drawText("Payment Method", c1, y, lbl); c.drawText(paymentMethod.uppercase(), c2, y, nrm); y += lh
    c.drawText("Date", c1, y, lbl); c.drawText(SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date()), c2, y, nrm)

    c.drawText("Generated by BatchFee", 297.5f, 820f, Paint().apply {
        color = android.graphics.Color.parseColor("#94A3B8"); textSize = 11f; isAntiAlias = true; textAlign = Paint.Align.CENTER
    })

    doc.finishPage(page)
    val file = File(context.cacheDir, "receipt_${receiptNumber.replace("/", "_")}.pdf")
    FileOutputStream(file).use { doc.writeTo(it) }
    doc.close()
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}

// ── Helper: Receipt bitmap for sharing ───────────────────────────
private fun createReceiptBitmap(
    context: Context,
    receiptNumber: String, studentName: String, batchName: String, feePeriod: String,
    payableAmount: Double, collectedAmount: Double, dueAmount: Double, paymentMethod: String,
    instituteName: String,
    instituteLogoUri: String?
): Bitmap {
    val w = 800; val h = 900
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    c.drawColor(android.graphics.Color.WHITE)

    val logo = loadBitmapFromUri(context, instituteLogoUri)
    c.drawRect(0f, 0f, w.toFloat(), 120f, Paint().apply { color = android.graphics.Color.parseColor("#0F172A") })
    if (logo != null) {
        val scaled = Bitmap.createScaledBitmap(logo, 72, 72, true)
        c.drawBitmap(scaled, 30f, 24f, Paint(Paint.ANTI_ALIAS_FLAG))
    } else {
        c.drawCircle(66f, 60f, 36f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.parseColor("#22D3EE") })
        c.drawText(instituteName.take(1).uppercase(), 50f, 76f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.parseColor("#0F172A")
            textSize = 34f
            typeface = Typeface.DEFAULT_BOLD
        })
    }
    c.drawText(instituteName, 120f, 56f, Paint().apply {
        color = android.graphics.Color.WHITE; textSize = 30f; typeface = Typeface.DEFAULT_BOLD; isAntiAlias = true
    })
    c.drawText("PAYMENT RECEIPT", 120f, 90f, Paint().apply {
        color = android.graphics.Color.WHITE; textSize = 36f; typeface = Typeface.DEFAULT_BOLD; isAntiAlias = true
    })

    val lbl = Paint().apply { color = android.graphics.Color.parseColor("#64748B"); textSize = 22f; isAntiAlias = true }
    val vlu = Paint().apply { color = android.graphics.Color.parseColor("#0F172A"); textSize = 24f; typeface = Typeface.DEFAULT_BOLD; isAntiAlias = true }
    val div = Paint().apply { color = android.graphics.Color.parseColor("#E2E8F0"); strokeWidth = 2f }

    var y = 150f; val lh = 40f; val c1 = 30f; val c2 = 250f
    for ((label, value) in listOf(
        "Receipt" to receiptNumber, "Student" to studentName, "Batch" to batchName, "Period" to feePeriod
    )) { c.drawText(label, c1, y, lbl); c.drawText(value, c2, y, vlu); y += lh }
    y += 20f; c.drawLine(c1, y, 770f, y, div); y += 30f

    c.drawText("Payable", c1, y, lbl); c.drawText("BDT ${"%.0f".format(payableAmount)}", c2, y, vlu); y += lh
    c.drawText("Collected", c1, y, lbl)
    c.drawText("BDT ${"%.0f".format(collectedAmount)}", c2, y, Paint().apply {
        color = android.graphics.Color.parseColor("#22D3EE"); textSize = 28f; typeface = Typeface.DEFAULT_BOLD; isAntiAlias = true
    }); y += lh
    c.drawText("Due", c1, y, lbl); c.drawText("BDT ${"%.0f".format(dueAmount)}", c2, y, vlu); y += lh + 20f
    c.drawLine(c1, y, 770f, y, div); y += 30f
    c.drawText("Method", c1, y, lbl); c.drawText(paymentMethod.uppercase(), c2, y, vlu); y += lh
    c.drawText("Date", c1, y, lbl); c.drawText(SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date()), c2, y, vlu)

    c.drawText("BatchFee", 400f, 860f, Paint().apply {
        color = android.graphics.Color.parseColor("#94A3B8"); textSize = 18f; isAntiAlias = true; textAlign = Paint.Align.CENTER
    })
    return bmp
}

/** Produces a document bitmap, never a screenshot of the app chrome. */
internal fun createReceiptDocumentBitmap(context: Context, receipt: ReceiptDocument): Bitmap {
    val width = 900
    val height = maxOf(1_720, 1_520 + receipt.allocations.size * 40)
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val ink = android.graphics.Color.parseColor("#0F172A")
    val muted = android.graphics.Color.parseColor("#64748B")
    val line = android.graphics.Color.parseColor("#E2E8F0")
    val blue = android.graphics.Color.parseColor("#2563EB")
    val cyan = android.graphics.Color.parseColor("#06B6D4")
    val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = muted; textSize = 23f }
    val value = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ink; textSize = 25f; typeface = Typeface.DEFAULT_BOLD }
    val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = muted; textSize = 19f }
    val divider = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = line; strokeWidth = 2f }

    canvas.drawColor(android.graphics.Color.WHITE)
    canvas.drawRect(0f, 0f, width.toFloat(), 190f, Paint().apply { color = ink })
    val logo = loadBitmapFromUri(context, receipt.instituteLogoUri)
    if (logo != null) {
        canvas.drawBitmap(Bitmap.createScaledBitmap(logo, 104, 104, true), 40f, 42f, Paint(Paint.ANTI_ALIAS_FLAG))
    } else {
        canvas.drawCircle(92f, 94f, 52f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = cyan })
        canvas.drawText(receipt.instituteName.take(2).uppercase(), 60f, 108f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ink; textSize = 34f; typeface = Typeface.DEFAULT_BOLD
        })
    }
    canvas.drawText(documentSafe(receipt.instituteName, 36), 170f, 82f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.WHITE; textSize = 34f; typeface = Typeface.DEFAULT_BOLD
    })
    listOfNotNull(receipt.instituteAddress, receipt.institutePhone, receipt.instituteEmail).take(2).forEachIndexed { index, item ->
        canvas.drawText(documentSafe(item, 62), 170f, 116f + index * 27f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.parseColor("#CBD5E1"); textSize = 20f
        })
    }

    var y = 238f
    canvas.drawText("MONEY RECEIPT", 42f, y, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = blue; textSize = 34f; typeface = Typeface.DEFAULT_BOLD })
    canvas.drawText(receipt.status.uppercase(), 858f, y, Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = if (receipt.status == "Paid") android.graphics.Color.parseColor("#059669") else muted
        textSize = 20f; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.RIGHT
    })
    y += 42f
    documentLine(canvas, label, value, "Receipt no.", receipt.receiptNumber, 42f, 305f, y)
    y += 37f
    documentLine(canvas, label, value, "Date", receiptDateLabel(receipt.receiptDateMs), 42f, 305f, y)
    y += 33f
    canvas.drawLine(42f, y, 858f, y, divider)
    y += 36f

    listOf(
        "Student" to receipt.studentName,
        "Student ID" to receipt.studentCode,
        "Batch" to receipt.batchName,
        "Phone" to receipt.studentPhone,
        "Fee period" to receipt.feePeriod,
        "Fee type" to receipt.feeType?.replace('_', ' ')
    ).forEach { (key, item) ->
        item?.takeIf { it.isNotBlank() }?.let {
            documentLine(canvas, label, value, key, documentSafe(it, 36), 42f, 305f, y)
            y += 37f
        }
    }
    if (receipt.allocations.size > 1) {
        canvas.drawText("EXACT FEE ALLOCATIONS", 42f, y, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = blue; textSize = 21f; typeface = Typeface.DEFAULT_BOLD
        })
        y += 34f
        receipt.allocations.forEach { allocation ->
            documentLine(
                canvas,
                label,
                value,
                allocation.feePeriod ?: "Not available",
                allocationReceiptLabel(allocation.status, allocation.receivedAmount, allocation.payableAmount),
                42f,
                390f,
                y
            )
            y += 37f
        }
    }
    y += 2f
    canvas.drawLine(42f, y, 858f, y, divider)
    y += 36f

    receipt.grossAmount?.let { documentLine(canvas, label, value, "Gross amount", currencyLabel(it), 42f, 540f, y); y += 37f }
    receipt.discountAmount?.takeIf { it > 0.0 }?.let { documentLine(canvas, label, value, "Discount / waiver", "- " + currencyLabel(it), 42f, 540f, y); y += 37f }
    documentLine(canvas, label, value, "Payable amount", currencyLabel(receipt.payableAmount), 42f, 540f, y); y += 37f
    documentLine(canvas, label, value, "Amount received", receipt.receivedAmount?.let(::currencyLabel) ?: "Not available", 42f, 540f, y); y += 37f
    documentLine(canvas, label, value, "Remaining due", currencyLabel(receipt.remainingDue), 42f, 540f, y); y += 37f
    documentLine(canvas, label, value, "Payment method", receipt.paymentMethod.ifBlank { "Not available" }, 42f, 540f, y); y += 37f
    receipt.paymentReference?.let { documentLine(canvas, label, value, "Reference ID", documentSafe(it, 36), 42f, 540f, y); y += 37f }
    receipt.remarks?.let { documentLine(canvas, label, value, "Remarks", documentSafe(it, 36), 42f, 540f, y); y += 37f }
    y += 4f
    canvas.drawLine(42f, y, 858f, y, divider)
    y += 36f

    canvas.drawText("COLLECTED BY", 42f, y, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = blue; textSize = 21f; typeface = Typeface.DEFAULT_BOLD })
    y += 34f
    documentLine(canvas, label, value, "Name", receipt.collectorName ?: "Not available", 42f, 305f, y); y += 37f
    receipt.collectorRole?.let { documentLine(canvas, label, value, "Role", it, 42f, 305f, y); y += 37f }
    receipt.collectorStaffCode?.let { documentLine(canvas, label, value, "Staff ID", it, 42f, 305f, y); y += 37f }

    val signatureY = maxOf(y + 98f, 1_510f)
    canvas.drawLine(64f, signatureY, 360f, signatureY, divider)
    canvas.drawLine(540f, signatureY, 836f, signatureY, divider)
    canvas.drawText("Collected By", 64f, signatureY + 27f, small)
    canvas.drawText("Authorized By", 540f, signatureY + 27f, small)
    canvas.drawText("Thank you for your payment", 450f, height - 44f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = muted; textSize = 19f; textAlign = Paint.Align.CENTER
    })
    return bitmap
}

private fun documentLine(canvas: Canvas, label: Paint, value: Paint, key: String, item: String, left: Float, right: Float, y: Float) {
    canvas.drawText(key, left, y, label)
    canvas.drawText(item, right, y, value)
}

private fun documentSafe(value: String, maxChars: Int): String =
    if (value.length <= maxChars) value else value.take(maxChars - 3) + "..."

internal fun generateReceiptDocumentPdf(context: Context, receipt: ReceiptDocument): Uri {
    val bitmap = createReceiptDocumentBitmap(context, receipt)
    val pdf = PdfDocument()
    val pageHeight = (bitmap.height * 595f / bitmap.width).toInt()
    val page = pdf.startPage(PdfDocument.PageInfo.Builder(595, pageHeight, 1).create())
    page.canvas.drawColor(android.graphics.Color.WHITE)
    page.canvas.drawBitmap(bitmap, null, android.graphics.Rect(0, 0, 595, pageHeight), Paint(Paint.ANTI_ALIAS_FLAG))
    pdf.finishPage(page)
    val file = File(context.cacheDir, "receipt_" + receipt.receiptNumber.replace("/", "_") + ".pdf")
    FileOutputStream(file).use { pdf.writeTo(it) }
    pdf.close()
    return FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
}

// ── Helper: WhatsApp / share ─────────────────────────────────────
private fun shareReceiptImage(context: Context, bitmap: Bitmap, phone: String?) {
    val file = File(context.cacheDir, "receipt_share_${System.currentTimeMillis()}.jpg")
    FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) }
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val send = { pkg: String? ->
        Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"; putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (pkg != null) `package` = pkg
            if (!phone.isNullOrBlank() && pkg == "com.whatsapp") {
                putExtra("jid", "${phone.replace("+", "").replace(" ", "").replace("-", "")}@s.whatsapp.net")
            }
        }
    }
    try { context.startActivity(Intent.createChooser(send("com.whatsapp"), "Share Receipt")) }
    catch (_: Exception) { context.startActivity(Intent.createChooser(send(null), "Share Receipt")) }
}

internal fun shareReceiptImageAny(context: Context, bitmap: Bitmap) {
    val file = File(context.cacheDir, "receipt_share_${System.currentTimeMillis()}.jpg")
    FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) }
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
        type = "image/jpeg"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }, "Share Receipt"))
}

private fun loadBitmapFromUri(context: Context, uriString: String?): Bitmap? {
    val uri = uriString?.takeIf { it.isNotBlank() }?.let(Uri::parse) ?: return null
    return try {
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
    } catch (_: Exception) {
        null
    }
}

private fun sendReceiptMessage(context: Context, phone: String?, body: String) {
    val intent = Intent(Intent.ACTION_SENDTO).apply {
        data = Uri.parse("smsto:${phone.orEmpty()}")
        putExtra("sms_body", body)
    }
    try {
        context.startActivity(intent)
    } catch (_: Exception) {
        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, body)
        }, "Send Receipt Message"))
    }
}

private fun buildReceiptMessage(
    receiptNumber: String,
    studentName: String,
    feePeriod: String,
    collectedAmount: Double,
    dueAmount: Double,
    paymentMethod: String
): String = buildString {
    appendLine("BatchFee Receipt")
    appendLine("Receipt: $receiptNumber")
    appendLine("Student: $studentName")
    appendLine("Period: $feePeriod")
    appendLine("Collected: BDT ${"%.0f".format(collectedAmount)}")
    appendLine("Remaining Due: BDT ${"%.0f".format(dueAmount)}")
    appendLine("Payment Mode: ${paymentMethod.uppercase()}")
}

// ── Reusable dropdown composable ─────────────────────────────────
@Composable
private fun <T> PremiumDropdown(
    label: String,
    options: List<T>,
    selectedOption: T?,
    onOptionSelected: (T) -> Unit,
    optionLabel: (T) -> String,
    enabled: Boolean = true
) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedTextField(
            value = selectedOption?.let(optionLabel) ?: "",
            onValueChange = {},
            readOnly = true,
            enabled = enabled,
            label = { Text(label) },
            trailingIcon = { Icon(Icons.Filled.ArrowDropDown, null, tint = TextMuted) },
            modifier = Modifier.fillMaxWidth(),
            colors = premiumTextFieldColors(),
            shape = RoundedCornerShape(12.dp)
        )
        if (enabled) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(70.dp)
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {
                        expanded = !expanded
                    }
            )
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(CardBg).heightIn(max = 300.dp)
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = {
                        Text(
                            optionLabel(option),
                            color = if (option == selectedOption) Cyan else TextWhite
                        )
                    },
                    onClick = { onOptionSelected(option); expanded = false }
                )
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
//  CreateFeeScreen  (unchanged)
// ═══════════════════════════════════════════════════════════════
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateFeeScreen(db: AppDatabase, onBack: () -> Unit) {
    val viewModel: FeeViewModel = viewModel(factory = FeeViewModelFactory(db))
    val instId = SessionManager.currentInstituteId.collectAsState().value
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    var students by remember { mutableStateOf<List<com.batchfee.edu.data.models.StudentEntity>>(emptyList()) }
    var selectedStudentId by remember { mutableStateOf<String?>(null) }
    var baseAmount by remember { mutableStateOf("") }
    var feePeriod by remember { mutableStateOf("") }
    
    LaunchedEffect(instId) {
        if(instId != null) {
            InstituteCacheRefreshManager.refreshIfStale(db, instId)
            db.studentDao().getStudentsByInstitute(instId).collect { students = it }
        }
    }

    Scaffold(
        containerColor = BgColor,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("Create Fee", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 20.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = TextWhite)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgColor)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            if (students.isNotEmpty()) {
                SectionLabel("Select Student")
                Spacer(Modifier.height(6.dp))
                LazyRow {
                    items(students, key = { it.id }) { s ->
                        val selected = selectedStudentId == s.id
                        FilterChip(
                            selected = selected,
                            onClick = { selectedStudentId = if (selected) null else s.id },
                            label = { Text(s.fullName) },
                            modifier = Modifier.padding(end = 8.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElectricBlue.copy(alpha = 0.25f),
                                selectedLabelColor = Cyan,
                                containerColor = CardBg,
                                labelColor = TextMuted
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                borderColor = BorderSub,
                                selectedBorderColor = Cyan,
                                enabled = true,
                                selected = selected
                            )
                        )
                    }
                }
            } else {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No students available. Please add a student first.", color = TextMuted, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(16.dp))

            SectionLabel("Fee Period")
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(
                value = feePeriod,
                onValueChange = { feePeriod = it },
                placeholder = { Text("e.g. Jan 2026", color = TextMuted.copy(alpha = 0.5f)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                colors = premiumTextFieldColors(),
                shape = RoundedCornerShape(12.dp)
            )
            Spacer(Modifier.height(12.dp))

            SectionLabel("Amount (BDT)")
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(
                value = baseAmount,
                onValueChange = { baseAmount = it },
                placeholder = { Text("0.00", color = TextMuted.copy(alpha = 0.5f)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                colors = premiumTextFieldColors(),
                shape = RoundedCornerShape(12.dp)
            )
            Spacer(Modifier.height(20.dp))

            val saveEnabled = selectedStudentId != null &&
                    feePeriod.isNotBlank() &&
                    (baseAmount.toDoubleOrNull() ?: 0.0) > 0.0
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .shadow(4.dp, RoundedCornerShape(14.dp), spotColor = Cyan.copy(alpha = 0.35f))
                    .let { m ->
                        if (saveEnabled)
                            m.background(brush = Brush.horizontalGradient(listOf(ElectricBlue, Cyan)))
                        else
                            m.background(CardBgAlt).border(1.dp, BorderSub, RoundedCornerShape(14.dp))
                    },
                contentAlignment = Alignment.Center
            ) {
                TextButton(
                    onClick = {
                        val amount = baseAmount.toDoubleOrNull()
                        if (amount != null && selectedStudentId != null && feePeriod.isNotBlank()) {
                            viewModel.createFee(
                                studentId = selectedStudentId!!,
                                batchId = null,
                                feePeriod = feePeriod,
                                feeType = "monthly_fee",
                                dueDateMs = System.currentTimeMillis() + 7L*24*60*60*1000,
                                baseAmount = amount,
                                discount = 0.0,
                                lateFee = 0.0,
                                onSuccess = onBack,
                                onError = { scope.launch { snackbarHostState.showSnackbar(it) } }
                            )
                        }
                    },
                    modifier = Modifier.fillMaxSize(),
                    enabled = saveEnabled,
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = if (saveEnabled) Color.White else TextMuted,
                        disabledContentColor = TextMuted
                    )
                ) {
                    Text("Save Fee", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
//  CollectPaymentScreen  (enhanced)
// ═══════════════════════════════════════════════════════════════
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CollectPaymentScreen(db: AppDatabase, feeId: String, onBack: () -> Unit, onNavigateReceipt: (String) -> Unit) {
    val viewModel: FeeViewModel = viewModel(factory = FeeViewModelFactory(db))
    val instId = SessionManager.currentInstituteId.collectAsState().value
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // ── Data ──
    var fee by remember { mutableStateOf<FeeEntity?>(null) }
    var student by remember { mutableStateOf<StudentEntity?>(null) }
    var institute by remember { mutableStateOf<InstituteEntity?>(null) }
    var batches by remember { mutableStateOf<List<BatchEntity>>(emptyList()) }
    var selectedBatchId by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(true) }

    // ── Calculations ──
    val monthOptions = remember { generateMonthOptions() }
    var startMonthIdx by remember { mutableIntStateOf(monthOptions.lastIndex - 1) }
    var endMonthIdx by remember { mutableIntStateOf(monthOptions.lastIndex - 1) }
    var discountPercent by remember { mutableDoubleStateOf(0.0) }
    var collectedAmount by remember { mutableStateOf("") }
    var manualAmountEdit by remember { mutableStateOf(false) }
    var paymentMethod by remember { mutableStateOf("cash") }
    var remarks by remember { mutableStateOf("") }
    val paymentDateMs = remember { System.currentTimeMillis() }
    val paymentDateLabel = remember(paymentDateMs) {
        SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(paymentDateMs))
    }
    val previewReceiptNumber = remember {
        "Rc-${(System.currentTimeMillis() % 1000000).toString().padStart(6, '0')}"
    }

    // ── Image ──
    var paymentBitmap by remember { mutableStateOf<Bitmap?>(null) }
    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) paymentBitmap = compressAndResizeBitmap(context, uri)
    }

    // ── UI state ──
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var savedPaymentId by remember { mutableStateOf<String?>(null) }
    var savedReceipt by remember { mutableStateOf<ReceiptEntity?>(null) }

    // ── Load fee ──
    LaunchedEffect(instId, feeId) {
        if (instId != null) {
            InstituteCacheRefreshManager.refreshIfStale(db, instId)
            fee = db.feeDao().getFeeById(feeId, instId)
            isLoading = false
        }
    }
    LaunchedEffect(instId) {
        if (instId != null) {
            InstituteCacheRefreshManager.refreshIfStale(db, instId)
            db.instituteDao().getInstituteFlow(instId).collect { institute = it }
        }
    }
    // ── Load student ──
    LaunchedEffect(instId, fee?.studentId) {
        val sid = fee?.studentId ?: return@LaunchedEffect
        if (instId != null) db.studentDao().getStudentById(sid, instId).collect { student = it }
    }
    // ── Load batches ──
    LaunchedEffect(instId, fee?.studentId) {
        val sid = fee?.studentId ?: return@LaunchedEffect
        if (instId != null) {
            db.batchStudentDao().getBatchesForStudent(sid, instId).collect { list ->
                batches = list
                if (selectedBatchId == null && list.isNotEmpty()) {
                    selectedBatchId = fee?.batchId?.takeIf { id -> list.any { it.id == id } }
                        ?: list.firstOrNull()?.id
                }
            }
        }
    }
    // ── Parse fee period → default month indices ──
    LaunchedEffect(fee, monthOptions.size) {
        if (fee != null && startMonthIdx == monthOptions.lastIndex - 1 && endMonthIdx == monthOptions.lastIndex - 1) {
            parseFeePeriod(fee!!.feePeriod)?.let { (m, y) ->
                val idx = monthOptions.indexOfFirst { it.month == m + 1 && it.year == y }
                if (idx >= 0) { startMonthIdx = idx; endMonthIdx = idx }
            }
        }
    }

    // ── Reactive math ──
    val selectedBatch = batches.find { it.id == selectedBatchId }
    val isDirectFee = fee?.batchId == null
    val batchFee = if (isDirectFee) fee?.baseAmount ?: 0.0 else selectedBatch?.monthlyFeeAmount ?: 0.0
    val numMonths = if (isDirectFee) 1 else if (endMonthIdx >= startMonthIdx && startMonthIdx >= 0) endMonthIdx - startMonthIdx + 1 else 0
    val baseAmount = if (isDirectFee) fee?.baseAmount ?: 0.0 else batchFee * numMonths
    val discountAmount = if (isDirectFee) fee?.discountAmount ?: 0.0 else baseAmount * discountPercent / 100.0
    val payableAmount = if (isDirectFee) fee?.totalAmount ?: 0.0 else baseAmount - discountAmount
    val totalPaid = fee?.paidAmount ?: 0.0
    val dueAmount = if (isDirectFee) fee?.dueAmount ?: 0.0 else (payableAmount - totalPaid).coerceAtLeast(0.0)

    // Auto-fill collected amount
    LaunchedEffect(discountPercent, selectedBatchId, startMonthIdx, endMonthIdx) { manualAmountEdit = false }
    LaunchedEffect(dueAmount) {
        if (!manualAmountEdit) collectedAmount = if (dueAmount > 0) String.format("%.0f", dueAmount) else ""
    }

    // ── Scaffold ──
    Scaffold(
        containerColor = BgColor,
        topBar = {
            TopAppBar(
                title = { Text("Collect Payment", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 20.sp) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = TextWhite) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgColor)
            )
        }
    ) { padding ->
        when {
            isLoading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Cyan)
            }
            fee == null -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Fee not found.", color = TextMuted)
            }
            savedPaymentId != null -> {
                // ── Success state ──
                Column(
                    Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(Modifier.height(40.dp))
                    Icon(Icons.Filled.CheckCircle, "Saved", tint = AccentGreen, modifier = Modifier.size(72.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Payment Saved!", color = TextWhite, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(24.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth().shadow(4.dp, RoundedCornerShape(14.dp), spotColor = Cyan.copy(0.2f)),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = CardBg),
                        border = BorderStroke(1.dp, BorderSub)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            savedReceipt?.let { r ->
                                ReceiptRow("Receipt", r.receiptNumber)
                                Spacer(Modifier.height(6.dp))
                            }
                            student?.let { ReceiptRow("Student", it.fullName) }
                            Spacer(Modifier.height(6.dp))
                            selectedBatch?.let { ReceiptRow("Batch", it.name) }
                            Spacer(Modifier.height(6.dp))
                            ReceiptRow("Period", if (isDirectFee) fee?.feePeriod ?: "" else monthOptions.getOrNull(startMonthIdx)?.label ?: "")
                            Spacer(Modifier.height(6.dp))
                            ReceiptRow("Collected", "BDT ${"%.2f".format(collectedAmount.toDoubleOrNull() ?: 0.0)}")
                            Spacer(Modifier.height(6.dp))
                            ReceiptRow("Remaining Due", "BDT ${"%.2f".format(dueAmount - (collectedAmount.toDoubleOrNull() ?: 0.0).coerceAtMost(dueAmount))}")
                        }
                    }

                    Spacer(Modifier.height(20.dp))
                    // Receipt actions
                    val receiptNumber = savedReceipt?.receiptNumber ?: previewReceiptNumber
                    val receiptPeriod = if (isDirectFee) fee?.feePeriod ?: "" else monthOptions.getOrNull(startMonthIdx)?.label ?: ""
                    val collectedNow = collectedAmount.toDoubleOrNull() ?: 0.0
                    val remainingDue = dueAmount - collectedNow.coerceAtMost(dueAmount)
                    val receiptMessage = buildReceiptMessage(
                        receiptNumber = receiptNumber,
                        studentName = student?.fullName ?: "",
                        feePeriod = receiptPeriod,
                        collectedAmount = collectedNow,
                        dueAmount = remainingDue,
                        paymentMethod = paymentMethod
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = {
                                try {
                                    val uri = generatePdfReceipt(
                                        context, receiptNumber, student?.fullName ?: "",
                                        selectedBatch?.name ?: "", receiptPeriod,
                                        baseAmount, discountPercent, discountAmount, payableAmount,
                                        totalPaid + (collectedAmount.toDoubleOrNull() ?: 0.0),
                                        remainingDue,
                                        collectedNow, paymentMethod
                                    )
                                    context.startActivity(Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(uri, "application/pdf")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    })
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Could not open PDF", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Cyan),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)
                        ) {
                            Icon(Icons.Filled.Print, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Print")
                        }
                        OutlinedButton(
                            onClick = {
                                val bmp = createReceiptBitmap(
                                    context,
                                    receiptNumber, student?.fullName ?: "",
                                    selectedBatch?.name ?: "", receiptPeriod,
                                    payableAmount, collectedNow,
                                    remainingDue, paymentMethod,
                                    institute?.name ?: "BatchFee",
                                    institute?.profilePhotoUri
                                )
                                shareReceiptImage(context, bmp, student?.phone)
                            },
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, AccentGreen),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentGreen)
                        ) {
                            Icon(Icons.Filled.Chat, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("WhatsApp")
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = { sendReceiptMessage(context, student?.phone, receiptMessage) },
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, TextMuted),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMuted)
                        ) {
                            Icon(Icons.Filled.Message, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Message")
                        }
                        Button(
                            onClick = {
                                val bmp = createReceiptBitmap(
                                    context,
                                    receiptNumber, student?.fullName ?: "",
                                    selectedBatch?.name ?: "", receiptPeriod,
                                    payableAmount, collectedNow,
                                    remainingDue, paymentMethod,
                                    institute?.name ?: "BatchFee",
                                    institute?.profilePhotoUri
                                )
                                shareReceiptImageAny(context, bmp)
                            },
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                        ) {
                            Icon(Icons.Filled.Share, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Share", color = Color.White)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = onBack,
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CardBgAlt)
                    ) { Text("Done", color = TextWhite, fontWeight = FontWeight.Bold) }
                }
            }
            else -> {
                // ── Collection form ──
                val f = fee!!
                Column(
                    Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    // Student info card
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
                            .shadow(4.dp, RoundedCornerShape(14.dp), spotColor = ElectricBlue.copy(0.15f)),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = CardBg),
                        border = BorderStroke(1.dp, BorderSub)
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Person, null, tint = Cyan, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(student?.fullName ?: "Loading…", color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                if (!student?.phone.isNullOrBlank()) {
                                    Text("Phone: ${student!!.phone}", color = TextMuted, fontSize = 13.sp)
                                }
                            }
                        }
                    }

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ReadOnlyPaymentBox(
                            label = "No. of Receipts",
                            value = savedReceipt?.receiptNumber ?: previewReceiptNumber,
                            modifier = Modifier.weight(1f)
                        )
                        ReadOnlyPaymentBox(
                            label = "Payment Date",
                            value = paymentDateLabel,
                            icon = Icons.Filled.CalendarMonth,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(Modifier.height(18.dp))

                    // Batch selection
                    SectionLabel("BATCH")
                    Spacer(Modifier.height(4.dp))
                    PremiumDropdown(
                        label = "Select Batch",
                        options = batches,
                        selectedOption = selectedBatch,
                        onOptionSelected = { selectedBatchId = it.id },
                        optionLabel = { "${it.name} — BDT ${"%.0f".format(it.monthlyFeeAmount)}" },
                        enabled = batches.isNotEmpty()
                    )
                    if (batches.isEmpty()) {
                        Text(
                            if (isDirectFee) "No batch linked to this fee. Collecting as direct student fee."
                            else "Student is not enrolled in any batch.",
                            color = if (isDirectFee) TextMuted else AccentRed,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                    Spacer(Modifier.height(14.dp))

                    // Fee period
                    SectionLabel("FEE PERIOD")
                    Spacer(Modifier.height(4.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.weight(1f)) {
                            PremiumDropdown("Start Month", monthOptions, monthOptions.getOrNull(startMonthIdx),
                                onOptionSelected = { startMonthIdx = monthOptions.indexOf(it) }, optionLabel = { it.label })
                        }
                        Box(Modifier.weight(1f)) {
                            PremiumDropdown("End Month", monthOptions, monthOptions.getOrNull(endMonthIdx),
                                onOptionSelected = { endMonthIdx = monthOptions.indexOf(it) }, optionLabel = { it.label })
                        }
                    }
                    if (numMonths > 0) {
                        Text("$numMonths month${if (numMonths > 1) "s" else ""} selected", color = Cyan, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                    if (endMonthIdx < startMonthIdx) {
                        Text("End month must be after start month.", color = AccentRed, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                    Spacer(Modifier.height(14.dp))

                    // Discount
                    SectionLabel("DISCOUNT")
                    Spacer(Modifier.height(4.dp))
                    val discountOptions = listOf(0.0, 10.0, 20.0, 30.0, 40.0, 50.0, 60.0, 70.0, 80.0)
                    PremiumDropdown("Discount %", discountOptions, discountPercent,
                        onOptionSelected = { discountPercent = it }, optionLabel = { "${it.toInt()}%" })
                    Spacer(Modifier.height(14.dp))

                    // Fee summary card
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
                            .shadow(4.dp, RoundedCornerShape(14.dp), spotColor = Cyan.copy(0.15f)),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = CardBg),
                        border = BorderStroke(1.dp, BorderSub)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            SummaryRow("Batch Fee / month", "BDT ${"%.0f".format(batchFee)}")
                            SummaryRow("× $numMonths months", "BDT ${"%.0f".format(baseAmount)}")
                            if (discountPercent > 0) {
                                SummaryRow("Discount (${discountPercent.toInt()}%)", "- BDT ${"%.2f".format(discountAmount)}", isDiscount = true)
                            }
                            HorizontalDivider(color = BorderSub, modifier = Modifier.padding(vertical = 6.dp))
                            SummaryRow("Payable Amount", "BDT ${"%.2f".format(payableAmount)}", bold = true)
                            Spacer(Modifier.height(4.dp))
                            SummaryRow("Already Paid", "BDT ${"%.2f".format(totalPaid)}")
                            SummaryRow("Due Amount", "BDT ${"%.2f".format(dueAmount)}", bold = true, valueColor = if (dueAmount > 0) AccentRed else AccentGreen)
                        }
                    }

                    // Collected now
                    SectionLabel("COLLECTED NOW")
                    Spacer(Modifier.height(4.dp))
                    OutlinedTextField(
                        value = collectedAmount,
                        onValueChange = { collectedAmount = it; manualAmountEdit = true },
                        placeholder = { Text("0", color = TextMuted.copy(0.5f)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = premiumTextFieldColors(),
                        shape = RoundedCornerShape(12.dp),
                        prefix = { Text("BDT ", color = TextMuted) }
                    )
                    Spacer(Modifier.height(14.dp))

                    SectionLabel("PAYMENT MODE")
                    Spacer(Modifier.height(4.dp))
                    PremiumDropdown(
                        label = "Payment mode",
                        options = listOf("cash", "bkash", "nagad", "bank"),
                        selectedOption = paymentMethod,
                        onOptionSelected = { paymentMethod = it },
                        optionLabel = { it.replaceFirstChar { c -> c.uppercase() } }
                    )
                    Spacer(Modifier.height(14.dp))

                    SectionLabel("REMARKS")
                    Spacer(Modifier.height(4.dp))
                    OutlinedTextField(
                        value = remarks,
                        onValueChange = { remarks = it },
                        placeholder = { Text("Remarks", color = TextMuted.copy(0.5f)) },
                        modifier = Modifier.fillMaxWidth().height(88.dp),
                        colors = premiumTextFieldColors(),
                        shape = RoundedCornerShape(12.dp),
                        maxLines = 3
                    )
                    Spacer(Modifier.height(18.dp))

                    // Image upload
                    SectionLabel("RECEIPT IMAGE (optional)")
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(
                            onClick = { galleryLauncher.launch("image/*") },
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, BorderSub),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMuted)
                        ) {
                            Icon(Icons.Filled.PhotoLibrary, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Gallery", fontSize = 13.sp)
                        }
                        if (paymentBitmap != null) {
                            IconButton(onClick = { paymentBitmap = null }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Filled.Close, "Remove image", tint = AccentRed, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                    if (paymentBitmap != null) {
                        Spacer(Modifier.height(8.dp))
                        Image(
                            bitmap = paymentBitmap!!.asImageBitmap(),
                            contentDescription = "Payment receipt image",
                            modifier = Modifier.size(90.dp).clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    }
                    Spacer(Modifier.height(20.dp))

                    // Error
                    if (errorMsg != null) {
                        Text(errorMsg!!, color = AccentRed, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp))
                    }

                    Text(
                        "Collected Fees And Discount",
                        color = TextMuted,
                        modifier = Modifier.fillMaxWidth(),
                        fontSize = 13.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Paid, contentDescription = null, tint = Color(0xFFFBBF24), modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            formatCurrencyPlain(collectedAmount.toDoubleOrNull() ?: 0.0),
                            color = Color(0xFFFBBF24),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.width(12.dp))
                        Text("•", color = TextMuted, fontSize = 22.sp)
                        Spacer(Modifier.width(12.dp))
                        Icon(Icons.Filled.Savings, contentDescription = null, tint = Color(0xFFFFA3A3), modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            formatCurrencyPlain(discountAmount),
                            color = Color(0xFFFFA3A3),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.height(18.dp))

                    // Save button
                    val canSave = (isDirectFee || batches.isNotEmpty()) && numMonths > 0 && endMonthIdx >= startMonthIdx
                            && (collectedAmount.toDoubleOrNull() ?: 0.0) > 0
                    Box(
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .shadow(4.dp, RoundedCornerShape(14.dp), spotColor = Cyan.copy(0.35f))
                            .let { m ->
                                if (canSave) m.background(brush = Brush.horizontalGradient(listOf(ElectricBlue, Cyan)))
                                else m.background(CardBgAlt).border(1.dp, BorderSub, RoundedCornerShape(14.dp))
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        TextButton(
                            onClick = {
                                errorMsg = null
                                val amount = collectedAmount.toDoubleOrNull() ?: 0.0
                                if (amount <= 0) { errorMsg = "Enter a valid amount."; return@TextButton }
                                if (isDirectFee) {
                                    viewModel.collectPayment(
                                        feeId = feeId,
                                        amount = amount,
                                        paymentMethod = paymentMethod,
                                        note = remarks.ifBlank { null },
                                        onSuccess = { pid ->
                                            scope.launch {
                                                savedPaymentId = pid
                                                savedReceipt = instId?.let { db.receiptDao().getReceiptByPaymentIdOnce(it, pid) }
                                            }
                                        },
                                        onError = { errorMsg = it }
                                    )
                                    return@TextButton
                                }
                                val periodLabel = if (startMonthIdx == endMonthIdx) monthOptions[startMonthIdx].label
                                else "${monthOptions[startMonthIdx].label} – ${monthOptions[endMonthIdx].label}"
                                viewModel.updateFeeAndCollectPayment(
                                    feeId = feeId,
                                    newBaseAmount = baseAmount,
                                    discountPercent = discountPercent,
                                    collectedAmount = amount,
                                    paymentMethod = paymentMethod,
                                    feePeriod = periodLabel,
                                    note = remarks.ifBlank { null },
                                    onSuccess = { pid ->
                                        scope.launch {
                                            savedPaymentId = pid
                                            savedReceipt = instId?.let { db.receiptDao().getReceiptByPaymentIdOnce(it, pid) }
                                        }
                                    },
                                    onError = { errorMsg = it }
                                )
                            },
                            modifier = Modifier.fillMaxSize(),
                            enabled = canSave,
                            colors = ButtonDefaults.textButtonColors(
                                contentColor = if (canSave) Color.White else TextMuted,
                                disabledContentColor = TextMuted
                            )
                        ) { Text("Collect Payment", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                    }
                    Spacer(Modifier.height(12.dp))
                }
            }
        }
    }
}

@Composable
private fun ReadOnlyPaymentBox(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null
) {
    Box(
        modifier = modifier
            .height(72.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(CardBgAlt)
            .border(1.dp, TextMuted.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            label,
            color = TextMuted,
            fontSize = 12.sp,
            modifier = Modifier
                .background(CardBgAlt)
                .padding(horizontal = 4.dp)
        )
        Row(
            modifier = Modifier.align(Alignment.CenterStart).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                value,
                color = TextWhite,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
                maxLines = 1
            )
            if (icon != null) {
                Icon(icon, contentDescription = null, tint = TextMuted, modifier = Modifier.size(20.dp))
            }
        }
    }
}

private fun formatCurrencyPlain(value: Double): String =
    java.text.NumberFormat.getNumberInstance(Locale.getDefault()).apply {
        maximumFractionDigits = 0
    }.format(value)

@Composable
private fun SummaryRow(label: String, value: String, bold: Boolean = false, isDiscount: Boolean = false, valueColor: Color = TextWhite) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = if (isDiscount) AccentGreen else TextMuted, fontSize = 14.sp)
        Text(value, color = if (isDiscount) AccentGreen else valueColor, fontSize = if (bold) 16.sp else 14.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun ReceiptRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TextMuted, fontSize = 14.sp)
        Text(value, color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ═══════════════════════════════════════════════════════════════
//  ReceiptDetailScreen  (enhanced with Print & Share)
// ═══════════════════════════════════════════════════════════════
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReceiptDetailScreen(db: AppDatabase, paymentId: String, onBack: () -> Unit) {
    val instId = SessionManager.currentInstituteId.collectAsState().value
    val context = LocalContext.current
    var document by remember { mutableStateOf<ReceiptDocument?>(null) }

    LaunchedEffect(instId, paymentId) {
        document = null
        val instituteId = instId ?: return@LaunchedEffect
        InstituteCacheRefreshManager.refreshIfStale(db, instituteId)
        db.receiptDao().getReceiptByPaymentId(instituteId, paymentId).collect { receipt ->
            if (receipt == null) {
                document = null
            } else {
                val institute = db.instituteDao().getInstitute(instituteId)
                val student = db.studentDao().getStudentById(receipt.studentId, instituteId).firstOrNull()
                val groupedReceipts = db.receiptDao()
                    .getReceiptsByNumberOnce(instituteId, receipt.receiptNumber)
                    .filter { it.studentId == receipt.studentId }
                    .ifEmpty { listOf(receipt) }
                val documents = groupedReceipts.map { groupedReceipt ->
                    val payment = db.paymentDao().getPaymentByIdOnce(instituteId, groupedReceipt.paymentId)
                    val fee = db.feeDao().getFeeById(groupedReceipt.feeId, instituteId)
                    val batch = fee?.batchId?.let { db.batchDao().getBatchById(it, instituteId).firstOrNull() }
                    val collectorId = payment?.collectedByUserId
                    groupedReceipt.id to ReceiptPresentation.create(
                        receipt = groupedReceipt,
                        payment = payment,
                        institute = institute,
                        student = student,
                        batch = batch,
                        fee = fee,
                        collector = collectorId?.let { db.userDao().getUserById(it) },
                        staff = collectorId?.let { db.staffDao().getStaffByIdOnce(it, instituteId) }
                    )
                }
                val selected = documents.first { it.first == receipt.id }.second
                document = ReceiptPresentation.consolidate(
                    listOf(selected) + documents.filterNot { it.first == receipt.id }.map { it.second }
                )
            }
        }
    }

    Scaffold(
        containerColor = BgColor,
        topBar = {
            TopAppBar(
                title = { Text("Receipt", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 20.sp) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = TextWhite) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgColor)
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            document?.let { receipt ->
                ReceiptDocumentCard(receipt)

                Spacer(Modifier.height(20.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(
                        onClick = {
                            try {
                                val uri = generateReceiptDocumentPdf(context, receipt)
                                context.startActivity(Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(uri, "application/pdf"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                })
                            } catch (e: Exception) { Toast.makeText(context, "Could not open PDF", Toast.LENGTH_SHORT).show() }
                        },
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Cyan),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)
                    ) {
                        Icon(Icons.Filled.Print, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp)); Text("Print")
                    }
                    Button(
                        onClick = {
                            shareReceiptImage(context, createReceiptDocumentBitmap(context, receipt), receipt.studentPhone)
                        },
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AccentGreen)
                    ) {
                        Icon(Icons.Filled.Share, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp)); Text("Share", color = Color.White)
                    }
                }
            } ?: run {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Cyan)
                }
            }
        }
    }
}

@Composable
private fun ReceiptDocumentCard(receipt: ReceiptDocument) {
    Card(
        modifier = Modifier.fillMaxWidth().shadow(4.dp, RoundedCornerShape(14.dp), spotColor = Cyan.copy(0.25f)),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, BorderSub)
    ) {
        Column(Modifier.padding(20.dp)) {
            Box(Modifier.fillMaxWidth().height(3.dp).background(Brush.horizontalGradient(listOf(ElectricBlue, Cyan))))
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(52.dp).clip(CircleShape).background(Cyan),
                    contentAlignment = Alignment.Center
                ) {
                    val logo = receipt.instituteLogoUri
                    if (logo != null) {
                        AsyncImage(model = logo, contentDescription = "Institute logo", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    } else {
                        Text(receipt.instituteName.take(2).uppercase(), color = CardBg, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(receipt.instituteName, color = TextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    listOfNotNull(receipt.instituteAddress, receipt.institutePhone, receipt.instituteEmail)
                        .take(2).forEach { Text(it, color = TextMuted, fontSize = 11.sp, maxLines = 1) }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("Money Receipt", color = Cyan, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            ReceiptRow("Receipt no.", receipt.receiptNumber)
            ReceiptRow("Date", receiptDateLabel(receipt.receiptDateMs))
            ReceiptRow("Status", receipt.status)
            HorizontalDivider(Modifier.padding(vertical = 12.dp), color = BorderSub)
            ReceiptOptionalRow("Student", receipt.studentName)
            ReceiptOptionalRow("Student ID", receipt.studentCode)
            ReceiptOptionalRow("Batch", receipt.batchName)
            ReceiptOptionalRow("Phone", receipt.studentPhone)
            ReceiptOptionalRow("Fee period", receipt.feePeriod)
            ReceiptOptionalRow("Fee type", receipt.feeType?.replace('_', ' '))
            if (receipt.allocations.size > 1) {
                Spacer(Modifier.height(10.dp))
                Text("Exact Fee Allocations", color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                receipt.allocations.forEach { allocation ->
                    ReceiptRow(
                        allocation.feePeriod ?: "Not available",
                        allocationReceiptLabel(allocation.status, allocation.receivedAmount, allocation.payableAmount)
                    )
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 12.dp), color = BorderSub)
            receipt.grossAmount?.let { ReceiptRow("Gross amount", currencyLabel(it)) }
            receipt.discountAmount?.takeIf { it > 0.0 }?.let { ReceiptRow("Discount / waiver", "- ${currencyLabel(it)}") }
            ReceiptRow("Payable amount", currencyLabel(receipt.payableAmount))
            ReceiptRow("Amount received", receipt.receivedAmount?.let(::currencyLabel) ?: "Not available")
            ReceiptRow("Remaining due", currencyLabel(receipt.remainingDue))
            ReceiptRow("Payment method", receipt.paymentMethod.ifBlank { "Not available" }.replaceFirstChar { it.uppercase() })
            ReceiptOptionalRow("Reference ID", receipt.paymentReference)
            ReceiptOptionalRow("Remarks", receipt.remarks)
            HorizontalDivider(Modifier.padding(vertical = 12.dp), color = BorderSub)
            Text("Collected By", color = TextMuted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            ReceiptOptionalRow("Name", receipt.collectorName)
            ReceiptOptionalRow("Role", receipt.collectorRole)
            ReceiptOptionalRow("Staff ID", receipt.collectorStaffCode)
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) { HorizontalDivider(color = TextMuted); Text("Collected By", color = TextMuted, fontSize = 11.sp) }
                Spacer(Modifier.width(28.dp))
                Column(Modifier.weight(1f)) { HorizontalDivider(color = TextMuted); Text("Authorized By", color = TextMuted, fontSize = 11.sp) }
            }
            if (receipt.isLegacy) {
                Spacer(Modifier.height(10.dp))
                Text("Some legacy receipt details were not saved at payment time.", color = TextMuted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun ReceiptOptionalRow(label: String, value: String?) {
    value?.takeIf { it.isNotBlank() }?.let { ReceiptRow(label, it) }
}

private fun currencyLabel(value: Double): String = "BDT ${"%.2f".format(value)}"

private fun allocationReceiptLabel(status: String, received: Double?, payable: Double): String {
    val statusLabel = if (status == "Partially Paid") "Partial" else status
    val receivedLabel = received?.let(::currencyLabel) ?: "Not available"
    return statusLabel + " " + receivedLabel + " / " + currencyLabel(payable)
}

private fun receiptDateLabel(value: Long): String =
    if (value > 0L) SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(value)) else "Not available"

