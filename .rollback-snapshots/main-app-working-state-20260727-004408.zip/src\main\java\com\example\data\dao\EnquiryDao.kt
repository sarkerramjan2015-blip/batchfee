package com.batchfee.edu.data.dao

import androidx.room.*
import com.batchfee.edu.data.models.EnquiryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface EnquiryDao {
    @Query(
        "SELECT * FROM enquiries WHERE instituteId = :instituteId AND archivedAtMs IS NULL " +
            "ORDER BY enquiryDateMs DESC, createdAtMs DESC"
    )
    fun getEnquiriesByInstitute(instituteId: String): Flow<List<EnquiryEntity>>

    @Query("SELECT * FROM enquiries WHERE instituteId = :instituteId AND archivedAtMs IS NOT NULL ORDER BY archivedAtMs DESC")
    fun getArchivedEnquiriesByInstitute(instituteId: String): Flow<List<EnquiryEntity>>

    @Query("SELECT * FROM enquiries WHERE instituteId = :instituteId AND archivedAtMs IS NULL AND phone = :phone LIMIT 1")
    suspend fun findActiveByPhone(instituteId: String, phone: String): EnquiryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEnquiry(enquiry: EnquiryEntity)

    @Update
    suspend fun updateEnquiry(enquiry: EnquiryEntity)

    @Query("DELETE FROM enquiries WHERE id = :enquiryId AND instituteId = :instituteId")
    suspend fun deleteEnquiry(enquiryId: String, instituteId: String)
}
