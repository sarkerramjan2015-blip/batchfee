package com.batchfee.edu.ui.registrations

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.batchfee.edu.data.database.AppDatabase
import com.batchfee.edu.data.firestore.InstituteSyncHelper
import com.batchfee.edu.data.firestore.RegistrationRepository
import com.batchfee.edu.data.firestore.StudentSyncHelper
import com.batchfee.edu.data.models.PendingRegistration
import com.batchfee.edu.data.models.StudentEntity
import com.batchfee.edu.domain.RegistrationApprovalRules
import com.batchfee.edu.domain.SessionManager
import com.batchfee.edu.domain.StaffAuditLogger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class RegistrationListViewModel(private val db: AppDatabase) : ViewModel() {
    private val repository = RegistrationRepository()

    private val _registrations = MutableStateFlow<List<PendingRegistration>>(emptyList())
    val registrations: StateFlow<List<PendingRegistration>> = _registrations.asStateFlow()
    private val _existingStudentPhones = MutableStateFlow<Set<String>>(emptySet())
    val existingStudentPhones: StateFlow<Set<String>> = _existingStudentPhones.asStateFlow()
    private val _instituteName = MutableStateFlow<String?>(null)
    val instituteName: StateFlow<String?> = _instituteName.asStateFlow()
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    init { loadRegistrations() }

    private fun loadRegistrations() {
        val instituteId = SessionManager.currentInstituteId.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            repository.registrationsFlow(instituteId).collect { list ->
                _registrations.value = list.sortedByDescending { it.submittedAt }
                _isLoading.value = false
            }
        }
        viewModelScope.launch {
            db.studentDao().getStudentsByInstitute(instituteId).collect { students ->
                _existingStudentPhones.value = students.mapNotNull { it.phone }.toSet()
            }
        }
        viewModelScope.launch {
            db.instituteDao().getInstituteFlow(instituteId).collect { _instituteName.value = it?.name }
        }
    }

    fun generateRegistrationLink(onGenerated: (String) -> Unit) {
        val instituteId = SessionManager.currentInstituteId.value ?: return
        if (!canManage()) return
        viewModelScope.launch {
            val institute = db.instituteDao().getInstitute(instituteId)
            val validInstitute = institute?.takeIf {
                RegistrationApprovalRules.instituteDisplayName(it.name) != null
            }
            if (validInstitute == null) {
                _snackbarMessage.value = "Registration link is unavailable until institute details are loaded."
                return@launch
            }
            runCatching {
                repository.syncInstituteInfo(validInstitute.id, validInstitute.name, validInstitute.phone)
                StaffAuditLogger.record(db, instituteId, SessionManager.currentUserId.value, "registration_link_shared", "registration", "Generated legacy-compatible registration link")
                onGenerated(repository.getRegistrationFormUrl(instituteId))
            }.onFailure { _snackbarMessage.value = "Could not refresh institute details for the registration form." }
        }
    }

    fun registrationShareText(url: String, instituteName: String?): String = buildString {
        RegistrationApprovalRules.instituteDisplayName(instituteName)?.let { appendLine("Student Registration — $it") }
            ?: appendLine("Student Registration")
        append("Please complete the registration form using this link: $url")
    }

    fun hasPendingDuplicate(registration: PendingRegistration): Boolean {
        val phone = RegistrationApprovalRules.normalizePhone(registration.phone)
        return phone.isNotEmpty() && _registrations.value.count {
            it.requestId != registration.requestId && it.status == RegistrationApprovalRules.PENDING &&
                RegistrationApprovalRules.normalizePhone(it.phone) == phone
        } > 0
    }

    fun approveRegistration(registration: PendingRegistration) {
        if (!canManage() || registration.requestId.isBlank()) return
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val instituteId = SessionManager.currentInstituteId.value ?: return@launch
                val current = repository.getPendingRegistration(instituteId, registration.requestId) ?: registration
                if (current.status == RegistrationApprovalRules.APPROVED) {
                    _snackbarMessage.value = "This registration is already approved."
                    return@launch
                }
                if (!RegistrationApprovalRules.canApprove(current.status)) {
                    _snackbarMessage.value = "Only pending registrations can be approved."
                    return@launch
                }
                if (!RegistrationApprovalRules.isValidSubmission(current.fullName, current.phone)) {
                    _snackbarMessage.value = "Registration has an invalid name or phone number."
                    return@launch
                }

                val studentId = current.approvedStudentId ?: "registration_${current.requestId}"
                val students = db.studentDao().getStudentsByInstituteOnce(instituteId)
                val existingById = students.firstOrNull { it.id == studentId }
                val duplicate = students.firstOrNull {
                    it.id != studentId && RegistrationApprovalRules.normalizePhone(it.phone) == RegistrationApprovalRules.normalizePhone(current.phone)
                }
                if (duplicate != null) {
                    StaffAuditLogger.record(db, instituteId, SessionManager.currentUserId.value, "registration_duplicate_prevented", "registration", "Approval blocked for ${current.fullName}: phone already belongs to ${duplicate.id}")
                    _snackbarMessage.value = "A student with this phone already exists. Approval was not completed."
                    return@launch
                }

                if (existingById == null) {
                    val now = System.currentTimeMillis()
                    val student = StudentEntity(
                        id = studentId, instituteId = instituteId, studentCode = studentCodeFor(current.requestId),
                        fullName = current.fullName.trim(), photoUri = null, gender = current.gender,
                        dateOfBirthMs = current.dateOfBirthMs, phone = current.phone.trim(), email = null,
                        address = current.address, schoolName = current.schoolName, className = current.className,
                        guardianName = current.guardianName, guardianPhone = null, guardianEmail = null,
                        emergencyContact = null, bloodGroup = null, admissionDateMs = now, status = "active",
                        notes = current.whatsappNumber?.takeIf { it.isNotBlank() }?.let { "WhatsApp: $it" },
                        createdAtMs = now, updatedAtMs = now, archivedAtMs = null
                    )
                    StudentSyncHelper.upsertStudent(student)
                    db.studentDao().insertStudent(student)
                    InstituteSyncHelper.updateStudentCount(instituteId, db.studentDao().getStudentsByInstituteOnce(instituteId).size)
                }

                repository.updateApproval(instituteId, current.requestId, studentId, SessionManager.currentUserId.value, System.currentTimeMillis())
                StaffAuditLogger.record(db, instituteId, SessionManager.currentUserId.value, "registration_approved", "registration", "Approved ${current.fullName}", newValue = studentId)
                _snackbarMessage.value = "${current.fullName} approved and added to students."
            } catch (e: Exception) {
                _snackbarMessage.value = "Failed to approve. The registration remains pending: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun rejectRegistration(registration: PendingRegistration, reason: String? = null) {
        if (!canManage() || registration.requestId.isBlank()) return
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val instituteId = SessionManager.currentInstituteId.value ?: return@launch
                val current = repository.getPendingRegistration(instituteId, registration.requestId) ?: registration
                if (current.status != RegistrationApprovalRules.PENDING) {
                    _snackbarMessage.value = "Only pending registrations can be rejected."
                    return@launch
                }
                repository.updateRejection(instituteId, current.requestId, SessionManager.currentUserId.value, System.currentTimeMillis(), reason)
                StaffAuditLogger.record(db, instituteId, SessionManager.currentUserId.value, "registration_rejected", "registration", "Rejected ${current.fullName}", newValue = reason)
                _snackbarMessage.value = "${current.fullName}'s registration was rejected and retained in history."
            } catch (e: Exception) {
                _snackbarMessage.value = "Failed to reject: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun clearSnackbar() { _snackbarMessage.value = null }

    private fun canManage(): Boolean {
        if (SessionManager.isAdmin()) return true
        _snackbarMessage.value = "You do not have permission to manage registrations."
        return false
    }

    private fun studentCodeFor(requestId: String): String =
        ("RG" + requestId.filter(Char::isLetterOrDigit).takeLast(6).uppercase()).padEnd(8, '0')
}

class RegistrationListViewModelFactory(private val db: AppDatabase) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(RegistrationListViewModel::class.java)) return RegistrationListViewModel(db) as T
        throw IllegalArgumentException()
    }
}
