﻿package com.batchfee.edu.ui.enquiries

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.batchfee.edu.data.database.AppDatabase
import com.batchfee.edu.data.firestore.EnquirySyncHelper
import com.batchfee.edu.data.firestore.InstituteCacheRefreshManager
import com.batchfee.edu.data.models.EnquiryEntity
import com.batchfee.edu.data.models.AuditLogEntity
import com.batchfee.edu.domain.SessionManager
import com.batchfee.edu.domain.StaffAuditLogger
import com.batchfee.edu.domain.EnquiryFollowUpSupport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.UUID

class EnquiryViewModel(private val db: AppDatabase) : ViewModel() {
    private val _allEnquiries = MutableStateFlow<List<EnquiryEntity>>(emptyList())
    val allEnquiries = _allEnquiries.asStateFlow()
    private val _archivedEnquiries = MutableStateFlow<List<EnquiryEntity>>(emptyList())
    val archivedEnquiries = _archivedEnquiries.asStateFlow()
    private val _auditLogs = MutableStateFlow<List<AuditLogEntity>>(emptyList())
    val auditLogs = _auditLogs.asStateFlow()

    private val _filterStatus = MutableStateFlow("all")
    val filterStatus = _filterStatus.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading = _isLoading.asStateFlow()

    private val _todayCount = MutableStateFlow(0)
    val todayCount = _todayCount.asStateFlow()

    private val _followUpCount = MutableStateFlow(0)
    val followUpCount = _followUpCount.asStateFlow()

    val todayLabel = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(
        Calendar.getInstance().time
    )

    init {
        loadEnquiries()
        loadArchivedEnquiries()
        viewModelScope.launch {
            val instId = SessionManager.currentInstituteId.value ?: return@launch
            db.auditLogDao().getAuditLogsByInstitute(instId).collect { _auditLogs.value = it }
        }
    }

    private fun loadEnquiries() {
        viewModelScope.launch {
            val instId = SessionManager.currentInstituteId.value ?: return@launch
            _isLoading.value = true
            InstituteCacheRefreshManager.refreshIfStale(db, instId)
            db.enquiryDao().getEnquiriesByInstitute(instId).collect { list ->
                _allEnquiries.value = list

                val startOfToday = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                _todayCount.value = list.count { it.enquiryDateMs >= startOfToday }
                _followUpCount.value = list.count {
                    it.status.equals("follow_up", ignoreCase = true) ||
                    it.status.equals("follow up", ignoreCase = true)
                }
                _isLoading.value = false
            }
        }
    }

    fun setFilter(status: String) {
        _filterStatus.value = status
    }

    fun updateStatus(enquiry: EnquiryEntity, newStatus: String, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val updated = enquiry.copy(
                        status = newStatus,
                        updatedAtMs = System.currentTimeMillis()
                    )
                    EnquirySyncHelper.upsertEnquiry(updated)
                    db.enquiryDao().updateEnquiry(updated)
                    StaffAuditLogger.record(db, updated.instituteId, SessionManager.currentUserId.value, "enquiry_status_changed", "enquiry", "Changed ${updated.name} status to $newStatus", enquiry.status, newStatus)
                }
            } catch (e: Exception) {
                onError(e.message ?: "Failed to update status")
            }
        }
    }

    private fun loadArchivedEnquiries() {
        viewModelScope.launch {
            val instId = SessionManager.currentInstituteId.value ?: return@launch
            db.enquiryDao().getArchivedEnquiriesByInstitute(instId).collect { _archivedEnquiries.value = it }
        }
    }

    fun deletePermanently(enquiry: EnquiryEntity, onError: (String) -> Unit = {}) {
        if (!SessionManager.isAdmin()) { onError("Only admins can permanently delete enquiries."); return }
        viewModelScope.launch { try { withContext(Dispatchers.IO) {
            db.enquiryDao().deleteEnquiry(enquiry.id, enquiry.instituteId)
            StaffAuditLogger.record(db, enquiry.instituteId, SessionManager.currentUserId.value, "enquiry_deleted", "enquiry", "Permanently deleted enquiry ${enquiry.name}")
        }} catch (e: Exception) { onError(e.message ?: "Delete failed") } }
    }

    fun saveFollowUp(enquiry: EnquiryEntity, atMs: Long?, type: String?, priority: String, note: String?, assignedStaffId: String?, source: String?, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val updated = enquiry.copy(status = "follow_up", followUpAtMs = atMs, followUpType = type, priority = priority, followUpNote = note?.trim()?.takeIf { it.isNotBlank() }, assignedStaffId = assignedStaffId?.takeIf { it.isNotBlank() }, source = source?.takeIf { it.isNotBlank() }, updatedAtMs = System.currentTimeMillis())
                    EnquirySyncHelper.upsertEnquiry(updated); db.enquiryDao().updateEnquiry(updated)
                    StaffAuditLogger.record(db, updated.instituteId, SessionManager.currentUserId.value, "enquiry_follow_up_scheduled", "enquiry", "Scheduled ${type ?: "follow-up"} for ${updated.name}")
                }
            } catch (e: Exception) { onError(e.message ?: "Failed to save follow-up") }
        }
    }

    fun archive(enquiry: EnquiryEntity, restore: Boolean = false, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            try { withContext(Dispatchers.IO) {
                val updated = enquiry.copy(archivedAtMs = if (restore) null else System.currentTimeMillis(), updatedAtMs = System.currentTimeMillis())
                EnquirySyncHelper.upsertEnquiry(updated); db.enquiryDao().updateEnquiry(updated)
                StaffAuditLogger.record(db, updated.instituteId, SessionManager.currentUserId.value, if (restore) "enquiry_restored" else "enquiry_archived", "enquiry", "${if (restore) "Restored" else "Archived"} enquiry ${updated.name}")
            }} catch (e: Exception) { onError(e.message ?: "Failed to update enquiry") }
        }
    }

    fun addEnquiry(
        name: String,
        phone: String,
        address: String?,
        subjectName: String,
        enquiryDateMs: Long,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val instId = SessionManager.currentInstituteId.value
        if (instId == null) { onError("No active institute."); return }
        if (name.isBlank()) { onError("Name is required."); return }
        if (phone.isBlank()) { onError("Phone is required."); return }
        if (subjectName.isBlank()) { onError("Subject is required."); return }

        viewModelScope.launch {
            try {
                val normalized = EnquiryFollowUpSupport.normalizedPhone(phone)
                if (_allEnquiries.value.any { EnquiryFollowUpSupport.normalizedPhone(it.phone) == normalized }) {
                    onError("An active enquiry with this phone number already exists.")
                    return@launch
                }
                val duplicate = withContext(Dispatchers.IO) {
                    db.studentDao().getStudentsByInstituteOnce(instId).any {
                        EnquiryFollowUpSupport.normalizedPhone(it.phone.orEmpty()) == normalized
                    }
                }
                if (duplicate) { onError("A student with this phone number already exists."); return@launch }
                val now = System.currentTimeMillis()
                val enquiry = EnquiryEntity(
                    id = UUID.randomUUID().toString(),
                    instituteId = instId,
                    name = name.trim(),
                    phone = phone.trim(),
                    address = address?.trim()?.takeIf { it.isNotEmpty() },
                    subjectName = subjectName.trim(),
                    enquiryDateMs = enquiryDateMs,
                    status = "active",
                    createdAtMs = now,
                    updatedAtMs = now,
                    archivedAtMs = null
                )
                withContext(Dispatchers.IO) {
                    EnquirySyncHelper.upsertEnquiry(enquiry)
                    db.enquiryDao().insertEnquiry(enquiry)
                }
                onSuccess()
            } catch (e: Exception) {
                onError(e.message ?: "Failed to save enquiry.")
            }
        }
    }
}

class EnquiryViewModelFactory(private val db: AppDatabase) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(EnquiryViewModel::class.java)) return EnquiryViewModel(db) as T
        throw IllegalArgumentException()
    }
}

