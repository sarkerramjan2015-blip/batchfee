package com.batchfee.edu.ui.registrations

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.batchfee.edu.data.database.AppDatabase
import com.batchfee.edu.data.models.PendingRegistration
import com.batchfee.edu.domain.RegistrationApprovalRules
import com.batchfee.edu.domain.SessionManager
import java.text.SimpleDateFormat
import java.util.*

private val BgColor = Color(0xFF07111F)
private val CardBg = Color(0xFF0F172A)
private val BorderSub = Color(0xFF1E293B)
private val Cyan = Color(0xFF22D3EE)
private val ElectricBlue = Color(0xFF3B82F6)
private val TextWhite = Color(0xFFF8FAFC)
private val TextMuted = Color(0xFF94A3B8)
private val AccentRed = Color(0xFFEF4444)
private val AccentGreen = Color(0xFF22C55E)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegistrationListScreen(
    db: AppDatabase,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val viewModel: RegistrationListViewModel = viewModel(
        factory = RegistrationListViewModelFactory(db)
    )
    val registrations by viewModel.registrations.collectAsStateWithLifecycle()
    val existingStudentPhones by viewModel.existingStudentPhones.collectAsStateWithLifecycle()
    val instituteName by viewModel.instituteName.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val canManage = remember { SessionManager.isAdmin() }
    var selectedRegistration by remember { mutableStateOf<PendingRegistration?>(null) }
    var showConfirmReject by remember { mutableStateOf<PendingRegistration?>(null) }
    var rejectionReason by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf(RegistrationApprovalRules.PENDING) }
    var generatedLink by remember { mutableStateOf<String?>(null) }
    var showLinkActions by remember { mutableStateOf(false) }
    val filteredRegistrations = remember(registrations, statusFilter) {
        registrations.filter { it.status == statusFilter }
    }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { message ->
            snackbarHostState.showSnackbar(message)
            viewModel.clearSnackbar()
        }
    }

    Scaffold(
        containerColor = BgColor,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("Student Registration", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 20.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = TextWhite)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgColor)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(horizontal = 20.dp)
        ) {
            if (canManage) {
                Button(
                    onClick = {
                        viewModel.generateRegistrationLink { url ->
                            generatedLink = url
                            showLinkActions = true
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .padding(vertical = 8.dp)
                        .shadow(4.dp, RoundedCornerShape(14.dp), spotColor = Cyan.copy(alpha = 0.2f)),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue, contentColor = Color.White)
                ) {
                    Icon(Icons.Filled.Link, null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("Create Registration Link", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                Text(
                    "Create a link, then choose how to share it.",
                    color = TextMuted,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )
            }

            Text(
                "Registration history",
                color = TextWhite,
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                RegistrationStatusFilter("Pending", RegistrationApprovalRules.PENDING, statusFilter) { statusFilter = it }
                RegistrationStatusFilter("Approved", RegistrationApprovalRules.APPROVED, statusFilter) { statusFilter = it }
                RegistrationStatusFilter("Rejected", RegistrationApprovalRules.REJECTED, statusFilter) { statusFilter = it }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${statusLabel(statusFilter)} registrations",
                    color = TextMuted,
                    fontSize = 13.sp
                )
                Spacer(Modifier.weight(1f))
                Surface(shape = RoundedCornerShape(20.dp), color = Cyan.copy(alpha = 0.15f)) {
                    Text(
                        "${filteredRegistrations.size}",
                        color = Cyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(color = BorderSub, modifier = Modifier.padding(bottom = 4.dp))

            if (isLoading && registrations.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Cyan)
                }
            } else if (filteredRegistrations.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Filled.PersonAdd,
                            contentDescription = null,
                            tint = TextMuted.copy(alpha = 0.4f),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "No ${statusLabel(statusFilter).lowercase()} registrations",
                            color = TextMuted,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredRegistrations, key = { it.requestId }) { registration ->
                        RegistrationCard(
                            registration = registration,
                            hasExistingStudentDuplicate = RegistrationApprovalRules.isDuplicatePhone(registration.phone, existingStudentPhones),
                            hasPendingDuplicate = viewModel.hasPendingDuplicate(registration),
                            canManage = canManage,
                            onDetailsClick = { selectedRegistration = registration },
                            onApproveClick = { viewModel.approveRegistration(registration) },
                            onRejectClick = { showConfirmReject = registration }
                        )
                    }
                }
            }
        }
    }

    selectedRegistration?.let { registration ->
        RegistrationDetailSheet(
            registration = registration,
            canManage = canManage,
            onDismiss = { selectedRegistration = null },
            onApprove = {
                viewModel.approveRegistration(registration)
                selectedRegistration = null
            },
            onReject = {
                selectedRegistration = null
                showConfirmReject = registration
            }
        )
    }

    showConfirmReject?.let { registration ->
        AlertDialog(
            onDismissRequest = {
                showConfirmReject = null
                rejectionReason = ""
            },
            containerColor = CardBg,
            title = { Text("Reject Registration", color = TextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "Reject ${registration.fullName}'s registration? The submission will remain in history.",
                        color = TextMuted
                    )
                    OutlinedTextField(
                        value = rejectionReason,
                        onValueChange = { rejectionReason = it },
                        label = { Text("Reason (optional)") },
                        singleLine = false,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedBorderColor = Cyan,
                            unfocusedBorderColor = BorderSub,
                            focusedLabelColor = Cyan,
                            unfocusedLabelColor = TextMuted
                        )
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.rejectRegistration(registration, rejectionReason)
                        showConfirmReject = null
                        rejectionReason = ""
                    }
                ) { Text("Reject", color = AccentRed, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = {
                    showConfirmReject = null
                    rejectionReason = ""
                }) { Text("Cancel", color = TextMuted) }
            }
        )
    }

    if (showLinkActions && generatedLink != null) {
        RegistrationLinkActionsDialog(
            url = generatedLink.orEmpty(),
            onDismiss = { showLinkActions = false },
            onCopy = { copyRegistrationLink(context, generatedLink.orEmpty()) },
            onShare = { shareRegistrationText(context, viewModel.registrationShareText(generatedLink.orEmpty(), instituteName)) },
            onWhatsApp = { shareToWhatsApp(context, viewModel.registrationShareText(generatedLink.orEmpty(), instituteName)) },
            onSms = { shareBySms(context, viewModel.registrationShareText(generatedLink.orEmpty(), instituteName)) }
        )
    }
}

@Composable
private fun RegistrationStatusFilter(label: String, value: String, selected: String, onSelect: (String) -> Unit) {
    FilterChip(
        selected = selected == value,
        onClick = { onSelect(value) },
        label = { Text(label, fontSize = 12.sp) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Cyan.copy(alpha = 0.18f),
            selectedLabelColor = Cyan,
            labelColor = TextMuted
        ),
        border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = selected == value,
            borderColor = BorderSub,
            selectedBorderColor = Cyan.copy(alpha = 0.45f)
        )
    )
}

@Composable
private fun RegistrationCard(
    registration: PendingRegistration,
    hasExistingStudentDuplicate: Boolean,
    hasPendingDuplicate: Boolean,
    canManage: Boolean,
    onDetailsClick: () -> Unit,
    onApproveClick: () -> Unit,
    onRejectClick: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }
    val isPending = registration.status == RegistrationApprovalRules.PENDING

    Card(
        modifier = Modifier.fillMaxWidth().shadow(2.dp, RoundedCornerShape(14.dp), spotColor = Cyan.copy(alpha = 0.1f)),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, BorderSub)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(12.dp), color = ElectricBlue.copy(alpha = 0.15f), modifier = Modifier.size(40.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(registration.fullName.take(1).uppercase(), color = Cyan, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(registration.fullName, color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Phone, null, tint = TextMuted.copy(alpha = 0.5f), modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(registration.phone, color = TextMuted, fontSize = 13.sp)
                    }
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(dateFormat.format(Date(registration.submittedAt)), color = TextMuted.copy(alpha = 0.6f), fontSize = 11.sp)
                    Spacer(Modifier.height(4.dp))
                    RegistrationStatusBadge(registration.status)
                }
            }

            if (hasExistingStudentDuplicate || hasPendingDuplicate) {
                Spacer(Modifier.height(10.dp))
                Text(
                    if (hasExistingStudentDuplicate) "Possible duplicate: a student already uses this phone." else "Possible duplicate: another pending registration uses this phone.",
                    color = AccentRed,
                    fontSize = 12.sp
                )
            }

            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = onDetailsClick,
                    modifier = Modifier.weight(1f).height(38.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = TextMuted),
                    border = BorderStroke(1.dp, BorderSub),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                ) {
                    Icon(Icons.Filled.Info, null, tint = TextMuted, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Review", fontSize = 12.sp)
                }
                if (isPending && canManage) {
                    Button(
                        onClick = onApproveClick,
                        modifier = Modifier.weight(1f).height(38.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AccentGreen, contentColor = Color.White),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                    ) {
                        Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Approve", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = onRejectClick, modifier = Modifier.size(38.dp)) {
                        Icon(Icons.Filled.Close, "Reject", tint = AccentRed.copy(alpha = 0.7f), modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun RegistrationStatusBadge(status: String) {
    val (label, color) = when (status) {
        RegistrationApprovalRules.APPROVED -> "Approved" to AccentGreen
        RegistrationApprovalRules.REJECTED -> "Rejected" to AccentRed
        else -> "Pending" to Cyan
    }
    Surface(shape = RoundedCornerShape(12.dp), color = color.copy(alpha = 0.14f)) {
        Text(label, color = color, fontSize = 10.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp))
    }
}

@Composable
private fun RegistrationLinkActionsDialog(
    url: String,
    onDismiss: () -> Unit,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onWhatsApp: () -> Unit,
    onSms: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardBg,
        title = { Text("Registration Link", color = TextWhite, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Share this registration link for the selected institute.", color = TextMuted)
                Text(url, color = Cyan, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = onCopy, modifier = Modifier.fillMaxWidth()) { Text("Copy Link", color = TextWhite) }
                TextButton(onClick = onShare, modifier = Modifier.fillMaxWidth()) { Text("Share", color = TextWhite) }
                TextButton(onClick = onWhatsApp, modifier = Modifier.fillMaxWidth()) { Text("WhatsApp", color = TextWhite) }
                TextButton(onClick = onSms, modifier = Modifier.fillMaxWidth()) { Text("SMS", color = TextWhite) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done", color = Cyan) } }
    )
}

private fun statusLabel(status: String): String = when (status) {
    RegistrationApprovalRules.APPROVED -> "Approved"
    RegistrationApprovalRules.REJECTED -> "Rejected"
    else -> "Pending"
}

private fun copyRegistrationLink(context: Context, link: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("Registration Link", link))
}

private fun shareRegistrationText(context: Context, shareText: String) {
    context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, shareText)
    }, "Share registration link"))
}

private fun shareToWhatsApp(context: Context, shareText: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, shareText)
        setPackage("com.whatsapp")
    }
    runCatching { context.startActivity(intent) }.getOrElse { shareRegistrationText(context, shareText) }
}

private fun shareBySms(context: Context, shareText: String) {
    val intent = Intent(Intent.ACTION_SENDTO).apply {
        data = Uri.parse("smsto:")
        putExtra("sms_body", shareText)
    }
    runCatching { context.startActivity(intent) }.getOrElse { shareRegistrationText(context, shareText) }
}
