package com.batchfee.edu.ui.fees

import android.content.Context
import android.content.Intent
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.AlertDialog
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.Row
import com.batchfee.edu.data.database.AppDatabase
import com.batchfee.edu.data.firestore.FinanceSyncHelper
import com.batchfee.edu.data.firestore.InstituteCacheRefreshManager
import com.batchfee.edu.data.models.BatchEntity
import com.batchfee.edu.data.models.FeeEntity
import com.batchfee.edu.data.models.InstituteEntity
import com.batchfee.edu.data.models.PaymentEntity
import com.batchfee.edu.data.models.ReceiptEntity
import com.batchfee.edu.data.models.StudentEntity
import com.batchfee.edu.data.repository.FeeCollectionRepository
import com.batchfee.edu.data.repository.MonthlyFeeReconciliationRepository
import com.batchfee.edu.data.repository.MonthlyFeeAllocationRequest
import com.batchfee.edu.domain.FeeMonthStatus
import com.batchfee.edu.domain.MonthlyFeeSchedule
import com.batchfee.edu.domain.ReceiptDocument
import com.batchfee.edu.domain.ReceiptPresentation
import com.batchfee.edu.domain.SessionManager
import com.batchfee.edu.domain.SmartFeeMonth
import com.batchfee.edu.domain.SmartFeePeriodPlanner
import com.batchfee.edu.domain.MonthlyFeeSnapshot
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.URLEncoder
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private val BgColor = Color(0xFF07111F)
private val CardBg = Color(0xFF0F172A)
private val CardBgAlt = Color(0xFF111827)
private val BorderSub = Color(0xFF1E293B)
private val Cyan = Color(0xFF22D3EE)
private val ElectricBlue = Color(0xFF3B82F6)
private val TextWhite = Color(0xFFF8FAFC)
private val TextMuted = Color(0xFF94A3B8)
private val AccentGreen = Color(0xFF22C55E)
private val AccentRed = Color(0xFFEF4444)
private val AccentAmber = Color(0xFFF59E0B)

data class EnrichedDue(val fee: FeeEntity, val studentName: String, val batchName: String?)

private data class StudentPaymentHistory(
    val payment: PaymentEntity,
    val receipt: ReceiptEntity?,
    val fee: FeeEntity?,
    val feePeriod: String,
    val batchId: String?,
    val batchName: String?,
    val baseAmount: Double,
    val discountAmount: Double,
    val totalAmount: Double,
    val remainingDue: Double
)

private data class PaymentEditRequest(
    val amount: Double,
    val method: String,
    val note: String,
    val feePeriod: String,
    val batchId: String?,
    val batchName: String?,
    val paymentDateMs: Long
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnifiedCollectScreen(
    db: AppDatabase,
    onBack: () -> Unit,
    onCollectPayment: (String) -> Unit = {}
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val feeRepository = remember { FeeCollectionRepository(db) }

    var instituteInfo by remember { mutableStateOf(InstituteInfo("BatchFee", "N/A", "BF")) }
    var instituteProfile by remember { mutableStateOf<InstituteEntity?>(null) }
    LaunchedEffect(Unit) {
        val instId = SessionManager.currentInstituteId.value
        if (instId != null) {
            val entity = withContext(Dispatchers.IO) { db.instituteDao().getInstitute(instId) }
            if (entity != null) {
                instituteProfile = entity
                instituteInfo = InstituteInfo(
                    name = entity.name.ifBlank { "BatchFee Institute" },
                    phone = entity.phone ?: "N/A",
                    logoText = entity.name.take(2).uppercase()
                )
            }
        }
    }

    var searchQuery by remember { mutableStateOf("") }
    var allStudents by remember { mutableStateOf<List<StudentEntity>>(emptyList()) }
    var selectedStudent by remember { mutableStateOf<StudentEntity?>(null) }
    var studentAllFees by remember { mutableStateOf<List<FeeEntity>>(emptyList()) }
    var studentDues by remember { mutableStateOf<List<EnrichedDue>>(emptyList()) }
    var studentBatches by remember { mutableStateOf<List<BatchEntity>>(emptyList()) }
    var paymentHistory by remember { mutableStateOf<List<StudentPaymentHistory>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var loadingLedger by remember { mutableStateOf(false) }
    var isSaving by remember { mutableStateOf(false) }

    var hasExistingDues by remember { mutableStateOf(false) }
    var showDueSelector by remember { mutableStateOf(false) }
    var showPeriodPicker by remember { mutableStateOf(false) }
    var collectionMode by remember { mutableStateOf("AUTO") }
    var customSelectedMonths by remember { mutableStateOf<Set<String>>(emptySet()) }
    var customAmounts by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var customDiscounts by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var enrollmentJoinedAtByBatch by remember { mutableStateOf<Map<String, Long>>(emptyMap()) }
    var showEarlierDueConfirmation by remember { mutableStateOf(false) }
    var customSkipConfirmed by remember { mutableStateOf(false) }
    var selectedDueId by remember { mutableStateOf<String?>(null) }
    var selectedBatchId by remember { mutableStateOf<String?>(null) }
    var feePeriod by remember { mutableStateOf(monthLabelForOffset(0)) }
    val monthOptions = remember { generateMonthOptions() }
    val currentMonthIdx = remember {
        val cal = Calendar.getInstance()
        val curMonth = cal.get(Calendar.MONTH) + 1
        val curYear = cal.get(Calendar.YEAR)
        monthOptions.indexOfFirst { it.month == curMonth && it.year == curYear }.coerceAtLeast(0)
    }
    var startMonthIdx by remember { mutableIntStateOf(currentMonthIdx) }
    var endMonthIdx by remember { mutableIntStateOf(currentMonthIdx) }
    var baseAmount by remember { mutableStateOf("") }
    var discountPercent by remember { mutableDoubleStateOf(0.0) }
    var collectAmount by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("cash") }
    var transactionReference by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var collectError by remember { mutableStateOf<String?>(null) }
    var editingHistoryItem by remember { mutableStateOf<StudentPaymentHistory?>(null) }

    val selectedBatch = studentBatches.firstOrNull { it.id == selectedBatchId }
    val selectedDue = studentDues.firstOrNull { it.fee.id == selectedDueId } ?: studentDues.firstOrNull()
    val monthlyFeeRepository = remember(db) { MonthlyFeeReconciliationRepository(db) }
    val currentBillingMonth = remember { MonthlyFeeSchedule.billingMonthAt(System.currentTimeMillis()) }
    val availableBillingMonths = remember(monthOptions) {
        monthOptions.map { MonthlyFeeSchedule.BillingMonth(it.year, it.month) }
    }
    val smartFeeMonths = remember(selectedStudent, selectedBatch, studentAllFees, enrollmentJoinedAtByBatch) {
        val student = selectedStudent
        val batch = selectedBatch
        if (student == null || batch == null || batch.monthlyFeeAmount <= 0.0) {
            emptyList()
        } else {
            val snapshots = studentAllFees
                .filter { it.batchId == batch.id && it.cancelledAtMs == null }
                .mapNotNull { fee -> fee.toMonthlyFeeSnapshotOrNull() }
            SmartFeePeriodPlanner.buildMonths(
                availableMonths = availableBillingMonths,
                admissionDateMs = student.admissionDateMs,
                joinedAtMs = enrollmentJoinedAtByBatch[batch.id] ?: student.admissionDateMs,
                monthlyAmount = batch.monthlyFeeAmount,
                feeSnapshots = snapshots,
                nowMs = System.currentTimeMillis()
            )
        }
    }

    fun amountText(value: Double): String =
        if (value <= 0.0) "" else "%.0f".format(value)

    fun calcNewFeeBase(batch: BatchEntity? = selectedBatch, months: Int = 1): Double {
        val monthlyFee = batch?.monthlyFeeAmount ?: 0.0
        return monthlyFee * months.coerceAtLeast(1)
    }

    fun numSelectedMonths(): Int {
        val realStart = if (startMonthIdx >= 0) startMonthIdx else currentMonthIdx
        val realEnd = if (endMonthIdx >= 0) endMonthIdx else currentMonthIdx
        return if (realEnd >= realStart) realEnd - realStart + 1 else 1
    }

    val autoFeeType = remember(startMonthIdx, endMonthIdx) {
        autoDetectFeeType(startMonthIdx, endMonthIdx, currentMonthIdx)
    }

    fun resetFormForNewFee() {
        showDueSelector = false
        selectedDueId = null
        startMonthIdx = currentMonthIdx
        endMonthIdx = currentMonthIdx
        val nextBase = calcNewFeeBase(selectedBatch)
        baseAmount = amountText(nextBase)
        discountPercent = 0.0
        collectAmount = amountText(nextBase)
        collectError = null
        transactionReference = ""
        note = ""
        feePeriod = buildFeePeriodLabel(startMonthIdx, endMonthIdx, monthOptions)
    }

    fun applyDueFeeSelection(due: EnrichedDue) {
        showDueSelector = true
        selectedDueId = due.fee.id
        feePeriod = due.fee.feePeriod
        baseAmount = amountText(due.fee.totalAmount)
        discountPercent = 0.0
        collectAmount = amountText(due.fee.dueAmount)
        collectError = null
    }

    fun onPeriodConfirmed(startIdx: Int, endIdx: Int) {
        startMonthIdx = minOf(startIdx, endIdx)
        endMonthIdx = maxOf(startIdx, endIdx)
        val months = (endMonthIdx - startMonthIdx + 1).coerceAtLeast(1)
        feePeriod = buildFeePeriodLabel(startMonthIdx, endMonthIdx, monthOptions)
        val nextBase = calcNewFeeBase(selectedBatch, months)
        baseAmount = amountText(nextBase)
        collectAmount = amountText(nextBase)
        showPeriodPicker = false
    }

    fun loadStudentLedger(student: StudentEntity) {
        selectedStudent = student
        scope.launch {
            loadingLedger = true
            collectError = null
            val instId = SessionManager.currentInstituteId.value
            if (instId == null) {
                loadingLedger = false
                collectError = "No active institute session."
                return@launch
            }
            InstituteCacheRefreshManager.refreshIfStale(db, instId)

            val allFees = withContext(Dispatchers.IO) {
                db.feeDao().getAllFeesOnce(instId)
                    .filter { it.studentId == student.id && it.cancelledAtMs == null }
            }
            val batches = withContext(Dispatchers.IO) {
                db.batchStudentDao().getBatchesForStudent(student.id, instId).first()
            }
            val joinedAtByBatch = withContext(Dispatchers.IO) {
                db.batchStudentDao().getActiveEnrollmentsOnce(instId)
                    .filter { it.studentId == student.id }
                    .associate { it.batchId to it.joinedAtMs }
            }
            val batchMap = withContext(Dispatchers.IO) {
                db.batchDao().getBatchesByInstituteOnce(instId).associateBy { it.id }
            }
            val payments = withContext(Dispatchers.IO) {
                db.paymentDao().getAllPaymentsOnce(instId)
                    .filter { it.studentId == student.id }
                    .sortedByDescending { it.paymentDateMs }
            }
            val receiptsByPayment = withContext(Dispatchers.IO) {
                payments.associate { payment ->
                    payment.id to db.receiptDao().getReceiptByPaymentIdOnce(instId, payment.id)
                }
            }

            studentAllFees = allFees
            studentBatches = batches
            enrollmentJoinedAtByBatch = joinedAtByBatch
            if (selectedBatchId == null || batches.none { it.id == selectedBatchId }) {
                selectedBatchId = batches.firstOrNull()?.id
            }
            studentDues = allFees
                .filter { it.dueAmount > 0.0 }
                .sortedBy { it.dueDateMs }
                .map { fee -> EnrichedDue(fee, student.fullName, fee.batchId?.let { batchMap[it]?.name }) }
            paymentHistory = payments.map { payment ->
                val fee = allFees.firstOrNull { it.id == payment.feeId }
                StudentPaymentHistory(
                    payment = payment,
                    receipt = receiptsByPayment[payment.id],
                    fee = fee,
                    feePeriod = fee?.feePeriod ?: "Fee payment",
                    batchId = fee?.batchId,
                    batchName = fee?.batchId?.let { batchMap[it]?.name },
                    baseAmount = fee?.baseAmount ?: payment.amount,
                    discountAmount = fee?.discountAmount ?: 0.0,
                    totalAmount = fee?.totalAmount ?: payment.amount,
                    remainingDue = receiptsByPayment[payment.id]?.dueAmount ?: fee?.dueAmount ?: 0.0
                )
            }

            resetFormForNewFee()
            loadingLedger = false
        }
    }

    LaunchedEffect(selectedStudent?.id, selectedBatchId, smartFeeMonths) {
        val default = SmartFeePeriodPlanner.defaultStart(smartFeeMonths) ?: return@LaunchedEffect
        val index = monthOptions.indexOfFirst {
            it.year == default.period.year && it.month == default.period.month
        }
        if (index >= 0) {
            startMonthIdx = index
            endMonthIdx = index
            feePeriod = default.label
            customSelectedMonths = setOf(default.period.selectionKey())
            customAmounts = mapOf(default.period.selectionKey() to amountText(default.remainingDue))
            customDiscounts = emptyMap()
        }
    }

    LaunchedEffect(Unit) {
        val instId = SessionManager.currentInstituteId.value ?: return@LaunchedEffect
        InstituteCacheRefreshManager.refreshIfStale(db, instId)
        allStudents = withContext(Dispatchers.IO) {
            db.studentDao().getStudentsByInstituteOnce(instId)
        }
        isLoading = false
    }

    Scaffold(
        containerColor = BgColor,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (selectedStudent == null) "Fee Collection" else "Collect Payment",
                        color = TextWhite,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (selectedStudent != null) {
                                selectedStudent = null
                                studentAllFees = emptyList()
                                studentDues = emptyList()
                                paymentHistory = emptyList()
                                collectError = null
                            } else {
                                onBack()
                            }
                        }
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextWhite)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgColor)
            )
        }
    ) { padding ->
        val filteredStudents = remember(allStudents, searchQuery) {
            if (searchQuery.isBlank()) {
                allStudents
            } else {
                allStudents.filter { student ->
                    student.fullName.contains(searchQuery, ignoreCase = true) ||
                        student.studentCode.contains(searchQuery, ignoreCase = true) ||
                        (student.phone?.contains(searchQuery) == true)
                }
            }
        }

        when {
            isLoading -> {
                Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Cyan)
                }
            }
            selectedStudent == null -> {
                StudentSearchPane(
                    modifier = Modifier.padding(padding),
                    query = searchQuery,
                    students = filteredStudents,
                    onQueryChange = { searchQuery = it },
                    onStudentSelected = { loadStudentLedger(it) }
                )
            }
            else -> {
                val student = selectedStudent!!
                val totalDue = studentDues.sumOf { it.fee.dueAmount }
                val totalPaid = paymentHistory.sumOf { it.payment.amount }
                fun singleDocument(item: StudentPaymentHistory): ReceiptDocument? =
                    item.receipt?.let { receipt ->
                        ReceiptPresentation.create(
                            receipt = receipt,
                            payment = item.payment,
                            institute = instituteProfile,
                            student = student,
                            batch = item.batchId?.let { batchId -> studentBatches.firstOrNull { it.id == batchId } },
                            fee = item.fee,
                            collector = null,
                            staff = null
                        )
                    }
                fun documentForHistory(item: StudentPaymentHistory): ReceiptDocument? {
                    val selected = singleDocument(item) ?: return null
                    val grouped = paymentHistory
                        .filter { history ->
                            history.receipt?.receiptNumber == item.receipt?.receiptNumber &&
                                history.payment.studentId == item.payment.studentId &&
                                history.payment.id != item.payment.id
                        }
                        .mapNotNull(::singleDocument)
                    return ReceiptPresentation.consolidate(
                        listOf(selected) + grouped
                    )
                }
                val startPeriod = monthOptions.getOrNull(startMonthIdx)?.let { MonthlyFeeSchedule.BillingMonth(it.year, it.month) }
                val endPeriod = monthOptions.getOrNull(endMonthIdx)?.let { MonthlyFeeSchedule.BillingMonth(it.year, it.month) }
                val rangeMonths = if (startPeriod != null && endPeriod != null) {
                    SmartFeePeriodPlanner.range(smartFeeMonths, startPeriod, endPeriod)
                } else emptyList()
                val selectedMonths = if (collectionMode == "CUSTOM") {
                    rangeMonths.filter { it.period.selectionKey() in customSelectedMonths && it.enabled }
                } else {
                    SmartFeePeriodPlanner.autoSelection(rangeMonths)
                }
                val automaticReceived = collectAmount.toDoubleOrNull() ?: 0.0
                val plannedAllocations = if (collectionMode == "CUSTOM") {
                    selectedMonths.mapNotNull { month ->
                        val key = month.period.selectionKey()
                        val amount = customAmounts[key]?.toDoubleOrNull() ?: 0.0
                        val discount = (customDiscounts[key]?.toDoubleOrNull() ?: 0.0).coerceIn(0.0, 100.0)
                        SmartFeePeriodPlanner.allocate(listOf(month), amount, discount, autoOrder = false).firstOrNull()
                    }
                } else {
                    SmartFeePeriodPlanner.allocate(selectedMonths, automaticReceived, discountPercent, autoOrder = true)
                }
                val collecting = plannedAllocations.sumOf { it.collectedAmount }
                val payable = selectedMonths.sumOf { month ->
                    val percent = if (collectionMode == "CUSTOM") {
                        (customDiscounts[month.period.selectionKey()]?.toDoubleOrNull() ?: 0.0).coerceIn(0.0, 100.0)
                    } else discountPercent
                    SmartFeePeriodPlanner.payableAfterDiscount(month, percent)
                }
                val discountAmount = selectedMonths.sumOf { month ->
                    val fee = month.fee
                    val percent = if (collectionMode == "CUSTOM") {
                        (customDiscounts[month.period.selectionKey()]?.toDoubleOrNull() ?: 0.0).coerceIn(0.0, 100.0)
                    } else discountPercent
                    ((fee?.baseAmount ?: month.monthlyAmount) * percent / 100.0 - (fee?.discountAmount ?: 0.0)).coerceAtLeast(0.0)
                }
                val remainingAfterPayment = (payable - collecting).coerceAtLeast(0.0)
                val canSave = !loadingLedger && !isSaving && selectedBatch != null && plannedAllocations.isNotEmpty() &&
                    plannedAllocations.all { it.collectedAmount > 0.0 || it.discountPercent >= 100.0 }

                LaunchedEffect(collectionMode, startMonthIdx, endMonthIdx, selectedBatchId, discountPercent, smartFeeMonths) {
                    if (collectionMode == "AUTO") {
                        val autoSelected = SmartFeePeriodPlanner.autoSelection(rangeMonths)
                        collectAmount = amountText(autoSelected.sumOf { SmartFeePeriodPlanner.payableAfterDiscount(it, discountPercent) })
                    }
                }

                if (showEarlierDueConfirmation) {
                    AlertDialog(
                        onDismissRequest = { showEarlierDueConfirmation = false },
                        containerColor = CardBg,
                        title = { Text("Earlier due remains", color = TextWhite) },
                        text = { Text("An earlier due month is still unpaid. Continue with this custom allocation?", color = TextMuted) },
                        confirmButton = {
                            TextButton(onClick = {
                                customSkipConfirmed = true
                                showEarlierDueConfirmation = false
                            }) { Text("Continue", color = Cyan) }
                        },
                        dismissButton = { TextButton(onClick = { showEarlierDueConfirmation = false }) { Text("Cancel", color = TextMuted) } }
                    )
                }

                if (showPeriodPicker) {
                    val disabledIndices = smartFeeMonths.filter { it.status == FeeMonthStatus.DISABLED }.mapNotNull { month ->
                        monthOptions.indexOfFirst { it.year == month.period.year && it.month == month.period.month }.takeIf { it >= 0 }
                    }.toSet()
                    val statusByIndex = smartFeeMonths.mapNotNull { month ->
                        monthOptions.indexOfFirst { it.year == month.period.year && it.month == month.period.month }
                            .takeIf { it >= 0 }
                            ?.let { it to month.status }
                    }.toMap()
                    MonthYearRangePicker(
                        selectedStartIdx = startMonthIdx,
                        selectedEndIdx = endMonthIdx,
                        monthOptions = monthOptions,
                        currentMonthIdx = currentMonthIdx,
                        disabledIndices = disabledIndices,
                        statusByIndex = statusByIndex,
                        onDismiss = { showPeriodPicker = false },
                        onConfirm = { start, end ->
                            startMonthIdx = start
                            endMonthIdx = end
                            customSkipConfirmed = false
                            feePeriod = buildFeePeriodLabel(start, end, monthOptions)
                            if (collectionMode == "AUTO") {
                                val selected = SmartFeePeriodPlanner.range(
                                    smartFeeMonths,
                                    MonthlyFeeSchedule.BillingMonth(monthOptions[start].year, monthOptions[start].month),
                                    MonthlyFeeSchedule.BillingMonth(monthOptions[end].year, monthOptions[end].month)
                                )
                                collectAmount = amountText(selected.sumOf { SmartFeePeriodPlanner.payableAfterDiscount(it, discountPercent) })
                            }
                            showPeriodPicker = false
                        }
                    )
                }

                LazyColumn(
                    modifier = Modifier.padding(padding).fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 28.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        StudentLedgerHeader(
                            student = student,
                            totalDue = totalDue,
                            totalPaid = totalPaid,
                            paymentCount = paymentHistory.size
                        )
                    }

                    if (loadingLedger) {
                        item {
                            Box(Modifier.fillMaxWidth().padding(vertical = 26.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = Cyan, modifier = Modifier.size(26.dp))
                            }
                        }
                    } else {
                        item {
                            PaymentHistoryCard(
                                history = paymentHistory,
                                onPrint = { item ->
                                    documentForHistory(item)?.let { openReceiptDocument(context, it) }
                                        ?: printHistoryReceipt(context, instituteInfo, student, item)
                                },
                                onWhatsApp = { item ->
                                    documentForHistory(item)?.let { shareReceiptDocumentPdf(context, it, student.phone) }
                                        ?: sendHistoryReceiptWhatsApp(context, instituteInfo, student, student.phone, item)
                                },
                                onMessage = { item -> sendHistoryReceiptMessage(context, student.phone, buildHistoryReceiptText(instituteInfo, student, item)) },
                                onShare = { item ->
                                    documentForHistory(item)?.let { shareReceiptImageAny(context, createReceiptDocumentBitmap(context, it)) }
                                        ?: shareHistoryReceipt(context, buildHistoryReceiptText(instituteInfo, student, item))
                                },
                                onEdit = { item -> editingHistoryItem = item }
                            )
                        }

                        item {
                            SmartMonthlyFeeForm(
                                batches = studentBatches,
                                selectedBatchId = selectedBatchId,
                                startMonthIdx = startMonthIdx,
                                endMonthIdx = endMonthIdx,
                                monthOptions = monthOptions,
                                months = smartFeeMonths,
                                mode = collectionMode,
                                discountPercent = discountPercent,
                                customSelectedMonths = customSelectedMonths,
                                customAmounts = customAmounts,
                                customDiscounts = customDiscounts,
                                onBatchSelected = { batch ->
                                    selectedBatchId = batch.id
                                    customSkipConfirmed = false
                                },
                                onPeriodClick = { showPeriodPicker = true },
                                onModeChange = { collectionMode = it },
                                onDiscountChange = { discountPercent = it.coerceIn(0.0, 100.0) },
                                onCustomSelectionChange = { month, selected ->
                                    val key = month.period.selectionKey()
                                    customSkipConfirmed = false
                                    customSelectedMonths = if (selected) customSelectedMonths + key else customSelectedMonths - key
                                    if (selected && key !in customAmounts) {
                                        customAmounts = customAmounts + (key to amountText(month.remainingDue))
                                    }
                                },
                                onCustomAmountChange = { month, value ->
                                    customAmounts = customAmounts + (month.period.selectionKey() to moneyInput(value))
                                },
                                onCustomDiscountChange = { month, value ->
                                    customDiscounts = customDiscounts + (month.period.selectionKey() to moneyInput(value))
                                }
                            )
                        }

                        item {
                            PaymentInputCard(
                                isDuePayment = false,
                                selectedDue = null,
                                payable = payable,
                                discountAmount = discountAmount,
                                collectAmount = if (collectionMode == "CUSTOM") amountText(collecting) else collectAmount,
                                paymentMethod = paymentMethod,
                                transactionReference = transactionReference,
                                note = note,
                                remainingAfterPayment = remainingAfterPayment,
                                onCollectAmountChange = { if (collectionMode == "AUTO") collectAmount = moneyInput(it) },
                                onMethodChange = { paymentMethod = it },
                                onTransactionReferenceChange = { transactionReference = it },
                                onNoteChange = { note = it },
                                amountEditable = collectionMode == "AUTO"
                            )
                        }

                        if (collectError != null) {
                            item {
                                Text(
                                    collectError ?: "",
                                    color = AccentRed,
                                    fontSize = 13.sp,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }

                        item {
                            Button(
                                onClick = {
                                    collectError = null
                                    if (isSaving) return@Button
                                    val instId = SessionManager.currentInstituteId.value
                                    val userId = SessionManager.currentUserId.value
                                    if (instId == null || userId == null) {
                                        collectError = "No active session."
                                        return@Button
                                    }
                                    if (selectedBatch == null || plannedAllocations.isEmpty()) {
                                        collectError = "Select at least one payable fee month."
                                        return@Button
                                    }
                                    if (collectionMode == "CUSTOM" && !customSkipConfirmed && SmartFeePeriodPlanner.hasEarlierUnselectedDue(selectedMonths, smartFeeMonths)) {
                                        showEarlierDueConfirmation = true
                                        return@Button
                                    }
                                    isSaving = true
                                    scope.launch {
                                        try {
                                            val now = System.currentTimeMillis()
                                            val missingMonths = plannedAllocations.filter { it.feeId == null }.map { it.period }
                                            val ensured = if (missingMonths.isEmpty()) emptyList() else {
                                                monthlyFeeRepository.ensureMonthlyObligations(
                                                    instituteId = instId,
                                                    studentId = student.id,
                                                    batchId = selectedBatch.id,
                                                    monthlyAmount = selectedBatch.monthlyFeeAmount,
                                                    months = missingMonths,
                                                    now = now
                                                )
                                            }
                                            val ensuredByPeriod = ensured.associateBy { fee ->
                                                MonthlyFeeSchedule.billingMonthAt(fee.dueDateMs)
                                            }
                                            val requests = plannedAllocations.map { allocation ->
                                                MonthlyFeeAllocationRequest(
                                                    feeId = allocation.feeId ?: ensuredByPeriod[allocation.period]?.id
                                                        ?: throw IllegalArgumentException("Could not prepare ${MonthlyFeeSchedule.monthLabel(allocation.period.year, allocation.period.month)}."),
                                                    collectedAmount = allocation.collectedAmount,
                                                    discountPercent = allocation.discountPercent
                                                )
                                            }
                                            val results = feeRepository.collectMonthlyAllocations(
                                                instituteId = instId,
                                                collectedByUserId = userId,
                                                studentId = student.id,
                                                allocations = requests,
                                                paymentMethod = paymentMethod,
                                                transactionId = transactionReference.ifBlank { null },
                                                note = note.ifBlank { null },
                                                now = now
                                            )
                                            val receiptCount = results.count { it.receiptNumber != null }
                                            snackbarHostState.showSnackbar("Saved $receiptCount month payment${if (receiptCount == 1) "" else "s"}.")
                                            note = ""
                                            transactionReference = ""
                                            customSkipConfirmed = false
                                            loadStudentLedger(student)
                                        } catch (e: IllegalArgumentException) {
                                            collectError = e.message ?: "Payment rejected."
                                        } finally {
                                            isSaving = false
                                        }
                                    }
                                },
                                enabled = canSave,
                                modifier = Modifier.fillMaxWidth().height(52.dp),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ElectricBlue,
                                    disabledContainerColor = CardBgAlt,
                                    contentColor = Color.White,
                                    disabledContentColor = TextMuted
                                )
                            ) {
                                Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(if (isSaving) "Saving..." else "Save Payment", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    editingHistoryItem?.let { item ->
        val student = selectedStudent
        EditPaymentDialog(
            item = item,
            batches = studentBatches,
            onDismiss = { editingHistoryItem = null },
            onSave = { editRequest ->
                if (student == null) return@EditPaymentDialog
                scope.launch {
                    val instId = SessionManager.currentInstituteId.value
                    if (instId == null) {
                        snackbarHostState.showSnackbar("No active institute session.")
                        return@launch
                    }
                    if (editRequest.amount <= 0.0) {
                        snackbarHostState.showSnackbar("Enter a valid payment amount.")
                        return@launch
                    }
                    if (editRequest.feePeriod.isBlank()) {
                        snackbarHostState.showSnackbar("Enter fee month/period.")
                        return@launch
                    }
                    try {
                        val payment = item.payment
                        val fee = db.feeDao().getFeeById(payment.feeId, instId)
                        if (fee == null) {
                            snackbarHostState.showSnackbar("Fee record not found.")
                            return@launch
                        }
                        val allPaymentsForFee = db.paymentDao().getAllPaymentsOnce(instId)
                            .filter { it.feeId == fee.id && it.status == "completed" }
                        val updatedPaid = allPaymentsForFee.sumOf {
                            if (it.id == payment.id) editRequest.amount else it.amount
                        }
                        if (updatedPaid - fee.totalAmount > 0.001) {
                            snackbarHostState.showSnackbar("Payment rejected - amount exceeds payable fee.")
                            return@launch
                        }
                        val updatedDue = (fee.totalAmount - updatedPaid).coerceAtLeast(0.0)
                        val updatedFee = fee.copy(
                            batchId = editRequest.batchId,
                            feePeriod = editRequest.feePeriod.trim(),
                            dueDateMs = editRequest.paymentDateMs,
                            paidAmount = updatedPaid,
                            dueAmount = updatedDue,
                            status = when {
                                updatedDue <= 0.001 -> "paid"
                                updatedPaid > 0.001 -> "partially_paid"
                                else -> "unpaid"
                            },
                            updatedAtMs = System.currentTimeMillis()
                        )
                        FinanceSyncHelper.upsertFee(updatedFee)
                        db.feeDao().updateFee(updatedFee)
                        val updatedPayment = payment.copy(
                            amount = editRequest.amount,
                            paymentMethod = editRequest.method,
                            paymentDateMs = editRequest.paymentDateMs,
                            note = editRequest.note.ifBlank { null },
                            updatedAtMs = System.currentTimeMillis()
                        )
                        FinanceSyncHelper.upsertPayment(updatedPayment)
                        db.paymentDao().insertPayment(updatedPayment)
                        db.receiptDao().getReceiptByPaymentIdOnce(instId, payment.id)?.let { receipt ->
                            val updatedReceipt = receipt.copy(
                                totalAmount = updatedFee.totalAmount,
                                paidAmount = updatedPaid,
                                dueAmount = updatedDue,
                                receiptDateMs = editRequest.paymentDateMs,
                                paymentMethod = editRequest.method,
                                receiptText = buildHistoryReceiptText(
                                    institute = instituteInfo,
                                    student = student,
                                    item = item.copy(
                                        payment = updatedPayment,
                                        feePeriod = editRequest.feePeriod.trim(),
                                        batchId = editRequest.batchId,
                                        batchName = editRequest.batchName,
                                        remainingDue = updatedDue
                                    )
                                )
                            )
                            FinanceSyncHelper.upsertReceipt(updatedReceipt)
                            db.receiptDao().insertReceipt(updatedReceipt)
                        }
                        editingHistoryItem = null
                        loadStudentLedger(student)
                        snackbarHostState.showSnackbar("Payment history updated.")
                    } catch (e: Exception) {
                        snackbarHostState.showSnackbar(e.message ?: "Could not update payment.")
                    }
                }
            }
        )
    }
}

@Composable
private fun StudentSearchPane(
    modifier: Modifier,
    query: String,
    students: List<StudentEntity>,
    onQueryChange: (String) -> Unit,
    onStudentSelected: (StudentEntity) -> Unit
) {
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text("Find student", color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        Spacer(Modifier.height(8.dp))
        SmartTextField(
            value = query,
            onValueChange = onQueryChange,
            placeholder = "Name, ID, or phone",
            leadingIcon = Icons.Filled.Search
        )
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(students, key = { it.id }) { student ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CardBg),
                    border = BorderStroke(1.dp, BorderSub)
                ) {
                    Column(Modifier.padding(14.dp).fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            InitialAvatar(student.fullName)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(student.fullName, color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                                Text(
                                    listOf(student.studentCode, student.phone).filterNotNull().filter { it.isNotBlank() }.joinToString("  |  "),
                                    color = TextMuted,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = { onStudentSelected(student) },
                            modifier = Modifier.fillMaxWidth().height(42.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                        ) {
                            Icon(Icons.Filled.Payments, contentDescription = null, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Collect Payment", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            if (students.isEmpty() && query.isNotBlank()) {
                item { Text("No students found.", color = TextMuted, modifier = Modifier.padding(20.dp)) }
            }
        }
    }
}

@Composable
private fun StudentLedgerHeader(
    student: StudentEntity,
    totalDue: Double,
    totalPaid: Double,
    paymentCount: Int
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, BorderSub)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                InitialAvatar(student.fullName)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(student.fullName, color = TextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(student.studentCode, color = TextMuted, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                LedgerStat("Due", formatSmartAmount(totalDue), AccentRed, Modifier.weight(1f))
                LedgerStat("Paid", formatSmartAmount(totalPaid), AccentGreen, Modifier.weight(1f))
                LedgerStat("Payments", paymentCount.toString(), Cyan, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun LedgerStat(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(CardBgAlt)
            .border(1.dp, BorderSub, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Text(label, color = TextMuted, fontSize = 11.sp)
        Spacer(Modifier.height(4.dp))
        Text(value, color = color, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun PaymentHistoryCard(
    history: List<StudentPaymentHistory>,
    onPrint: (StudentPaymentHistory) -> Unit,
    onWhatsApp: (StudentPaymentHistory) -> Unit,
    onMessage: (StudentPaymentHistory) -> Unit,
    onShare: (StudentPaymentHistory) -> Unit,
    onEdit: (StudentPaymentHistory) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, BorderSub)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.History, contentDescription = null, tint = Cyan, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Payment History", color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            if (history.isEmpty()) {
                Text("No payment recorded yet.", color = TextMuted, fontSize = 13.sp)
            } else {
                history.take(6).forEachIndexed { index, item ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 9.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    item.feePeriod,
                                    color = TextWhite,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    listOfNotNull(item.batchName, item.payment.paymentMethod.uppercase(), item.payment.receiptNumber)
                                        .joinToString(" | "),
                                    color = TextMuted,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(formatSmartAmount(item.payment.amount), color = AccentGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(formatDate(item.payment.paymentDateMs), color = TextMuted, fontSize = 11.sp)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            item {
                                HistoryActionButton("Print", Icons.Filled.Print, Cyan) { onPrint(item) }
                            }
                            item {
                                HistoryActionButton("WhatsApp", Icons.Filled.Message, AccentGreen) { onWhatsApp(item) }
                            }
                            item {
                                HistoryActionButton("Message", Icons.Filled.Message, TextMuted) { onMessage(item) }
                            }
                            item {
                                HistoryActionButton("Share", Icons.Filled.Share, ElectricBlue) { onShare(item) }
                            }
                            item {
                                HistoryActionButton("Edit", Icons.Filled.Payments, AccentAmber) { onEdit(item) }
                            }
                        }
                    }
                    if (index != history.take(6).lastIndex) HorizontalDivider(color = BorderSub)
                }
            }
        }
    }
}

@Composable
private fun HistoryActionButton(
    label: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .border(1.dp, color.copy(alpha = 0.65f), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(15.dp))
        Spacer(Modifier.width(5.dp))
        Text(label, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun EditPaymentDialog(
    item: StudentPaymentHistory,
    batches: List<BatchEntity>,
    onDismiss: () -> Unit,
    onSave: (PaymentEditRequest) -> Unit
) {
    var amount by remember(item.payment.id) { mutableStateOf("%.0f".format(item.payment.amount)) }
    var method by remember(item.payment.id) { mutableStateOf(item.payment.paymentMethod) }
    var note by remember(item.payment.id) { mutableStateOf(item.payment.note.orEmpty()) }
    var feePeriod by remember(item.payment.id) { mutableStateOf(item.feePeriod) }
    var paymentDate by remember(item.payment.id) { mutableStateOf(formatEditDate(item.payment.paymentDateMs)) }
    var selectedBatchId by remember(item.payment.id) { mutableStateOf(item.batchId) }
    val selectedBatch = batches.firstOrNull { it.id == selectedBatchId }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardBg,
        title = { Text("Edit Payment", color = TextWhite, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(item.payment.receiptNumber, color = TextMuted, fontSize = 12.sp)
                SmartTextField(
                    value = amount,
                    onValueChange = { amount = moneyInput(it) },
                    placeholder = "Payment amount",
                    keyboardType = KeyboardType.Decimal
                )
                SmartTextField(
                    value = paymentDate,
                    onValueChange = { paymentDate = it },
                    placeholder = "Payment date (dd/MM/yyyy)"
                )
                SmartTextField(
                    value = feePeriod,
                    onValueChange = { feePeriod = it },
                    placeholder = "Fee month / period"
                )
                Text("Batch", color = TextMuted, fontSize = 12.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(
                            selected = selectedBatchId == null,
                            onClick = { selectedBatchId = null },
                            label = { Text("Direct") },
                            colors = smartChipColors()
                        )
                    }
                    items(batches, key = { it.id }) { batch ->
                        FilterChip(
                            selected = selectedBatchId == batch.id,
                            onClick = { selectedBatchId = batch.id },
                            label = { Text(batch.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            colors = smartChipColors()
                        )
                    }
                }
                Text("Payment Method", color = TextMuted, fontSize = 12.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("cash", "bkash", "nagad", "bank")) { option ->
                        FilterChip(
                            selected = method == option,
                            onClick = { method = option },
                            label = { Text(option.replaceFirstChar { it.uppercase() }) },
                            colors = smartChipColors()
                        )
                    }
                }
                SmartTextField(
                    value = note,
                    onValueChange = { note = it },
                    placeholder = "Note or transaction reference"
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onSave(
                        PaymentEditRequest(
                            amount = amount.toDoubleOrNull() ?: 0.0,
                            method = method,
                            note = note,
                            feePeriod = feePeriod,
                            batchId = selectedBatchId,
                            batchName = selectedBatch?.name,
                            paymentDateMs = parseEditDate(paymentDate) ?: item.payment.paymentDateMs
                        )
                    )
                }
            ) {
                Text("Save", color = Cyan, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextMuted)
            }
        }
    )
}

@Composable
private fun ExistingDueSelector(
    dues: List<EnrichedDue>,
    selectedDueId: String?,
    onSelect: (EnrichedDue) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, BorderSub)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("Select Due Fee", color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            if (dues.isEmpty()) {
                Text("No pending due fee. Use Running month or Advance fee.", color = TextMuted, fontSize = 13.sp)
            } else {
                dues.forEach { due ->
                    val selected = due.fee.id == selectedDueId
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (selected) ElectricBlue.copy(alpha = 0.18f) else CardBgAlt)
                            .border(1.dp, if (selected) Cyan else BorderSub, RoundedCornerShape(12.dp))
                            .clickable { onSelect(due) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(due.fee.feePeriod, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(due.batchName ?: due.fee.feeType, color = TextMuted, fontSize = 11.sp)
                        }
                        Text(formatSmartAmount(due.fee.dueAmount), color = AccentRed, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
private fun SmartMonthlyFeeForm(
    batches: List<BatchEntity>,
    selectedBatchId: String?,
    startMonthIdx: Int,
    endMonthIdx: Int,
    monthOptions: List<UcMonthYear>,
    months: List<SmartFeeMonth>,
    mode: String,
    discountPercent: Double,
    customSelectedMonths: Set<String>,
    customAmounts: Map<String, String>,
    customDiscounts: Map<String, String>,
    onBatchSelected: (BatchEntity) -> Unit,
    onPeriodClick: () -> Unit,
    onModeChange: (String) -> Unit,
    onDiscountChange: (Double) -> Unit,
    onCustomSelectionChange: (SmartFeeMonth, Boolean) -> Unit,
    onCustomAmountChange: (SmartFeeMonth, String) -> Unit,
    onCustomDiscountChange: (SmartFeeMonth, String) -> Unit
) {
    val start = monthOptions.getOrNull(startMonthIdx)
    val end = monthOptions.getOrNull(endMonthIdx)
    val selectedRange = if (start != null && end != null) {
        SmartFeePeriodPlanner.range(
            months,
            MonthlyFeeSchedule.BillingMonth(start.year, start.month),
            MonthlyFeeSchedule.BillingMonth(end.year, end.month)
        )
    } else emptyList()
    val statusSummary = listOf(FeeMonthStatus.DUE, FeeMonthStatus.CURRENT, FeeMonthStatus.ADVANCE, FeeMonthStatus.PARTIAL)
        .mapNotNull { status ->
            selectedRange.count { it.status == status }.takeIf { it > 0 }?.let { "$it ${status.monthStatusLabel()}" }
        }
        .joinToString(" • ")

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, BorderSub)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Fee Period Details", color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            if (batches.isEmpty()) {
                Text("No active batch assigned. Monthly collection requires a batch fee.", color = AccentAmber, fontSize = 12.sp)
            } else {
                Text("Batch", color = TextMuted, fontSize = 12.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(batches, key = { it.id }) { batch ->
                        FilterChip(
                            selected = selectedBatchId == batch.id,
                            onClick = { onBatchSelected(batch) },
                            label = { Text("${batch.name} (${formatSmartAmount(batch.monthlyFeeAmount)})", maxLines = 1) },
                            colors = smartChipColors()
                        )
                    }
                }
            }

            Text("Fee Period", color = TextMuted, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onPeriodClick, modifier = Modifier.weight(1f)) {
                    Column(horizontalAlignment = Alignment.Start) {
                        Text("Start Month", fontSize = 10.sp, color = TextMuted)
                        Text(start?.label ?: "Select", color = TextWhite, fontSize = 13.sp)
                    }
                }
                OutlinedButton(onClick = onPeriodClick, modifier = Modifier.weight(1f)) {
                    Column(horizontalAlignment = Alignment.Start) {
                        Text("End Month", fontSize = 10.sp, color = TextMuted)
                        Text(end?.label ?: "Select", color = TextWhite, fontSize = 13.sp)
                    }
                }
            }
            Text(
                listOfNotNull(
                    buildFeePeriodLabel(startMonthIdx, endMonthIdx, monthOptions).takeIf { it.isNotBlank() },
                    statusSummary.takeIf { it.isNotBlank() }
                ).joinToString(" • "),
                color = Cyan.copy(alpha = 0.85f),
                fontSize = 12.sp
            )

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("AUTO", "CUSTOM").forEach { option ->
                    FilterChip(
                        selected = mode == option,
                        onClick = { onModeChange(option) },
                        label = { Text(option.lowercase().replaceFirstChar { it.uppercase() }) },
                        colors = smartChipColors()
                    )
                }
            }

            if (mode == "AUTO") {
                Text("Auto pays selected months oldest Partial → Due → Current → Advance.", color = TextMuted, fontSize = 11.sp)
                SmartTextField(
                    value = if (discountPercent == 0.0) "" else "%.0f".format(discountPercent),
                    onValueChange = { onDiscountChange(it.toDoubleOrNull() ?: 0.0) },
                    placeholder = "Discount % (selected months)",
                    keyboardType = KeyboardType.Number
                )
            } else {
                Text("Choose exact months and optional amount/discount for each. Unselected months remain due.", color = TextMuted, fontSize = 11.sp)
                selectedRange.filter { it.enabled }.forEach { month ->
                    val key = month.period.selectionKey()
                    val checked = key in customSelectedMonths
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(CardBgAlt)
                            .padding(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = checked, onCheckedChange = { onCustomSelectionChange(month, it) })
                            Column(Modifier.weight(1f)) {
                                Text(month.label, color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text("${month.status.monthStatusLabel()} • Remaining ${formatSmartAmount(month.remainingDue)}", color = TextMuted, fontSize = 11.sp)
                            }
                        }
                        if (checked) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                SmartTextField(
                                    value = customAmounts[key].orEmpty(),
                                    onValueChange = { onCustomAmountChange(month, it) },
                                    placeholder = "Amount",
                                    keyboardType = KeyboardType.Decimal,
                                    modifier = Modifier.weight(1f)
                                )
                                SmartTextField(
                                    value = customDiscounts[key].orEmpty(),
                                    onValueChange = { onCustomDiscountChange(month, it) },
                                    placeholder = "Discount %",
                                    keyboardType = KeyboardType.Number,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NewFeeForm(
    batches: List<BatchEntity>,
    selectedBatchId: String?,
    startMonthIdx: Int = 0,
    endMonthIdx: Int = 0,
    monthOptions: List<UcMonthYear> = emptyList(),
    feeType: String,
    baseAmount: String,
    discountPercent: Double,
    onBatchSelected: (BatchEntity?) -> Unit,
    onStartMonthChanged: (Int) -> Unit,
    onEndMonthChanged: (Int) -> Unit,
    onBaseAmountChange: (String) -> Unit,
    onDiscountChange: (Double) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, BorderSub)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("$feeType Details", color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)

            if (batches.isNotEmpty()) {
                Text("Batch", color = TextMuted, fontSize = 12.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(batches, key = { it.id }) { batch ->
                        FilterChip(
                            selected = selectedBatchId == batch.id,
                            onClick = { onBatchSelected(batch) },
                            label = { Text("${batch.name} (${formatSmartAmount(batch.monthlyFeeAmount)})", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            colors = smartChipColors()
                        )
                    }
                }
            } else {
                Text("No active batch assigned. This will be saved as a direct student fee.", color = TextMuted, fontSize = 12.sp)
            }

            Text("Fee Period", color = TextMuted, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MonthDropdown(
                    label = "Start Month",
                    selectedIdx = startMonthIdx,
                    monthOptions = monthOptions,
                    onSelected = onStartMonthChanged,
                    modifier = Modifier.weight(1f)
                )
                MonthDropdown(
                    label = "End Month",
                    selectedIdx = endMonthIdx,
                    monthOptions = monthOptions,
                    onSelected = onEndMonthChanged,
                    modifier = Modifier.weight(1f)
                )
            }
            val monthCount = (endMonthIdx - startMonthIdx + 1).coerceAtLeast(1)
            Text(
                "$monthCount Month${if (monthCount > 1) "s" else ""} • $feeType",
                color = Cyan.copy(alpha = 0.8f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                SmartTextField(
                    value = baseAmount,
                    onValueChange = onBaseAmountChange,
                    placeholder = "Fee amount",
                    keyboardType = KeyboardType.Decimal,
                    modifier = Modifier.weight(1f)
                )
                SmartTextField(
                    value = if (discountPercent == 0.0) "" else "%.0f".format(discountPercent),
                    onValueChange = { onDiscountChange(it.toDoubleOrNull() ?: 0.0) },
                    placeholder = "Discount %",
                    keyboardType = KeyboardType.Number,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun PaymentInputCard(
    isDuePayment: Boolean,
    selectedDue: EnrichedDue?,
    payable: Double,
    discountAmount: Double,
    collectAmount: String,
    paymentMethod: String,
    transactionReference: String,
    note: String,
    remainingAfterPayment: Double,
    onCollectAmountChange: (String) -> Unit,
    onMethodChange: (String) -> Unit,
    onTransactionReferenceChange: (String) -> Unit,
    onNoteChange: (String) -> Unit,
    amountEditable: Boolean = true
) {
    val dueAmount = selectedDue?.fee?.dueAmount ?: 0.0
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, BorderSub)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Payment", color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(CardBgAlt)
                    .border(1.dp, BorderSub, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                SummaryLine(
                    label = if (isDuePayment) "Selected due" else "Payable amount",
                    value = formatSmartAmount(if (isDuePayment) dueAmount else payable),
                    color = if (isDuePayment) AccentRed else TextWhite
                )
                if (!isDuePayment && discountAmount > 0.0) {
                    SummaryLine("Discount", "-${formatSmartAmount(discountAmount)}", AccentGreen)
                }
                SummaryLine("Remaining after payment", formatSmartAmount(remainingAfterPayment), if (remainingAfterPayment > 0.0) AccentAmber else AccentGreen)
            }

            if (amountEditable) {
                SmartTextField(
                    value = collectAmount,
                    onValueChange = onCollectAmountChange,
                    placeholder = "Collected amount",
                    keyboardType = KeyboardType.Decimal,
                    leadingIcon = Icons.Filled.Payments
                )
            } else {
                SummaryLine("Custom selected total", formatSmartAmount(collectAmount.toDoubleOrNull() ?: 0.0), Cyan)
            }

            Text("Payment Method", color = TextMuted, fontSize = 12.sp)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("cash", "bkash", "nagad", "bank")) { method ->
                    FilterChip(
                        selected = paymentMethod == method,
                        onClick = { onMethodChange(method) },
                        label = { Text(method.replaceFirstChar { it.uppercase() }) },
                        colors = smartChipColors()
                    )
                }
            }

            SmartTextField(
                value = transactionReference,
                onValueChange = onTransactionReferenceChange,
                placeholder = "Transaction / reference ID (optional)"
            )
            SmartTextField(
                value = note,
                onValueChange = onNoteChange,
                placeholder = "Remarks (optional)"
            )
        }
    }
}

@Composable
private fun SummaryLine(label: String, value: String, color: Color = TextWhite) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TextMuted, fontSize = 13.sp)
        Text(value, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun <T> PremiumMonthDropdown(
    label: String,
    options: List<T>,
    selectedOption: T?,
    onOptionSelected: (T) -> Unit,
    optionLabel: (T) -> String,
    enabled: Boolean = true
) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedTextField(
            value = selectedOption?.let(optionLabel) ?: "",
            onValueChange = {},
            readOnly = true,
            enabled = enabled,
            label = { Text(label, color = TextMuted) },
            trailingIcon = { Icon(Icons.Filled.ArrowDropDown, null, tint = TextMuted) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CardBg, unfocusedContainerColor = CardBg,
                focusedTextColor = TextWhite, unfocusedTextColor = TextWhite,
                focusedBorderColor = Cyan, unfocusedBorderColor = BorderSub
            ),
            shape = RoundedCornerShape(12.dp)
        )
        if (enabled) {
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .clickable { expanded = !expanded }
            )
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(CardBg).heightIn(max = 280.dp)
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(optionLabel(option), color = if (option == selectedOption) Cyan else TextWhite) },
                    onClick = { onOptionSelected(option); expanded = false }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SmartTextField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier.fillMaxWidth(),
    keyboardType: KeyboardType = KeyboardType.Text,
    leadingIcon: ImageVector? = null
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        placeholder = { Text(placeholder, color = TextMuted.copy(alpha = 0.55f)) },
        modifier = modifier,
        singleLine = true,
        leadingIcon = leadingIcon?.let { icon ->
            { Icon(icon, contentDescription = null, tint = TextMuted) }
        },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        textStyle = TextStyle(color = TextWhite, fontSize = 14.sp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = TextWhite,
            unfocusedTextColor = TextWhite,
            focusedBorderColor = ElectricBlue,
            unfocusedBorderColor = BorderSub,
            focusedContainerColor = CardBgAlt,
            unfocusedContainerColor = CardBgAlt,
            cursorColor = ElectricBlue
        ),
        shape = RoundedCornerShape(12.dp)
    )
}

@Composable
private fun InitialAvatar(name: String) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(ElectricBlue.copy(alpha = 0.18f))
            .border(1.dp, Cyan.copy(alpha = 0.45f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(name.ifBlank { "S" }.take(1).uppercase(), color = Cyan, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}

@Composable
private fun smartChipColors() = FilterChipDefaults.filterChipColors(
    selectedContainerColor = ElectricBlue.copy(alpha = 0.24f),
    selectedLabelColor = Cyan,
    containerColor = CardBgAlt,
    labelColor = TextMuted
)

private fun moneyInput(value: String): String =
    value.filter { it.isDigit() || it == '.' }

// ── Auto-detect fee type from selected months ──
private fun autoDetectFeeType(startIdx: Int, endIdx: Int, currentMonthIdx: Int): String {
    val safeStart = minOf(startIdx, endIdx)
    val safeEnd = maxOf(startIdx, endIdx)
    return when {
        safeEnd < currentMonthIdx -> "Due Fee"
        safeStart > currentMonthIdx -> "Advance Fee"
        safeStart == currentMonthIdx && safeEnd == currentMonthIdx -> "Running Month"
        safeStart <= currentMonthIdx && safeEnd >= currentMonthIdx -> "Mixed Period"
        else -> "Monthly Fee"
    }
}

// ═══════════════════════════════════════════════════════════════
//  MonthYearRangePicker — grid-based month picker with range support
// ═══════════════════════════════════════════════════════════════
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MonthYearRangePicker(
    selectedStartIdx: Int,
    selectedEndIdx: Int,
    monthOptions: List<UcMonthYear>,
    currentMonthIdx: Int,
    disabledIndices: Set<Int>,
    statusByIndex: Map<Int, FeeMonthStatus>,
    onDismiss: () -> Unit,
    onConfirm: (startIdx: Int, endIdx: Int) -> Unit
) {
    val names = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    val currentYear = Calendar.getInstance().get(Calendar.YEAR)
    val years = remember { (currentYear - 1..currentYear + 2).toList() }
    var viewYear by remember { mutableIntStateOf(monthOptions.getOrNull(selectedStartIdx)?.year ?: currentYear) }

    var tapStart by remember { mutableIntStateOf(selectedStartIdx) }
    var tapEnd by remember { mutableIntStateOf(selectedEndIdx) }
    var awaitingSecondTap by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardBg,
        title = {
            Column {
                Text("Select Fee Period", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (viewYear > years.first()) viewYear -= 1 }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.ChevronLeft, null, tint = TextMuted.copy(alpha = 0.7f))
                    }
                    Text("$viewYear", color = Cyan, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    IconButton(onClick = { if (viewYear < years.last()) viewYear += 1 }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.ChevronRight, null, tint = TextMuted.copy(alpha = 0.7f))
                    }
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                for (row in 0..2) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (col in 0..3) {
                            val month = row * 4 + col + 1
                            val globalIdx = monthOptions.indexOfFirst { it.month == month && it.year == viewYear }
                            val effectiveStart = minOf(tapStart, tapEnd)
                            val effectiveEnd = maxOf(tapStart, tapEnd)
                            val inRange = globalIdx in effectiveStart..effectiveEnd
                            val isEdge = globalIdx == tapStart || globalIdx == tapEnd
                            val isPast = globalIdx in 0..<currentMonthIdx
                            val disabled = globalIdx in disabledIndices
                            val status = statusByIndex[globalIdx]

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1.4f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        when {
                                            isEdge -> Cyan
                                            disabled -> CardBgAlt.copy(alpha = 0.55f)
                                            inRange -> Cyan.copy(alpha = 0.2f)
                                            else -> CardBgAlt
                                        }
                                    )
                                    .border(
                                        width = if (isEdge) 0.dp else 1.dp,
                                        color = when {
                                            globalIdx == currentMonthIdx -> Cyan.copy(alpha = 0.5f)
                                            isPast -> BorderSub.copy(alpha = 0.5f)
                                            else -> BorderSub
                                        },
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                    .clickable(enabled = !disabled) {
                                        if (awaitingSecondTap) {
                                            tapStart = globalIdx
                                            tapEnd = globalIdx
                                            awaitingSecondTap = false
                                        } else {
                                            if (globalIdx >= tapStart) {
                                                tapEnd = globalIdx
                                            } else {
                                                tapStart = globalIdx
                                            }
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    names[month - 1],
                                    color = when {
                                        isEdge -> CardBg
                                        disabled -> TextMuted.copy(alpha = 0.3f)
                                        inRange -> Cyan
                                        isPast -> TextMuted.copy(alpha = 0.45f)
                                        else -> TextMuted
                                    },
                                    fontSize = 13.sp,
                                    fontWeight = if (isEdge) FontWeight.Bold else FontWeight.Normal
                                )
                                if (status != null && !disabled) {
                                    Text(
                                        status.monthStatusLabel(),
                                        color = if (isEdge) CardBg else TextMuted,
                                        fontSize = 7.sp
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))

                val safeStart = minOf(tapStart, tapEnd)
                val safeEnd = maxOf(tapStart, tapEnd)
                val monthCount = (safeEnd - safeStart + 1).coerceAtLeast(1)
                val label = buildFeePeriodLabel(safeStart, safeEnd, monthOptions)
                val detectedType = autoDetectFeeType(safeStart, safeEnd, currentMonthIdx)

                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = CardBgAlt),
                    border = BorderStroke(1.dp, BorderSub)
                ) {
                    Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(label.ifBlank { "No selection" }, color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "$monthCount Month${if (monthCount > 1) "s" else ""} • $detectedType",
                            color = Cyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        },
        confirmButton = {
            val safeStart = minOf(tapStart, tapEnd)
            val safeEnd = maxOf(tapStart, tapEnd)
            TextButton(onClick = { onConfirm(safeStart, safeEnd) }) {
                Text("Confirm ✓", color = Cyan, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = TextMuted) } }
    )
}

@Composable
private fun MonthDropdown(
    label: String,
    selectedIdx: Int,
    monthOptions: List<UcMonthYear>,
    onSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    val selectedLabel = monthOptions.getOrNull(selectedIdx)?.label ?: "Select"

    Box(modifier = modifier) {
        OutlinedTextField(
            value = selectedLabel,
            onValueChange = {},
            readOnly = true,
            label = { Text(label, color = TextMuted, fontSize = 11.sp) },
            trailingIcon = {
                IconButton(onClick = { expanded = true }) {
                    Icon(Icons.Filled.ArrowDropDown, null, tint = TextMuted)
                }
            },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedContainerColor = CardBgAlt,
                unfocusedContainerColor = CardBgAlt,
                focusedBorderColor = Cyan.copy(alpha = 0.5f),
                unfocusedBorderColor = BorderSub,
                cursorColor = Cyan
            )
        )
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(CardBg)
        ) {
            monthOptions.forEachIndexed { idx, item ->
                DropdownMenuItem(
                    text = {
                        Text(
                            item.label,
                            color = if (idx == selectedIdx) Cyan else TextWhite,
                            fontSize = 13.sp,
                            fontWeight = if (idx == selectedIdx) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    onClick = {
                        onSelected(idx)
                        expanded = false
                    }
                )
            }
        }
    }
}

private data class UcMonthYear(val month: Int, val year: Int, val label: String)

private fun MonthlyFeeSchedule.BillingMonth.selectionKey(): String = "$year-$month"

private fun FeeMonthStatus.monthStatusLabel(): String = when (this) {
    FeeMonthStatus.DISABLED -> "Before fee start"
    FeeMonthStatus.PAID -> "Paid"
    FeeMonthStatus.PARTIAL -> "Partial"
    FeeMonthStatus.DUE -> "Due"
    FeeMonthStatus.CURRENT -> "Current"
    FeeMonthStatus.ADVANCE -> "Advance"
}

private fun FeeEntity.toMonthlyFeeSnapshotOrNull(): MonthlyFeeSnapshot? {
    val period = when {
        id.startsWith("monthly_due_") && dueDateMs > 0L -> MonthlyFeeSchedule.billingMonthAt(dueDateMs)
        else -> parseMonthlyPeriod(feePeriod)
    } ?: return null
    return MonthlyFeeSnapshot(
        id = id,
        period = period,
        baseAmount = baseAmount,
        discountAmount = discountAmount,
        lateFeeAmount = lateFeeAmount,
        totalAmount = totalAmount,
        paidAmount = paidAmount,
        dueAmount = dueAmount
    )
}

private fun parseMonthlyPeriod(value: String): MonthlyFeeSchedule.BillingMonth? {
    val match = Regex("(?i)\\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\\s+(\\d{4})\\b")
        .find(value) ?: return null
    val month = when (match.groupValues[1].lowercase(Locale.US)) {
        "jan", "january" -> 1; "feb", "february" -> 2; "mar", "march" -> 3; "apr", "april" -> 4
        "may" -> 5; "jun", "june" -> 6; "jul", "july" -> 7; "aug", "august" -> 8
        "sep", "sept", "september" -> 9; "oct", "october" -> 10; "nov", "november" -> 11
        "dec", "december" -> 12; else -> return null
    }
    return MonthlyFeeSchedule.BillingMonth(match.groupValues[2].toIntOrNull() ?: return null, month)
}

private fun generateMonthOptions(): List<UcMonthYear> {
    val names = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    val currentYear = Calendar.getInstance().get(Calendar.YEAR)
    return (currentYear - 1..currentYear + 2).flatMap { year ->
        (1..12).map { month -> UcMonthYear(month, year, "${names[month - 1]} $year") }
    }
}

private fun buildFeePeriodLabel(startIdx: Int, endIdx: Int, options: List<UcMonthYear>): String {
    if (startIdx == endIdx) return options.getOrNull(startIdx)?.label ?: ""
    val s = options.getOrNull(startIdx)?.label ?: return ""
    val e = options.getOrNull(endIdx)?.label ?: return ""
    return "$s - $e"
}

private fun monthLabelForOffset(offset: Int): String {
    val calendar = Calendar.getInstance()
    calendar.add(Calendar.MONTH, offset)
    return SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(calendar.time)
}

private fun advancePeriodLabel(monthCount: Int): String {
    val safeCount = monthCount.coerceAtLeast(1)
    return if (safeCount == 1) {
        monthLabelForOffset(1)
    } else {
        "${monthLabelForOffset(1)} - ${monthLabelForOffset(safeCount)}"
    }
}

private fun formatDate(timeMs: Long): String =
    SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(timeMs))

private fun formatEditDate(timeMs: Long): String =
    SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(timeMs))

private fun parseEditDate(value: String): Long? =
    runCatching {
        SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).apply {
            isLenient = false
        }.parse(value.trim())?.time
    }.getOrNull()

private fun formatSmartAmount(amount: Double): String =
    NumberFormat.getNumberInstance(Locale.getDefault()).apply {
        maximumFractionDigits = 0
    }.format(amount)

private fun pdfSafe(value: String, maxChars: Int): String =
    if (value.length <= maxChars) value else value.take(maxChars - 1) + "..."

private fun formatDiscountPercent(item: StudentPaymentHistory): String {
    val percent = if (item.baseAmount > 0.0) item.discountAmount / item.baseAmount * 100.0 else 0.0
    return if (percent % 1.0 == 0.0) "%.0f".format(percent) else "%.1f".format(percent)
}

private fun drawReceiptLine(
    canvas: android.graphics.Canvas,
    textPaint: Paint,
    boldPaint: Paint,
    label: String,
    value: String,
    x: Float,
    y: Float,
    valueColor: Int = AndroidColor.rgb(20, 27, 38)
) {
    textPaint.color = AndroidColor.rgb(100, 116, 139)
    textPaint.textSize = 11f
    textPaint.textAlign = Paint.Align.LEFT
    canvas.drawText(label, x, y, textPaint)
    boldPaint.color = valueColor
    boldPaint.textSize = 12f
    boldPaint.textAlign = Paint.Align.RIGHT
    canvas.drawText(value, 368f, y, boldPaint)
    boldPaint.textAlign = Paint.Align.LEFT
}

private fun buildCollectionReceiptText(
    instituteName: String,
    institutePhone: String,
    student: StudentEntity,
    batchName: String?,
    period: String,
    mode: String,
    payableAmount: Double,
    discountAmount: Double,
    collectedAmount: Double,
    remainingDue: Double,
    paymentMethod: String
): String = buildString {
    appendLine("══════════════════════════════")
    appendLine("  $instituteName")
    appendLine("══════════════════════════════")
    appendLine("PAYMENT RECEIPT")
    appendLine("")
    appendLine("Student: ${student.fullName}")
    appendLine("ID: ${student.studentCode}")
    appendLine("Batch: ${batchName ?: "Direct"}")
    appendLine("Type: $mode")
    appendLine("Period: $period")
    appendLine("Payable: BDT ${formatSmartAmount(payableAmount)}")
    if (discountAmount > 0.0) appendLine("Discount: BDT ${formatSmartAmount(discountAmount)}")
    appendLine("Collected: BDT ${formatSmartAmount(collectedAmount)}")
    appendLine("Remaining Due: BDT ${formatSmartAmount(remainingDue)}")
    appendLine("Method: ${paymentMethod.uppercase()}")
    appendLine("Date: ${formatDate(System.currentTimeMillis())}")
    appendLine("")
    appendLine("──────────────────────────────")
    appendLine("Contact: $institutePhone")
    appendLine("Thank you • $instituteName")
}

private fun buildHistoryReceiptText(institute: InstituteInfo, student: StudentEntity, item: StudentPaymentHistory): String =
    buildString {
        appendLine("══════════════════════════════")
        appendLine("  ${institute.name}")
        appendLine("══════════════════════════════")
        appendLine("PAYMENT RECEIPT")
        appendLine("Receipt: ${item.payment.receiptNumber}")
        appendLine("")
        appendLine("Student: ${student.fullName}")
        appendLine("ID: ${student.studentCode}")
        appendLine("Batch: ${item.batchName ?: "Direct"}")
        appendLine("Period: ${item.feePeriod}")
        appendLine("Date: ${formatDate(item.payment.paymentDateMs)}")
        appendLine("Fee Amount: BDT ${formatSmartAmount(item.baseAmount)}")
        if (item.discountAmount > 0.0) {
            appendLine("Discount: ${formatDiscountPercent(item)}% - BDT ${formatSmartAmount(item.discountAmount)}")
        }
        appendLine("Payable: BDT ${formatSmartAmount(item.totalAmount)}")
        appendLine("Collected: BDT ${formatSmartAmount(item.payment.amount)}")
        appendLine("Remaining Due: BDT ${formatSmartAmount(item.remainingDue)}")
        appendLine("Method: ${item.payment.paymentMethod.uppercase()}")
        item.payment.note?.takeIf { it.isNotBlank() }?.let { appendLine("Note: $it") }
        appendLine("")
        appendLine("──────────────────────────────")
        appendLine("Contact: ${institute.phone}")
        appendLine("Thank you • ${institute.name}")
    }

private data class InstituteInfo(val name: String, val phone: String, val logoText: String)

private fun shareHistoryReceipt(context: Context, receiptText: String) {
    context.startActivity(
        Intent.createChooser(
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "Payment Receipt")
                putExtra(Intent.EXTRA_TEXT, receiptText)
            },
            "Share Receipt"
        )
    )
}

private fun openReceiptDocument(context: Context, document: ReceiptDocument) {
    try {
        val uri = generateReceiptDocumentPdf(context, document)
        context.startActivity(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        })
    } catch (_: Exception) {
        Toast.makeText(context, "Could not open receipt PDF", Toast.LENGTH_SHORT).show()
    }
}

private fun shareReceiptDocumentPdf(context: Context, document: ReceiptDocument, phone: String?) {
    try {
        val uri = generateReceiptDocumentPdf(context, document)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, "Money Receipt - " + document.receiptNumber)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        if (!phone.isNullOrBlank()) {
            intent.putExtra("jid", phone.replace("+", "").replace(" ", "").replace("-", "") + "@s.whatsapp.net")
        }
        try {
            intent.setPackage("com.whatsapp")
            context.startActivity(intent)
        } catch (_: Exception) {
            intent.setPackage(null)
            context.startActivity(Intent.createChooser(intent, "Share Receipt"))
        }
    } catch (_: Exception) {
        Toast.makeText(context, "Could not share receipt PDF", Toast.LENGTH_SHORT).show()
    }
}

private fun sendHistoryReceiptMessage(context: Context, phone: String?, receiptText: String) {
    context.startActivity(
        Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${phone.orEmpty()}")).apply {
            putExtra("sms_body", receiptText)
        }
    )
}

private fun sendHistoryReceiptWhatsApp(context: Context, institute: InstituteInfo, student: StudentEntity, phone: String?, item: StudentPaymentHistory) {
    try {
        val file = generateReceiptPdf(context, institute, student, item)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val cleanPhone = phone.orEmpty().replace("+", "").replace(" ", "").replace("-", "")
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, "Payment Receipt - ${student.fullName}")
        }
        try {
            intent.`package` = "com.whatsapp"
            context.startActivity(intent)
        } catch (_: Exception) {
            val waIntent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse(if (cleanPhone.isBlank()) "https://wa.me/" else "https://wa.me/$cleanPhone")
            }
            context.startActivity(waIntent)
            Toast.makeText(context, "Please attach the PDF manually from your files.", Toast.LENGTH_LONG).show()
        }
    } catch (_: Exception) {
        val receiptText = buildHistoryReceiptText(institute, student, item)
        val cleanPhone = phone.orEmpty().replace("+", "").replace(" ", "").replace("-", "")
        val encoded = URLEncoder.encode(receiptText, "UTF-8")
        val url = if (cleanPhone.isBlank()) "https://wa.me/?text=$encoded" else "https://wa.me/$cleanPhone?text=$encoded"
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }
}

private fun printHistoryReceipt(context: Context, institute: InstituteInfo, student: StudentEntity, item: StudentPaymentHistory) {
    try {
        val file = generateReceiptPdf(context, institute, student, item)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        context.startActivity(
            Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        )
    } catch (e: Exception) {
        val receiptText = buildHistoryReceiptText(institute, student, item)
        Toast.makeText(context, "Could not open receipt PDF. Sharing text instead.", Toast.LENGTH_SHORT).show()
        shareHistoryReceipt(context, receiptText)
    }
}

private fun generateReceiptPdf(context: Context, institute: InstituteInfo, student: StudentEntity, item: StudentPaymentHistory): File {
    val document = PdfDocument()
    val showDiscount = item.discountAmount > 0.0
    val pageHeight = if (showDiscount) 575 else 535
        val page = document.startPage(PdfDocument.PageInfo.Builder(420, pageHeight, 1).create())
        val canvas = page.canvas
        val ink = AndroidColor.rgb(20, 27, 38)
        val muted = AndroidColor.rgb(101, 116, 139)
        val blue = AndroidColor.rgb(37, 99, 235)
        val cyan = AndroidColor.rgb(14, 165, 233)
        val green = AndroidColor.rgb(16, 185, 129)
        val softBlue = AndroidColor.rgb(239, 246, 255)
        val softLine = AndroidColor.rgb(226, 232, 240)
        val pale = AndroidColor.rgb(248, 250, 252)
        val fill = Paint().apply { style = Paint.Style.FILL }
        val stroke = Paint().apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.1f
            color = softLine
        }
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ink
            textSize = 11.5f
        }
        val bold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ink
            textSize = 13f
            isFakeBoldText = true
        }
        val whiteBold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = AndroidColor.WHITE
            textSize = 12f
            isFakeBoldText = true
        }

        canvas.drawColor(AndroidColor.WHITE)
        fill.color = pale
        canvas.drawRoundRect(RectF(18f, 18f, 402f, pageHeight - 18f), 22f, 22f, fill)
        canvas.drawRoundRect(RectF(18f, 18f, 402f, pageHeight - 18f), 22f, 22f, stroke)

        fill.color = blue
        canvas.drawRoundRect(RectF(18f, 18f, 402f, 120f), 22f, 22f, fill)
        fill.color = cyan
        canvas.drawCircle(363f, 48f, 42f, fill)
        fill.color = AndroidColor.argb(80, 255, 255, 255)
        canvas.drawCircle(334f, 80f, 24f, fill)

        fill.color = AndroidColor.WHITE
        canvas.drawRoundRect(RectF(34f, 34f, 72f, 72f), 10f, 10f, fill)
        bold.color = blue
        bold.textSize = 14f
        canvas.drawText(institute.logoText.take(2).uppercase(), 44f, 58f, bold)
        whiteBold.textSize = 16f
        val safeName = pdfSafe(institute.name, 24)
        canvas.drawText(safeName, 88f, 46f, whiteBold)
        text.color = AndroidColor.argb(210, 255, 255, 255)
        text.textSize = 10f
        canvas.drawText("Receipt ${item.payment.receiptNumber}", 88f, 64f, text)
        canvas.drawText(formatEditDate(item.payment.paymentDateMs), 292f, 64f, text)
        canvas.drawText("Contact: ${institute.phone}", 88f, 80f, text)

        var y = 148f
        bold.color = ink
        bold.textSize = 17f
        canvas.drawText(pdfSafe(student.fullName, 27), 34f, y, bold)
        text.color = muted
        text.textSize = 11f
        canvas.drawText("Student ID: ${student.studentCode}", 34f, y + 18f, text)
        canvas.drawText("Guardian: ${pdfSafe(student.guardianName ?: "N/A", 24)}", 34f, y + 34f, text)
        canvas.drawText("Phone: ${student.phone ?: student.guardianPhone ?: "N/A"}", 244f, y + 18f, text)
        canvas.drawText("Batch: ${pdfSafe(item.batchName ?: "Direct", 19)}", 244f, y + 34f, text)

        y += 64f
        fill.color = AndroidColor.WHITE
        canvas.drawRoundRect(RectF(34f, y, 386f, y + 108f), 16f, 16f, fill)
        canvas.drawRoundRect(RectF(34f, y, 386f, y + 108f), 16f, 16f, stroke)
        drawReceiptLine(canvas, text, bold, "Fee period", item.feePeriod, 52f, y + 28f)
        drawReceiptLine(canvas, text, bold, "Fee amount", "BDT ${formatSmartAmount(item.baseAmount)}", 52f, y + 52f)
        if (showDiscount) {
            drawReceiptLine(
                canvas,
                text,
                bold,
                "Discount",
                "${formatDiscountPercent(item)}%  |  BDT ${formatSmartAmount(item.discountAmount)}",
                52f,
                y + 76f,
                valueColor = green
            )
            drawReceiptLine(canvas, text, bold, "Payable", "BDT ${formatSmartAmount(item.totalAmount)}", 52f, y + 100f)
            y += 132f
        } else {
            drawReceiptLine(canvas, text, bold, "Payable", "BDT ${formatSmartAmount(item.totalAmount)}", 52f, y + 76f)
            y += 108f
        }

        fill.color = AndroidColor.WHITE
        canvas.drawRoundRect(RectF(34f, y, 386f, y + 104f), 16f, 16f, fill)
        canvas.drawRoundRect(RectF(34f, y, 386f, y + 104f), 16f, 16f, stroke)
        text.color = muted
        text.textSize = 11f
        canvas.drawText("Collected", 52f, y + 30f, text)
        bold.color = blue
        bold.textSize = 24f
        bold.textAlign = Paint.Align.RIGHT
        canvas.drawText("BDT ${formatSmartAmount(item.payment.amount)}", 368f, y + 34f, bold)
        bold.textAlign = Paint.Align.LEFT
        drawReceiptLine(canvas, text, bold, "Remaining due", "BDT ${formatSmartAmount(item.remainingDue)}", 52f, y + 68f, valueColor = if (item.remainingDue > 0.0) AndroidColor.rgb(245, 158, 11) else green)
        drawReceiptLine(canvas, text, bold, "Payment mode", item.payment.paymentMethod.replaceFirstChar { it.uppercase() }, 52f, y + 90f)
        y += 130f

        fill.color = softBlue
        canvas.drawRoundRect(RectF(34f, y, 386f, y + 54f), 14f, 14f, fill)
        text.color = muted
        text.textSize = 10.5f
        canvas.drawText("Remark", 52f, y + 20f, text)
        text.color = ink
        text.textSize = 11.5f
        canvas.drawText(pdfSafe(item.payment.note ?: "No remark added", 48), 52f, y + 39f, text)
        y += 86f

        stroke.color = softLine
        canvas.drawLine(44f, y, 172f, y, stroke)
        canvas.drawLine(248f, y, 376f, y, stroke)
        text.color = muted
        text.textSize = 10f
        text.textAlign = Paint.Align.CENTER
        canvas.drawText("Received By", 108f, y + 17f, text)
        canvas.drawText("Authorized Sign", 312f, y + 17f, text)
        text.textAlign = Paint.Align.LEFT

        fill.color = blue
        canvas.drawRoundRect(RectF(34f, pageHeight - 46f, 386f, pageHeight - 30f), 8f, 8f, fill)
        text.color = AndroidColor.WHITE
        text.textSize = 9.5f
        text.textAlign = Paint.Align.CENTER
        canvas.drawText("Thank you  •  ${institute.name}", 210f, pageHeight - 34f, text)
        text.textAlign = Paint.Align.LEFT

        document.finishPage(page)

        val file = File(context.cacheDir, "history_receipt_${item.payment.receiptNumber.replace("/", "_")}.pdf")
        file.outputStream().use { document.writeTo(it) }
        document.close()
        return file
}

