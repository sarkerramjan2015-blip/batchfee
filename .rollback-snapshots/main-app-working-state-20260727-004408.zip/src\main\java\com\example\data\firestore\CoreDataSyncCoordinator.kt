﻿package com.batchfee.edu.data.firestore

import com.batchfee.edu.data.database.AppDatabase
import com.batchfee.edu.data.repository.MonthlyFeeReconciliationRepository
import com.batchfee.edu.domain.SessionManager
import com.google.firebase.crashlytics.FirebaseCrashlytics

object CoreDataSyncCoordinator {

    suspend fun refreshInstituteCache(db: AppDatabase, instituteId: String): Boolean {
        return try {
            SubscriptionPlanSyncHelper.syncAllFromFirestore(db)
            if (instituteId.isBlank()) return false
            InstituteSyncHelper.syncInstituteFromFirestore(db, instituteId)
            StaffSyncHelper.syncAllFromFirestore(db, instituteId)
            StudentSyncHelper.syncAllFromFirestore(db, instituteId)
            BatchSyncHelper.syncAllFromFirestore(db, instituteId)
            BatchStudentSyncHelper.syncAllFromFirestore(db, instituteId)
            FinanceSyncHelper.syncAllFromFirestore(db, instituteId)
            MonthlyFeeReconciliationRepository(db).reconcile(instituteId)
            AttendanceSyncHelper.syncAllFromFirestore(db, instituteId)
            EnquirySyncHelper.syncAllFromFirestore(db, instituteId)
            ExamSyncHelper.syncAllFromFirestore(db, instituteId)
            ExpenseSyncHelper.syncAllFromFirestore(db, instituteId)
            SalarySyncHelper.syncAllFromFirestore(db, instituteId)
            ReminderTemplateSyncHelper.syncAllFromFirestore(db, instituteId)
            AuditLogSyncHelper.syncAllFromFirestore(db, instituteId)
            true
        } catch (e: Exception) {
            SessionManager.handleRemoteFailure(e)
            FirebaseCrashlytics.getInstance().recordException(e)
            false
        }
    }
}

